import Fuse from 'fuse.js'
import { normalizeCommandText } from '../../../commands/parser/normalizeText'
import type { SlotResolution, VoiceSlotOption } from './slotTypes'

const normalizeSlotText = (value: string): string =>
  normalizeCommandText(value)
    .replace(/[’']/g, '')
    .replace(/[,/\\_\-—–]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()

const compact = (value: string): string => value.replace(/\s+/g, '')

const editDistance = (left: string, right: string): number => {
  const previous = Array.from({ length: right.length + 1 }, (_, index) => index)
  for (let leftIndex = 1; leftIndex <= left.length; leftIndex += 1) {
    let diagonal = previous[0]
    previous[0] = leftIndex
    for (let rightIndex = 1; rightIndex <= right.length; rightIndex += 1) {
      const above = previous[rightIndex]
      previous[rightIndex] = Math.min(
        above + 1,
        previous[rightIndex - 1] + 1,
        diagonal + (left[leftIndex - 1] === right[rightIndex - 1] ? 0 : 1),
      )
      diagonal = above
    }
  }
  return previous[right.length]
}

const compactEditRatio = (left: string, right: string): number => {
  const longest = Math.max(left.length, right.length)
  return longest ? editDistance(left, right) / longest : 0
}

const semanticOptionKey = (option: VoiceSlotOption): string =>
  option.instanceId
    ? `instance:${option.instanceId}`
    : `canonical:${normalizeSlotText(option.canonical)}`

const coalesceEquivalentOptions = (
  options: readonly VoiceSlotOption[],
): VoiceSlotOption[] => {
  const byEntity = new Map<string, VoiceSlotOption>()
  for (const option of options) {
    const key = semanticOptionKey(option)
    const previous = byEntity.get(key)
    if (!previous) {
      byEntity.set(key, option)
      continue
    }
    byEntity.set(key, {
      ...previous,
      aliases: [...new Set([...previous.aliases, ...option.aliases])],
    })
  }
  return [...byEntity.values()]
}

const normalizedAliases = (option: VoiceSlotOption): string[] =>
  [normalizeSlotText(option.canonical), ...option.aliases.map(normalizeSlotText)].filter(Boolean)

type FuseSlotDocument = { optionIndex: number; normalized: string; compact: string }
type RankedOption = { option: VoiceSlotOption; fuseScore: number }

const TOKEN_FUSE_THRESHOLD = 0.4
const COMPACT_FUSE_THRESHOLD = 0.38
const MAX_ACCEPTED_FUSE_SCORE = 0.38
const WEAK_AMBIGUITY_FUSE_SCORE = 0.44
const AMBIGUITY_FUSE_MARGIN = 0.07
const MAX_COMPACT_EDIT_RATIO = 0.3
const COMPACT_EDIT_AMBIGUITY_MARGIN = 0.1
const MIN_FUZZY_QUERY_LENGTH = 5
const BOUNDARY_PREFIX_MIN_SCORE = 96

const FRAGMENT_MIN_COMPACT_LENGTH = 3
const FRAGMENT_MAX_EDIT_RATIO = 0.34
const FRAGMENT_MAX_TOKENS = 3

const contiguousFragments = (value: string): string[] => {
  const tokens = value.split(/\s+/).filter(Boolean)
  const fragments: string[] = []
  for (let start = 0; start < tokens.length; start += 1)
    for (let size = 1; size <= FRAGMENT_MAX_TOKENS; size += 1) {
      const fragment = tokens.slice(start, start + size).join(' ')
      if (compact(fragment).length >= FRAGMENT_MIN_COMPACT_LENGTH)
        fragments.push(fragment)
    }
  return fragments
}

const fragmentMatchRatio = (query: string, fragment: string): number | undefined => {
  const queryCompact = compact(query)
  const fragmentCompact = compact(fragment)
  if (
    queryCompact === fragmentCompact ||
    (queryCompact.length >= 5 && fragmentCompact.includes(queryCompact)) ||
    (fragmentCompact.length >= 5 && queryCompact.includes(fragmentCompact))
  )
    return 0
  const ratio = compactEditRatio(queryCompact, fragmentCompact)
  return ratio <= FRAGMENT_MAX_EDIT_RATIO ? ratio : undefined
}

/**
 * Short/partial names are safe only when the current legal catalog makes the
 * reference unique. This deliberately uses no card-specific aliases: "senu",
 * "seno" or "keen eye" are resolved from name fragments, while "bender" stays
 * ambiguous if several legal entities contain a compatible fragment.
 */
const contextualFragmentResolution = (
  query: string,
  options: readonly VoiceSlotOption[],
): SlotResolution | null => {
  if (compact(query).length < FRAGMENT_MIN_COMPACT_LENGTH) return null
  const matched = options
    .map((option) => {
      let bestRatio: number | undefined
      for (const alias of normalizedAliases(option))
        for (const fragment of contiguousFragments(alias)) {
          const ratio = fragmentMatchRatio(query, fragment)
          if (ratio === undefined) continue
          if (bestRatio === undefined || ratio < bestRatio) bestRatio = ratio
        }
      return bestRatio === undefined ? undefined : { option, ratio: bestRatio }
    })
    .filter((value): value is { option: VoiceSlotOption; ratio: number } => Boolean(value))
    .sort((left, right) => left.ratio - right.ratio)

  if (!matched.length) return null
  const bestRatio = matched[0].ratio
  const contenders = matched.filter(
    ({ ratio }) => ratio - bestRatio <= 0.08,
  )
  if (contenders.length > 1)
    return { status: 'AMBIGUOUS', options: contenders.map(({ option }) => option) }
  return {
    status: 'MATCHED',
    option: matched[0].option,
    score: bestRatio === 0 ? 96 : Math.max(86, Math.round((1 - bestRatio) * 100)),
  }
}

const toDocuments = (options: readonly VoiceSlotOption[]): FuseSlotDocument[] =>
  options.flatMap((option, optionIndex) =>
    normalizedAliases(option).map((normalized) => ({
      optionIndex,
      normalized,
      compact: compact(normalized),
    })),
  )

const addFuseResults = (
  ranked: Map<number, number>,
  results: readonly { item: FuseSlotDocument; score?: number }[],
): void => {
  for (const result of results) {
    if (typeof result.score !== 'number') continue
    const previous = ranked.get(result.item.optionIndex)
    if (previous === undefined || result.score < previous)
      ranked.set(result.item.optionIndex, result.score)
  }
}

const rankWithFuse = (query: string, options: readonly VoiceSlotOption[]): RankedOption[] => {
  const queryCompact = compact(query)
  if (queryCompact.length < MIN_FUZZY_QUERY_LENGTH) return []
  const documents = toDocuments(options)
  if (!documents.length) return []
  const ranked = new Map<number, number>()
  const tokenFuse = new Fuse(documents, {
    keys: ['normalized'], includeScore: true, useTokenSearch: true,
    tokenMatch: 'all', threshold: TOKEN_FUSE_THRESHOLD, ignoreLocation: true,
    ignoreFieldNorm: true, ignoreDiacritics: true, minMatchCharLength: 2,
  })
  addFuseResults(ranked, tokenFuse.search(query))
  const compactFuse = new Fuse(documents, {
    keys: ['compact'], includeScore: true, threshold: COMPACT_FUSE_THRESHOLD,
    ignoreLocation: true, ignoreFieldNorm: true, ignoreDiacritics: true,
    minMatchCharLength: 2,
  })
  addFuseResults(ranked, compactFuse.search(queryCompact))
  return [...ranked.entries()]
    .map(([optionIndex, fuseScore]) => ({ option: options[optionIndex], fuseScore }))
    .sort((left, right) => left.fuseScore - right.fuseScore)
}

const confidenceFromFuseScore = (score: number): number =>
  Math.max(0, Math.min(98, Math.round((1 - score) * 100)))

const exactCandidateResolution = (
  candidates: readonly VoiceSlotOption[],
  score: number,
): SlotResolution | null => {
  if (!candidates.length) return null
  if (candidates.length > 1) return { status: 'AMBIGUOUS', options: candidates }
  return { status: 'MATCHED', option: candidates[0], score }
}

const exactResolution = (
  query: string,
  options: readonly VoiceSlotOption[],
): SlotResolution | null => {
  const queryCompact = compact(query)
  const exactCanonical = exactCandidateResolution(
    options.filter((option) => normalizeSlotText(option.canonical) === query),
    100,
  )
  if (exactCanonical) return exactCanonical
  const compactCanonical = exactCandidateResolution(
    options.filter((option) => compact(normalizeSlotText(option.canonical)) === queryCompact),
    99,
  )
  if (compactCanonical) return compactCanonical
  const exactAlias = exactCandidateResolution(
    options.filter((option) => option.aliases.map(normalizeSlotText).includes(query)),
    98,
  )
  if (exactAlias) return exactAlias
  return exactCandidateResolution(
    options.filter((option) =>
      option.aliases.map(normalizeSlotText).some((alias) => compact(alias) === queryCompact),
    ),
    97,
  )
}

const rankByCompactEdit = (
  query: string,
  options: readonly VoiceSlotOption[],
): Array<{ option: VoiceSlotOption; ratio: number }> => {
  const queryCompact = compact(query)
  if (queryCompact.length < MIN_FUZZY_QUERY_LENGTH) return []
  return options
    .map((option) => ({
      option,
      ratio: Math.min(...normalizedAliases(option).map((alias) => compactEditRatio(queryCompact, compact(alias)))),
    }))
    .sort((left, right) => left.ratio - right.ratio)
}

const resolveNormalizedVoiceSlot = (
  query: string,
  options: readonly VoiceSlotOption[],
): SlotResolution => {
  const exact = exactResolution(query, options)
  if (exact) return exact
  const fragment = contextualFragmentResolution(query, options)
  if (fragment) return fragment
  const ranked = rankWithFuse(query, options)
  if (ranked.length && ranked[0].fuseScore <= MAX_ACCEPTED_FUSE_SCORE) {
    const best = ranked[0]
    const contenders = ranked.filter(({ fuseScore }) =>
      fuseScore <= WEAK_AMBIGUITY_FUSE_SCORE && fuseScore - best.fuseScore <= AMBIGUITY_FUSE_MARGIN,
    )
    if (contenders.length > 1)
      return { status: 'AMBIGUOUS', options: contenders.map(({ option }) => option) }
    return { status: 'MATCHED', option: best.option, score: confidenceFromFuseScore(best.fuseScore) }
  }

  const editRanked = rankByCompactEdit(query, options)
  const editBest = editRanked[0]
  if (!editBest || editBest.ratio > MAX_COMPACT_EDIT_RATIO)
    return { status: 'NO_MATCH' }
  const editContenders = editRanked.filter(({ ratio }) =>
    ratio <= MAX_COMPACT_EDIT_RATIO && ratio - editBest.ratio <= COMPACT_EDIT_AMBIGUITY_MARGIN,
  )
  if (editContenders.length > 1)
    return { status: 'AMBIGUOUS', options: editContenders.map(({ option }) => option) }
  return {
    status: 'MATCHED',
    option: editBest.option,
    score: Math.max(70, Math.round((1 - editBest.ratio) * 100)),
  }
}

const boundaryCandidates = (query: string): { prefix: string; remainder: string }[] => {
  const candidates: { prefix: string; remainder: string }[] = []
  const expression = /\s+y\s+/g
  for (const match of query.matchAll(expression)) {
    const index = match.index ?? -1
    if (index <= 0) continue
    const prefix = query.slice(0, index).trim()
    const remainder = query.slice(index + match[0].length).trim()
    if (prefix && remainder) candidates.push({ prefix, remainder })
  }
  return candidates.sort((left, right) => right.prefix.length - left.prefix.length)
}

export const resolveVoiceSlot = (
  rawQuery: string,
  options: readonly VoiceSlotOption[],
): SlotResolution => {
  const query = normalizeSlotText(rawQuery)
  if (!query || !options.length) return { status: 'NO_MATCH' }
  // Multiple recipe/printing entries can represent one deck entity. Physical
  // instances retain their instanceId and therefore remain distinct.
  const semanticOptions = coalesceEquivalentOptions(options)
  const whole = resolveNormalizedVoiceSlot(query, semanticOptions)
  if (whole.status !== 'NO_MATCH') return whole
  for (const boundary of boundaryCandidates(query)) {
    const prefix = resolveNormalizedVoiceSlot(boundary.prefix, semanticOptions)
    if (prefix.status !== 'MATCHED' || prefix.score < BOUNDARY_PREFIX_MIN_SCORE) continue
    const suffix = resolveNormalizedVoiceSlot(boundary.remainder, semanticOptions)
    if (suffix.status !== 'NO_MATCH') continue
    return { ...prefix, consumedText: boundary.prefix, ignoredRemainder: boundary.remainder }
  }
  return { status: 'NO_MATCH' }
}
