export type VoiceSlotOption = {
  id: string
  canonical: string
  aliases: readonly string[]
  instanceId?: string
}

export type SlotResolution =
  | { status: 'NO_MATCH' }
  | { status: 'AMBIGUOUS'; options: readonly VoiceSlotOption[] }
  | {
      status: 'MATCHED'
      option: VoiceSlotOption
      score: number
      consumedText?: string
      ignoredRemainder?: string
    }
