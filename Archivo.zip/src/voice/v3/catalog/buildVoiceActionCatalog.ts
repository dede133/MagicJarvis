import { cardNameAliases } from '../../../commands/resolver/cardResolver'
import {
  effectiveAbilitiesForCard,
  effectiveTypeLine,
} from '../../../abilities/engine/staticEffects'
import type { ActivatedAbilityDefinition } from '../../../abilities/types/abilityTypes'
import { activatedAbilityMatchesHint } from '../../../commands/resolver/activatedAbilityHints'
import { localizedCardAliases } from '../../../data/cardAliases'
import { activeDeckDefinition } from '../../../game/deckLookup'
import { basicLandManaColor } from '../../../rules/legality/basicLands'
import { canAttack, canBlock } from '../../../rules/combat/combatRules'
import {
  activePlayerIdOf,
  localPlayerIdOf,
  opponentPlayerIds,
} from '../../../rules/players/playerState'
import type { GameState } from '../../../types/game'
import { getResolvedDeckCommanders } from '../../../types/deck'
import { getVisualCardLabel } from '../../../utils/cardLabels'
import {
  getVoiceUiActions,
  type VoiceUiActionDescriptor,
} from '../../voiceUiActions'
import type { VoiceSlotOption } from '../slots/slotTypes'
import { buildVoiceReferenceAliases } from './voiceReferenceAliases'

export type VoiceActionCatalog = {
  pendingActions: readonly VoiceUiActionDescriptor[]
  playableCards: readonly VoiceSlotOption[]
  tappableCards: readonly VoiceSlotOption[]
  untappableCards: readonly VoiceSlotOption[]
  discardableCards: readonly VoiceSlotOption[]
  counterTargets: readonly VoiceSlotOption[]
  activatableCards: readonly VoiceSlotOption[]
  manaSources: readonly VoiceSlotOption[]
  channelSources: readonly VoiceSlotOption[]
  equipSources: readonly VoiceSlotOption[]
  waterbendSources: readonly VoiceSlotOption[]
  movableCards: readonly VoiceSlotOption[]
  attackableCards: readonly VoiceSlotOption[]
  defendingTargets: readonly VoiceSlotOption[]
  blockingAttackers: readonly VoiceSlotOption[]
  blockerCards: readonly VoiceSlotOption[]
  stackSpells: readonly VoiceSlotOption[]
}

const unique = (values: readonly string[]): string[] => [...new Set(values)]


const optionsForKnownInstances = (
  cards: GameState['cards'],
  prefix: string,
): VoiceSlotOption[] =>
  cards.map((card) => {
    const sameName = cards.filter(
      (candidate) => candidate.card.name === card.card.name,
    )
    const index =
      sameName.findIndex(
        (candidate) => candidate.instanceId === card.instanceId,
      ) + 1
    const baseAliases = [
      ...(localizedCardAliases[card.card.name] ?? []),
      ...(card.card.localizedAliases ?? []),
      ...Object.entries(cardNameAliases)
        .filter(
          ([, canonical]) => canonical === card.card.name.toLocaleLowerCase(),
        )
        .map(([alias]) => alias),
    ]
    return {
      id: `${prefix}:${card.instanceId}`,
      canonical: card.card.name,
      instanceId: card.instanceId,
      aliases: unique([
        getVisualCardLabel(card, cards),
        ...baseAliases,
        ...(sameName.length > 1
          ? baseAliases.map((alias) => `${alias} ${index}`)
          : []),
      ]),
    }
  })

const actorCommanderIds = (state: GameState): string[] => {
  const explicit = state.commanderIdsByPlayer?.[state.activePlayerId]
  if (explicit) return explicit
  if (!state.localPlayerId || state.activePlayerId === state.localPlayerId)
    return state.commanderIds ?? (state.commanderId ? [state.commanderId] : [])
  return []
}

export const buildPlayableCardVoiceOptions = (
  state: Pick<
    GameState,
    | 'activePlayerId'
    | 'deckDefinition'
    | 'deckDefinitionsByPlayer'
    | 'localPlayerId'
  >,
): VoiceSlotOption[] => {
  const deck = activeDeckDefinition(state)
  if (!deck) return []
  const commanders = getResolvedDeckCommanders(deck)
  const commanderNames = new Set(commanders.map((entry) => entry.name))
  const entries = [...commanders, ...deck.mainboard]
  const byName = new Map<string, VoiceSlotOption>()
  for (const entry of entries) {
    if (byName.has(entry.name)) continue
    const aliases = [
      ...(localizedCardAliases[entry.name] ?? []),
      ...(entry.card.localizedAliases ?? []),
      ...(entry.card.cardFaces ?? []).map((face) => face.name),
      ...buildVoiceReferenceAliases(entry.card, {
        commander: commanderNames.has(entry.name),
      }),
      ...Object.entries(cardNameAliases)
        .filter(([, canonical]) => canonical === entry.name.toLocaleLowerCase())
        .map(([alias]) => alias),
    ]
    byName.set(entry.name, {
      id: `deck:${entry.card.scryfallId}`,
      canonical: entry.name,
      aliases: unique(aliases),
    })
  }
  return [...byName.values()]
}

const isActorPermanent = (
  state: GameState,
  card: GameState['cards'][number],
) => {
  if (card.zone !== 'battlefield' || card.phasedOut) return false
  if (card.controllerId) return card.controllerId === state.activePlayerId
  const actorIsLocal =
    !state.localPlayerId || state.activePlayerId === state.localPlayerId
  return actorIsLocal
    ? card.controller !== 'OPPONENT'
    : card.controller === 'OPPONENT'
}

const isActorCard = (
  state: GameState,
  card: GameState['cards'][number],
): boolean => {
  const actorId = state.activePlayerId
  const actorIsLocal = !state.localPlayerId || actorId === state.localPlayerId
  if (card.zone === 'battlefield') {
    if (card.controllerId) return card.controllerId === actorId
    return actorIsLocal
      ? card.controller !== 'OPPONENT'
      : card.controller === 'OPPONENT'
  }
  if (card.ownerId) return card.ownerId === actorId
  return actorIsLocal
    ? card.controller !== 'OPPONENT'
    : card.controller === 'OPPONENT'
}

const activatedAbilitiesFromCurrentZone = (
  state: GameState,
  card: GameState['cards'][number],
): ActivatedAbilityDefinition[] =>
  effectiveAbilitiesForCard(state, card).filter(
    (ability): ability is ActivatedAbilityDefinition =>
      ability.kind === 'ACTIVATED' &&
      (ability.activeZones?.length
        ? ability.activeZones.includes(card.zone)
        : card.zone === 'battlefield'),
  )

const activatedSourceOptions = (
  state: GameState,
  predicate: (
    card: GameState['cards'][number],
    abilities: ActivatedAbilityDefinition[],
  ) => boolean,
): VoiceSlotOption[] => {
  const sources = state.cards.filter((card) => {
    if (!isActorCard(state, card) || card.phasedOut) return false
    return predicate(card, activatedAbilitiesFromCurrentZone(state, card))
  })
  return sources.map((card) => {
    const sameName = sources.filter(
      (candidate) => candidate.card.name === card.card.name,
    )
    const index =
      sameName.findIndex(
        (candidate) => candidate.instanceId === card.instanceId,
      ) + 1
    const baseAliases = [
      ...(localizedCardAliases[card.card.name] ?? []),
      ...(card.card.localizedAliases ?? []),
      ...buildVoiceReferenceAliases(card.card, {
        commander: actorCommanderIds(state).includes(card.instanceId),
      }),
      ...Object.entries(cardNameAliases)
        .filter(
          ([, canonical]) => canonical === card.card.name.toLocaleLowerCase(),
        )
        .map(([alias]) => alias),
    ]
    return {
      id: `ability-source:${card.instanceId}`,
      canonical: card.card.name,
      instanceId: card.instanceId,
      aliases: unique([
        getVisualCardLabel(card, sources),
        ...baseAliases,
        ...(sameName.length > 1
          ? baseAliases.map((alias) => `${alias} ${index}`)
          : []),
      ]),
    }
  })
}

const battlefieldOptions = (
  state: GameState,
  predicate: (card: GameState['cards'][number]) => boolean,
): VoiceSlotOption[] => {
  const visible = state.cards.filter((card) => isActorPermanent(state, card))
  return visible.filter(predicate).map((card) => {
    const sameName = visible.filter(
      (candidate) => candidate.card.name === card.card.name,
    )
    const index =
      sameName.findIndex(
        (candidate) => candidate.instanceId === card.instanceId,
      ) + 1
    const baseAliases = [
      ...(localizedCardAliases[card.card.name] ?? []),
      ...(card.card.localizedAliases ?? []),
      ...buildVoiceReferenceAliases(card.card, {
        commander: actorCommanderIds(state).includes(card.instanceId),
      }),
      ...Object.entries(cardNameAliases)
        .filter(
          ([, canonical]) => canonical === card.card.name.toLocaleLowerCase(),
        )
        .map(([alias]) => alias),
    ]
    return {
      id: `instance:${card.instanceId}`,
      canonical: card.card.name,
      instanceId: card.instanceId,
      aliases: unique([
        getVisualCardLabel(card, visible),
        ...baseAliases,
        ...(sameName.length > 1
          ? baseAliases.map((alias) => `${alias} ${index}`)
          : []),
      ]),
    }
  })
}

const knownActorCardOptions = (state: GameState): VoiceSlotOption[] => {
  const known = state.cards.filter(
    (card) => isActorCard(state, card) && !card.phasedOut,
  )
  return known.map((card) => {
    const sameName = known.filter(
      (candidate) => candidate.card.name === card.card.name,
    )
    const index =
      sameName.findIndex(
        (candidate) => candidate.instanceId === card.instanceId,
      ) + 1
    const baseAliases = [
      ...(localizedCardAliases[card.card.name] ?? []),
      ...(card.card.localizedAliases ?? []),
      ...buildVoiceReferenceAliases(card.card, {
        commander: actorCommanderIds(state).includes(card.instanceId),
      }),
      ...Object.entries(cardNameAliases)
        .filter(
          ([, canonical]) => canonical === card.card.name.toLocaleLowerCase(),
        )
        .map(([alias]) => alias),
    ]
    return {
      id: `known:${card.instanceId}`,
      canonical: card.card.name,
      instanceId: card.instanceId,
      aliases: unique([
        getVisualCardLabel(card, known),
        ...baseAliases,
        ...(sameName.length > 1
          ? baseAliases.map((alias) => `${alias} ${index}`)
          : []),
      ]),
    }
  })
}


const defendingTargetOptions = (state: GameState): VoiceSlotOption[] => {
  const defendingPlayerId = opponentPlayerIds(
    state,
    activePlayerIdOf(state),
  )[0]
  if (!defendingPlayerId) return []
  const localPlayerId = localPlayerIdOf(state)
  const planeswalkers = state.cards.filter((card) => {
    if (card.zone !== 'battlefield' || card.phasedOut) return false
    const controllerId =
      card.controllerId ??
      (card.controller === 'OPPONENT'
        ? opponentPlayerIds(state, localPlayerId)[0]
        : localPlayerId)
    return (
      controllerId === defendingPlayerId &&
      /\bplaneswalker\b/i.test(effectiveTypeLine(state, card))
    )
  })
  return optionsForKnownInstances(planeswalkers, 'defender')
}

const combatAttackerOptions = (state: GameState): VoiceSlotOption[] => {
  const ids = new Set(
    state.combatState.attackers.map((attacker) => attacker.attackerInstanceId),
  )
  return optionsForKnownInstances(
    state.cards.filter(
      (card) =>
        ids.has(card.instanceId) &&
        card.zone === 'battlefield' &&
        !card.phasedOut,
    ),
    'combat-attacker',
  )
}

const blockerOptions = (state: GameState): VoiceSlotOption[] => {
  if (
    state.turnState.step !== 'DECLARE_BLOCKERS' ||
    !state.combatState.active
  )
    return []
  const candidates = state.cards.filter(
    (card) =>
      isActorPermanent(state, card) &&
      /\bcreature\b/i.test(effectiveTypeLine(state, card)) &&
      state.combatState.attackers.some((attacker) =>
        canBlock(state, attacker, card).legal,
      ),
  )
  return optionsForKnownInstances(candidates, 'blocker')
}

const stackSpellOptions = (state: GameState): VoiceSlotOption[] =>
  optionsForKnownInstances(
    state.cards.filter((card) => card.zone === 'stack'),
    'stack-spell',
  )

export const buildVoiceActionCatalog = (
  state: GameState,
): VoiceActionCatalog => {
  const deck = buildPlayableCardVoiceOptions(state)
  return {
    pendingActions: getVoiceUiActions(state),
    // Hand identity is deliberately never inferred. The deck recipe is merely
    // the vocabulary of cards the player may physically declare.
    playableCards: deck,
    discardableCards: deck,
    tappableCards: battlefieldOptions(state, (card) => !card.tapped),
    untappableCards: battlefieldOptions(state, (card) => card.tapped),
    counterTargets: battlefieldOptions(state, () => true),
    activatableCards: activatedSourceOptions(
      state,
      (_card, abilities) => abilities.length > 0,
    ),
    manaSources: activatedSourceOptions(
      state,
      (card, abilities) =>
        card.zone === 'battlefield' &&
        (abilities.some((ability) =>
          activatedAbilityMatchesHint(ability, 'MANA'),
        ) ||
          basicLandManaColor(effectiveTypeLine(state, card)) !== undefined),
    ),
    channelSources: activatedSourceOptions(state, (_card, abilities) =>
      abilities.some((ability) =>
        activatedAbilityMatchesHint(ability, 'CHANNEL'),
      ),
    ),
    equipSources: activatedSourceOptions(state, (_card, abilities) =>
      abilities.some((ability) =>
        activatedAbilityMatchesHint(ability, 'EQUIP'),
      ),
    ),
    waterbendSources: activatedSourceOptions(state, (_card, abilities) =>
      abilities.some((ability) =>
        activatedAbilityMatchesHint(ability, 'WATERBEND'),
      ),
    ),
    movableCards: knownActorCardOptions(state),
    attackableCards: battlefieldOptions(
      state,
      (card) => canAttack(state, card).legal,
    ),
    defendingTargets: defendingTargetOptions(state),
    blockingAttackers: combatAttackerOptions(state),
    blockerCards: blockerOptions(state),
    stackSpells: stackSpellOptions(state),
  }
}
