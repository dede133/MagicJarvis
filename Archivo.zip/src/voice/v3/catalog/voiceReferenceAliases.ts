import { normalizeCommandText } from '../../../commands/parser/normalizeText'
import type { CardDefinition } from '../../../types/card'

const unique = (values: readonly string[]): string[] => [...new Set(values.filter(Boolean))]

const splitTypeLine = (typeLine: string): { left: string[]; subtypes: string[] } => {
  const [rawLeft = '', rawSubtypes = ''] = typeLine.split(/\s+[—-]\s+/, 2)
  return {
    left: normalizeCommandText(rawLeft).split(/\s+/).filter(Boolean),
    subtypes: normalizeCommandText(rawSubtypes).split(/\s+/).filter(Boolean),
  }
}

const localizedTypeWord: Record<string, string> = {
  legendary: 'legendaria',
  basic: 'basica',
  land: 'tierra',
  creature: 'criatura',
  enchantment: 'encantamiento',
  artifact: 'artefacto',
  planeswalker: 'planeswalker',
  instant: 'instantaneo',
  sorcery: 'conjuro',
  equipment: 'equipo',
  aura: 'aura',
}

/**
 * Generates references from public card characteristics instead of card-by-card
 * aliases. The same rules therefore work for every deck: "mi comandante",
 * "tierra legendaria", "encantamiento", "tierra basica de isla", etc.
 * Ambiguity is intentionally preserved when several legal options share a role.
 */
export const buildVoiceReferenceAliases = (
  card: CardDefinition,
  options: { commander?: boolean } = {},
): string[] => {
  const { left, subtypes } = splitTypeLine(card.typeLine)
  const translatedLeft = left.map((word) => localizedTypeWord[word] ?? word)
  const translatedSubtypes = subtypes.map((word) => localizedTypeWord[word] ?? word)
  const aliases: string[] = []

  if (options.commander) aliases.push('comandante', 'mi comandante')

  if (translatedLeft.length) {
    aliases.push(translatedLeft.join(' '))
    for (const word of translatedLeft) aliases.push(word)
  }

  const hasLand = left.includes('land')
  const isBasic = left.includes('basic')
  const isLegendary = left.includes('legendary')
  if (hasLand) {
    aliases.push('tierra')
    if (isLegendary) aliases.push('tierra legendaria', 'legendaria')
    if (isBasic) aliases.push('tierra basica', 'basica')
    for (const subtype of translatedSubtypes) {
      aliases.push(subtype, `tierra ${subtype}`)
      if (isBasic)
        aliases.push(`tierra basica ${subtype}`, `tierra basica de ${subtype}`)
      if (isLegendary) aliases.push(`tierra legendaria ${subtype}`)
    }
  } else {
    for (const subtype of translatedSubtypes) aliases.push(subtype)
  }

  const normalizedName = normalizeCommandText(card.name)
  const descriptive = unique(aliases.map(normalizeCommandText))
  // Players often say the card class before the damaged name (for example
  // "encantamiento resourceful defense"). Generate that composition from
  // characteristics instead of teaching the recognizer per-card phrases.
  return unique([
    ...descriptive,
    ...descriptive.map((reference) => `${reference} ${normalizedName}`),
  ])
}
