import type { GameState } from '../../types/game'
import { DEFAULT_VOICE_LANGUAGE_PACK, type VoiceLanguagePack } from '../languages'
import { hasVoiceCommandCandidateAnchor } from '../voiceCommandGate'
import { matchSemanticVoiceCommand } from './matcher/semanticMatcher'
import type { SemanticIntent, SemanticMatchResult } from './semanticCommand'

type PendingVoiceSlot = {
  intent: SemanticIntent
  resumePrefix: string
  activePlayerId: GameState['activePlayerId']
  turn: number
  expiresAt: number
}

export type VoiceResumeResult = {
  transcript: string
  match: SemanticMatchResult
}

/**
 * Short-lived conversational state for Web Speech finals that split one human
 * declaration into several utterances ("juego" -> "Seat of the Empire"). It
 * stores only the missing semantic slot, never hidden card identity.
 */
export class VoiceConversationSession {
  private pending?: PendingVoiceSlot

  constructor(
    private readonly pendingTtlMs = 5_000,
    private readonly now: () => number = () => Date.now(),
  ) {}

  clear(): void {
    this.pending = undefined
  }

  rememberIncomplete(
    match: Extract<SemanticMatchResult, { status: 'INCOMPLETE' }>,
    state: GameState,
  ): void {
    this.pending = {
      intent: match.intent,
      resumePrefix: match.resumePrefix,
      activePlayerId: state.activePlayerId,
      turn: state.turn,
      expiresAt: this.now() + this.pendingTtlMs,
    }
  }

  tryResume(
    input: string,
    state: GameState,
    languagePack: VoiceLanguagePack = DEFAULT_VOICE_LANGUAGE_PACK,
  ): VoiceResumeResult | undefined {
    const pending = this.pending
    if (!pending) return undefined
    if (
      pending.expiresAt < this.now() ||
      pending.activePlayerId !== state.activePlayerId ||
      pending.turn !== state.turn
    ) {
      this.clear()
      return undefined
    }

    const transcript = `${pending.resumePrefix} ${input}`.trim()
    const match = matchSemanticVoiceCommand(transcript, state, languagePack)
    if (match.status === 'MATCHED' && match.command.intent === pending.intent) {
      this.clear()
      return { transcript, match }
    }
    if (match.status === 'AMBIGUOUS') {
      const compatible = match.commands.filter(
        (command) => command.intent === pending.intent,
      )
      if (compatible.length) return { transcript, match }
    }

    // Only after the pending intent failed to consume this utterance do we
    // treat an explicit new action as a replacement. This avoids mistaking a
    // card name containing a Magic word (for example "Mana Crypt") for a new
    // command before the slot resolver gets a chance to identify it.
    if (hasVoiceCommandCandidateAnchor(input, languagePack)) this.clear()
    return undefined
  }
}
