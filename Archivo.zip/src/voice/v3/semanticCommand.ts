import type { ActivatedAbilityHint } from '../../commands/types/commandTypes'
import type { Zone } from '../../types/card'
import type { TurnStep } from '../../types/turn'

export type SemanticIntent =
  | 'PLAY_CARD'
  | 'TAP_CARD'
  | 'UNTAP_CARD'
  | 'UNTAP_ALL'
  | 'NEXT_TURN'
  | 'ADVANCE_STEP'
  | 'GAIN_LIFE'
  | 'LOSE_LIFE'
  | 'SET_LIFE'
  | 'DRAW'
  | 'DISCARD_CARD'
  | 'SET_HAND_COUNT'
  | 'SET_LIBRARY_COUNT'
  | 'ADD_COUNTER'
  | 'REMOVE_COUNTER'
  | 'ACTIVATE_ABILITY'
  | 'ACTIVATE_MANA'
  | 'MOVE_ZONE'
  | 'SHUFFLE_LIBRARY'
  | 'DECLARE_ATTACKERS'
  | 'DECLARE_BLOCKERS'
  | 'RESOLVE_COMBAT_DAMAGE'
  | 'RESOLVE_SPELL'
  | 'UNDO'
  | 'CONCEDE'
  | 'PENDING_DECISION'

export type SemanticCommandSlots = {
  card?: string
  cardInstanceId?: string
  cards?: string[]
  cardInstanceIds?: string[]
  amount?: number
  counter?: string
  abilityHint?: ActivatedAbilityHint
  color?: string
  destination?: Zone
  all?: boolean
  subtype?: string
  defender?: string
  defenderInstanceId?: string
  attacker?: string
  attackerInstanceId?: string
  none?: boolean
  inResponse?: true
  targetStep?: TurnStep
  uiActionId?: string
  uiActionKind?: 'PENDING_DECISION' | 'PENDING_ABILITY_PAYMENT' | 'PENDING_ABILITY_RESOLVE' | 'PENDING_ABILITY_IGNORE'
  decisionId?: string
  pendingAbilityId?: string
  selection?: string
  uiDescription?: string
  uiParsed?: string
  uiEntity?: string
}

export type SemanticCommand = {
  intent: SemanticIntent
  slots: SemanticCommandSlots
  normalizedText: string
  /** Deterministic confidence: structural grammar + contextual slot evidence. */
  score: number
  evidence: string[]
}

export type SemanticMatchResult =
  | { status: 'NO_MATCH'; normalizedText: string }
  | {
      status: 'INCOMPLETE'
      normalizedText: string
      intent: SemanticIntent
      resumePrefix: string
      description: string
    }
  | {
      status: 'REJECTED_CONTEXT'
      normalizedText: string
      description: string
    }
  | {
      status: 'UNSAFE'
      normalizedText: string
      reason: 'QUESTION' | 'UNCERTAINTY' | 'NEGATED_ACTION' | 'PAST_REFERENCE'
    }
  | {
      status: 'AMBIGUOUS'
      normalizedText: string
      commands: SemanticCommand[]
      description: string
    }
  | { status: 'MATCHED'; command: SemanticCommand }
