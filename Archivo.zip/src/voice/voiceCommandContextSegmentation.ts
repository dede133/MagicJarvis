import { parseCommand } from '../commands/parser/parseCommand'
import type { ParsedCommand } from '../commands/types/commandTypes'
import { activeDeckDefinition } from '../game/deckLookup'
import type { GameState } from '../types/game'
import { normalizeSpokenCommand } from './spokenCommandNormalizer'
import { buildPlayableCardVoiceOptions } from './v3/catalog/buildVoiceActionCatalog'
import { resolveVoiceSlot } from './v3/slots/resolveSlot'
import { segmentVoiceCommands } from './voiceCommandSegmentation'
import { DEFAULT_VOICE_LANGUAGE_PACK, type VoiceLanguagePack } from './languages'

type VoiceDeckContext = Pick<
  GameState,
  | 'activePlayerId'
  | 'deckDefinition'
  | 'deckDefinitionsByPlayer'
  | 'localPlayerId'
>

type CardDeclaration = {
  prefix: 'juego' | 'lanzo'
  command: Extract<
    ParsedCommand,
    { type: 'PLAY_CARD' | 'DECLARE_CARD' | 'CAST_SPELL' }
  >
}

const cardDeclaration = (
  input: string,
  languagePack: VoiceLanguagePack,
): CardDeclaration | undefined => {
  const parsed = parseCommand(normalizeSpokenCommand(input, languagePack))
  if (parsed.status !== 'parsed') return undefined

  switch (parsed.command.type) {
    case 'PLAY_CARD':
    case 'DECLARE_CARD':
      return { prefix: 'juego', command: parsed.command }
    case 'CAST_SPELL':
      return { prefix: 'lanzo', command: parsed.command }
    default:
      return undefined
  }
}

const resolvesDeckCard = (
  game: VoiceDeckContext,
  command: CardDeclaration['command'],
): boolean =>
  resolveVoiceSlot(command.cardQuery, buildPlayableCardVoiceOptions(game))
    .status === 'MATCHED'

/**
 * Handles a common spoken ellipsis that is unsafe to solve with a generic
 * `split(' y ')`:
 *
 *   "juego una isla y una remora"
 *     -> "juego una isla" + "juego una remora"
 *
 * We only split when the whole card query does NOT resolve in the active deck,
 * but every inherited sub-command DOES resolve to a real deck card. This keeps
 * ordinary lists such as "ataco con Namor y Wolverine" untouched and avoids
 * inventing cards from arbitrary conversation.
 */
const expandResolvableCardEllipsis = (
  segment: string,
  game: VoiceDeckContext,
  languagePack: VoiceLanguagePack,
): string[] => {
  if (!activeDeckDefinition(game) || !/\s+y\s+/.test(segment)) return [segment]

  const whole = cardDeclaration(segment, languagePack)
  if (!whole) return [segment]

  // If the original query already names a real card, "y" may belong to the
  // card/alias itself and must not be treated as a command boundary.
  if (resolvesDeckCard(game, whole.command)) return [segment]

  const parts = segment
    .split(/\s+y\s+/)
    .map((part) => part.trim())
    .filter(Boolean)
  if (parts.length < 2) return [segment]

  const inherited = parts.map((part, index) =>
    index === 0 ? part : `${whole.prefix} ${part}`,
  )
  const declarations = inherited.map((value) => cardDeclaration(value, languagePack))
  if (
    declarations.some(
      (declaration) =>
        !declaration || !resolvesDeckCard(game, declaration.command),
    )
  )
    return [segment]

  return inherited
}

/**
 * Game-aware second pass over the conservative text segmenter. Text-only
 * segmentation intentionally does not guess at plain "y" ellipsis. Once the
 * active deck is available, we can safely split only when both sides resolve
 * to actual deck cards.
 */
export const segmentVoiceCommandsForGame = (
  input: string,
  game: VoiceDeckContext,
  languagePack: VoiceLanguagePack = DEFAULT_VOICE_LANGUAGE_PACK,
): string[] =>
  segmentVoiceCommands(input, languagePack).flatMap((segment) =>
    expandResolvableCardEllipsis(segment, game, languagePack),
  )
