import readyCatalog from './tritones-runtime-ready-definitions.json'
import runtimeCatalog from './tritones-runtime-catalog.json'
import type { AbilityDefinition } from '../types/abilityTypes'
import { validateAbilityDefinitions } from '../compiler/validators/abilityDefinitionValidator'

type ReadyCatalog = { definitions?: Record<string, unknown> }
type PartialRuntimeCatalog = {
  cards?: Record<string, { status?: string; runtimeAbilities?: unknown }>
}

const normalize = (name: string) =>
  name
    .toLocaleLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '')

export const loadReadyRuntimeDefinitions = (
  catalog: ReadyCatalog = readyCatalog,
): ReadonlyMap<string, AbilityDefinition[]> => {
  const result = new Map<string, AbilityDefinition[]>()
  for (const [name, raw] of Object.entries(catalog.definitions ?? {})) {
    if (!Array.isArray(raw) || raw.length === 0) continue
    const validated = validateAbilityDefinitions(raw)
    if (
      validated.valid &&
      validated.value.every((ability) => ability.sourceCardName === name)
    )
      result.set(normalize(name), validated.value)
  }
  return result
}

export const loadRuntimeCatalogReadyDefinitions = (
  catalog: PartialRuntimeCatalog = runtimeCatalog,
): ReadonlyMap<string, AbilityDefinition[]> => {
  const result = new Map<string, AbilityDefinition[]>()
  for (const [name, entry] of Object.entries(catalog.cards ?? {})) {
    if (entry.status !== 'READY' || !Array.isArray(entry.runtimeAbilities))
      continue
    const validated = validateAbilityDefinitions(entry.runtimeAbilities)
    if (
      validated.valid &&
      validated.value.length > 0 &&
      validated.value.every((ability) => ability.sourceCardName === name)
    )
      result.set(normalize(name), validated.value)
  }
  return result
}

export const loadSupplementalPartialStaticDefinitions = (
  catalog: PartialRuntimeCatalog = runtimeCatalog,
): ReadonlyMap<string, AbilityDefinition[]> => {
  const result = new Map<string, AbilityDefinition[]>()
  for (const [name, entry] of Object.entries(catalog.cards ?? {})) {
    if (entry.status !== 'PARTIAL' || !Array.isArray(entry.runtimeAbilities))
      continue
    const staticOnly = entry.runtimeAbilities.filter(
      (ability) =>
        typeof ability === 'object' &&
        ability !== null &&
        'kind' in ability &&
        ability.kind === 'STATIC',
    )
    if (!staticOnly.length) continue
    const validated = validateAbilityDefinitions(staticOnly)
    if (
      validated.valid &&
      validated.value.every(
        (ability) =>
          ability.kind === 'STATIC' && ability.sourceCardName === name,
      )
    )
      result.set(normalize(name), validated.value)
  }
  return result
}

const supplementalPartialStaticDefinitions =
  loadSupplementalPartialStaticDefinitions()

export const getSupplementalPartialStaticDefinitions = (cardName: string) =>
  supplementalPartialStaticDefinitions.get(normalize(cardName))

const promotedReadyDefinitions = loadRuntimeCatalogReadyDefinitions()
const readyDefinitions = new Map<string, AbilityDefinition[]>(
  promotedReadyDefinitions,
)
for (const [name, abilities] of loadReadyRuntimeDefinitions())
  readyDefinitions.set(name, abilities)

export const getReadyRuntimeDefinitions = (cardName: string) =>
  readyDefinitions.get(normalize(cardName))

export const readyRuntimeDefinitionCount = readyDefinitions.size
