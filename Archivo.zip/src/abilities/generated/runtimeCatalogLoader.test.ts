import { describe, expect, it } from 'vitest'
import {
  getReadyRuntimeDefinitions,
  getSupplementalPartialStaticDefinitions,
  loadReadyRuntimeDefinitions,
  loadRuntimeCatalogReadyDefinitions,
  readyRuntimeDefinitionCount,
} from './runtimeCatalogLoader'
import readyCatalog from './tritones-runtime-ready-definitions.json'
import { getAbilitiesForCard } from '../definitions/abilityRegistry'
import type { CardDefinition } from '../../types/card'

const card = (name: string, oracleText = ''): CardDefinition => ({
  scryfallId: name,
  name,
  cmc: 0,
  typeLine: 'Artifact',
  colors: [],
  colorIdentity: [],
  oracleText,
})

describe('Tritones precompiled runtime catalog', () => {
  it('loads ready definitions through normalized lookup', () => {
    expect(readyRuntimeDefinitionCount).toBeGreaterThanOrEqual(
      loadReadyRuntimeDefinitions(readyCatalog).size,
    )
    expect(getReadyRuntimeDefinitions('merfolk looter')?.[0]?.kind).toBe(
      'ACTIVATED',
    )
  })

  it('wins over deterministic compilation without combining definitions', () => {
    const abilities = getAbilitiesForCard(
      card('Merfolk Looter', '{T}: Draw a card, then discard a card.'),
    )
    expect(abilities).toHaveLength(1)
    expect(abilities[0]?.id).toBe('tritones-merfolk-looter-loot')
  })

  it('keeps a missing card on the deterministic fallback', () => {
    expect(getAbilitiesForCard(card('Fallback', '{T}: Add {U}.'))[0]?.id).toBe(
      'compiled-tap-add-mana',
    )
  })

  it('rejects invalid definitions safely', () => {
    expect(
      loadReadyRuntimeDefinitions({
        definitions: { Broken: [{ kind: 'TRIGGERED' }] },
      }).size,
    ).toBe(0)
  })

  it('loads newly promoted READY cards from the strict runtime catalog', () => {
    expect(
      loadRuntimeCatalogReadyDefinitions().get('svyelunofseaandsky'),
    ).toHaveLength(3)
    expect(getReadyRuntimeDefinitions('Svyelun of Sea and Sky')).toHaveLength(3)
    expect(getReadyRuntimeDefinitions('Kopala, Warden of Waves')).toHaveLength(
      2,
    )
    expect(
      getSupplementalPartialStaticDefinitions('Svyelun of Sea and Sky'),
    ).toBeUndefined()
  })

  it('exposes only safe static sub-abilities from cards that remain PARTIAL', () => {
    expect(
      getSupplementalPartialStaticDefinitions('Cyclonic Rift'),
    ).toBeUndefined()
  })

  it('returns one precompiled source for Remora and Looter', () => {
    const remora = getReadyRuntimeDefinitions('Mystic Remora')
    expect(remora).toHaveLength(2)
    expect(remora?.find((ability) => ability.id === 'tritones-mystic-remora-cumulative-upkeep')).toMatchObject({
      trigger: { type: 'UPKEEP_STARTED' },
      conditions: [{ type: 'EVENT_ACTIVE_PLAYER_IS_SOURCE_CONTROLLER' }],
    })
    expect(getReadyRuntimeDefinitions('Merrow Commerce')?.[0]).toMatchObject({
      trigger: { type: 'END_STEP_STARTED' },
      conditions: [{ type: 'EVENT_ACTIVE_PLAYER_IS_SOURCE_CONTROLLER' }],
    })
    expect(getReadyRuntimeDefinitions('Merfolk Looter')).toHaveLength(1)
  })
})
