import type { GameAction } from '../../actions/gameActions'
import type { GameState } from '../../types/game'

export type AutomaticTurnStartAction = Extract<
  GameAction,
  { type: 'NEXT_TURN' | 'START_TURN' }
>

export type AutomaticTurnAdvanceResult = {
  state: GameState
  actions: GameAction[]
  stoppedForInteraction: boolean
}

/**
 * The game must pause whenever its current state requires a player response.
 * This derives from domain state; it never guesses that a player has passed.
 */
export const requiresPlayerInteraction = (state: GameState): boolean =>
  state.stack.length > 0 ||
  state.pendingAbilities.length > 0 ||
  state.pendingResolutions.length > 0 ||
  state.pendingDecisions.length > 0

const withBeginningAutoAdvancePaused = (
  state: GameState,
  paused: boolean,
): GameState =>
  state.autoAdvanceBeginningOfTurnPaused === paused
    ? state
    : { ...state, autoAdvanceBeginningOfTurnPaused: paused }

/**
 * Continues a beginning-of-turn auto-advance that previously stopped for a
 * real player interaction. This is intentionally separate from starting a new
 * turn: resolving an upkeep trigger must resume at the current step, not run
 * untap/upkeep again.
 */
export const resumeAutomaticBeginningOfTurn = ({
  state: initial,
  applyAction,
}: {
  state: GameState
  applyAction: (state: GameState, action: GameAction) => GameState
}): AutomaticTurnAdvanceResult => {
  if (!initial.autoAdvanceBeginningOfTurnPaused)
    return { state: initial, actions: [], stoppedForInteraction: false }
  if (requiresPlayerInteraction(initial))
    return { state: initial, actions: [], stoppedForInteraction: true }

  if (initial.turnState.step === 'MAIN_1')
    return {
      state: withBeginningAutoAdvancePaused(initial, false),
      actions: [],
      stoppedForInteraction: false,
    }

  if (
    initial.turnState.step !== 'UNTAP' &&
    initial.turnState.step !== 'UPKEEP' &&
    initial.turnState.step !== 'DRAW'
  )
    return {
      state: withBeginningAutoAdvancePaused(initial, false),
      actions: [],
      stoppedForInteraction: false,
    }

  let state = initial
  const actions: GameAction[] = []
  while (state.turnState.step !== 'MAIN_1') {
    state = applyAction(state, { type: 'ADVANCE_STEP' })
    actions.push({ type: 'ADVANCE_STEP' })
    if (requiresPlayerInteraction(state))
      return {
        state: withBeginningAutoAdvancePaused(state, true),
        actions,
        stoppedForInteraction: true,
      }
  }

  return {
    state: withBeginningAutoAdvancePaused(state, false),
    actions,
    stoppedForInteraction: false,
  }
}

/**
 * Runs only the beginning-of-turn bookkeeping steps. `applyAction` is supplied
 * by the store so each transition still derives events, triggers and SBAs.
 */
export const advanceUntilPlayerInteraction = ({
  state: initial,
  startAction,
  applyAction,
}: {
  state: GameState
  startAction: AutomaticTurnStartAction
  applyAction: (state: GameState, action: GameAction) => GameState
}): AutomaticTurnAdvanceResult => {
  if (requiresPlayerInteraction(initial))
    return { state: initial, actions: [], stoppedForInteraction: true }

  let state = applyAction(initial, startAction)
  const actions: GameAction[] = [startAction]
  if (requiresPlayerInteraction(state))
    return {
      state: withBeginningAutoAdvancePaused(state, true),
      actions,
      stoppedForInteraction: true,
    }

  while (state.turnState.step !== 'MAIN_1') {
    state = applyAction(state, { type: 'ADVANCE_STEP' })
    actions.push({ type: 'ADVANCE_STEP' })
    if (requiresPlayerInteraction(state))
      return {
        state: withBeginningAutoAdvancePaused(state, true),
        actions,
        stoppedForInteraction: true,
      }
  }
  return {
    state: withBeginningAutoAdvancePaused(state, false),
    actions,
    stoppedForInteraction: false,
  }
}
