import type { ManaColor, Zone } from '../../types/card'
import type { TurnStep } from '../../types/turn'

export type ActivatedAbilityHint = 'MANA' | 'CHANNEL' | 'EQUIP' | 'WATERBEND'

export type ParsedCommand =
  | { type: 'PLAY_CARD'; cardQuery: string }
  | { type: 'DECLARE_CARD'; cardQuery: string }
  | {
      type: 'CAST_SPELL'
      cardQuery: string
      targetQuery?: string
      /** Explicitly declared physical source for permissions such as casting from library top. */
      fromZone?: 'library'
      /** Explicit response language always suppresses implicit resolution. */
      inResponse?: true
    }
  | { type: 'DISCARD_CARD'; cardQuery?: string; amount: number; unknown?: true }
  | {
      type: 'ACTIVATE_ABILITY'
      cardQuery: string
      /** Optional exact public instance selected by a contextual/semantic slot. */
      instanceId?: string
      abilityHint?: ActivatedAbilityHint
      inResponse?: true
    }
  | {
      type: 'ACTIVATE_MANA'
      cardQuery: string
      /** Optional exact battlefield instance selected by a contextual/semantic slot. */
      instanceId?: string
      colorQuery?: string
    }
  | { type: 'RESOLVE_SPELL'; cardQuery?: string; instanceId?: string }
  | { type: 'TAP_CARD'; cardQuery: string; indexes?: number[]; count?: number }
  | {
      type: 'UNTAP_CARD'
      cardQuery: string
      indexes?: number[]
      count?: number
    }
  | { type: 'UNTAP_ALL' }
  | {
      type: 'MOVE_CARD'
      cardQuery: string
      destination: Zone
      index?: number
      /** Optional exact known instance selected by a contextual/semantic slot. */
      instanceId?: string
    }
  | { type: 'ADD_MANA'; colorQuery: string; amount: number }
  | { type: 'SPEND_MANA'; colorQuery: string; amount: number }
  | { type: 'GAIN_LIFE'; amount: number }
  | { type: 'LOSE_LIFE'; amount: number }
  | { type: 'SET_LIFE'; amount: number }
  | { type: 'SET_HAND_COUNT'; count: number }
  | { type: 'SET_LIBRARY_COUNT'; count: number }
  | { type: 'DRAW'; amount: number }
  | { type: 'START_TURN' }
  | { type: 'CONCEDE' }
  | {
      type: 'DECLARE_ATTACKERS'
      attackerQueries: string[]
      /** Optional exact public instances selected by semantic slots. */
      attackerInstanceIds?: string[]
      all?: true
      subtype?: string
      /** Optional known opposing planeswalker to attack instead of the player. */
      defenderQuery?: string
      /** Optional exact known defending planeswalker selected by V3. */
      defenderInstanceId?: string
      /** Explicit declaration of zero attackers. */
      none?: true
    }
  | { type: 'DECLARE_EXTERNAL_ATTACKER'; cardQuery: string }
  | {
      type: 'DECLARE_BLOCKERS'
      attackerQuery?: string
      /** Optional exact current attacker selected by V3. */
      attackerInstanceId?: string
      blockerQueries: string[]
      assignments?: Array<{ attackerQuery: string; blockerQuery: string }>
      /** Optional exact local blocker instances selected by V3. */
      blockerInstanceIds?: string[]
      none?: true
    }
  | { type: 'RESOLVE_COMBAT_DAMAGE' }
  | {
      type: 'DECLARE_ASSISTED_BLOCKER'
      attackerQuery: string
      power?: number
      toughness?: number
    }
  | { type: 'DECLARE_DAMAGE'; targetQuery: string; amount: number }
  | { type: 'NEXT_TURN' }
  | { type: 'ADVANCE_STEP'; targetStep?: TurnStep }
  | { type: 'COMBAT_ACTION' }
  | { type: 'DECLARE_PLAYER_SHUFFLED'; player: 'local' | 'opponent' }
  | { type: 'UNDO' }

export type CommandErrorCode =
  | 'UNKNOWN_COMMAND'
  | 'CARD_NOT_FOUND'
  | 'AMBIGUOUS_CARD'
  | 'NOT_ENOUGH_MATCHING_CARDS'
  | 'ALREADY_TAPPED'
  | 'ALREADY_UNTAPPED'
  | 'INVALID_AMOUNT'
  | 'NOT_ENOUGH_MANA'
  | 'CARD_NOT_IN_HAND'
  | 'AMBIGUOUS_TARGET'
  | 'LAND_PLAY_LIMIT_REACHED'
  | 'CARD_COPY_UNAVAILABLE'
  | 'AMBIGUOUS_MANA_PAYMENT'
  | 'SPELL_ALREADY_LEFT_STACK'
  | 'INVALID_TIMING'
  | 'CAST_RESTRICTED'
  | 'STACK_NOT_EMPTY'
  | 'NO_PRIORITY'
  | 'NOT_TOP_OF_STACK'
  | 'GAME_OVER'
  | 'COMBAT_NOT_IMPLEMENTED'
  | 'INVALID_ATTACKER'
  | 'INVALID_BLOCKER'
  | 'BLOCK_REQUIREMENT_NOT_MET'
  | 'SUMMONING_SICKNESS'
  | 'COMBAT_DAMAGE_COMPLETE'
  | 'ASSISTED_COMBAT_REQUIRED'

export type CommandError = { code: CommandErrorCode; message: string }

export type ParseResult =
  | { status: 'parsed'; command: ParsedCommand; normalized: string }
  | { status: 'error'; error: CommandError; normalized: string }

export type CardMatch =
  | { status: 'resolved'; name: string }
  | { status: 'ambiguous'; names: string[] }
  | { status: 'not_found' }

export type ResolvedCommand =
  | {
      status: 'resolved'
      actions: import('../../actions/gameActions').GameAction[]
      description: string
    }
  | { status: 'undo'; description: string }
  | { status: 'error'; error: CommandError }

export const manaColorAliases: Record<string, ManaColor> = {
  blanco: 'W',
  white: 'W',
  w: 'W',
  azul: 'U',
  blue: 'U',
  u: 'U',
  negro: 'B',
  black: 'B',
  b: 'B',
  rojo: 'R',
  red: 'R',
  r: 'R',
  verde: 'G',
  green: 'G',
  g: 'G',
  incoloro: 'C',
  colorless: 'C',
  c: 'C',
}
