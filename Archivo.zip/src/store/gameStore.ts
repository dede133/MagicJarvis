import { isCommanderInstance } from '../rules/commander/commanderRules'
import { create } from 'zustand'
import type { GameAction } from '../actions/gameActions'
import {
  applyGameAction,
  createInitialGameState,
  type ActionMetadata,
} from '../engine/gameEngine'
import type { GameState, StackResolutionMode } from '../types/game'
import type { CardDefinition, ManaColor } from '../types/card'
import type { PendingResolution } from '../abilities/types/abilityTypes'
import {
  advancePendingResolution,
  createPendingResolution,
  createSpellEffectResolution,
  createAsEntersResolution,
  createActivatedPendingAbility,
  evaluateAbilities,
  evaluateDelayedEffects,
} from '../abilities/engine/abilityEngine'
import { deriveGameEvents } from '../events/deriveGameEvents'
import { getAbilitiesForCard } from '../abilities/definitions/abilityRegistry'
import {
  castRestrictionViolation,
  effectiveAbilitiesForCard,
  entersBattlefieldTappedByStaticEffects,
  effectiveCreatureSubtypes,
} from '../abilities/engine/staticEffects'
import { targetingCosts } from '../rules/targeting/targetingRules'
import {
  declarationModeRequirement,
  declarationTargetRequirement,
  declaredModeVariableKey,
  declaredTargetCountVariableKey,
  declaredTargetCard,
  legalDeclarationTargetOptions,
} from '../rules/targeting/declarationTargets'
import {
  activationPermanentCostCandidates,
  activationWaterbendCostCandidates,
  resolveActivatedAbility,
} from '../abilities/engine/activationEngine'
import { checkStateBasedActions } from '../rules/stateBasedActions'
import { planReplacement } from '../rules/replacement/replacementCore'
import {
  advanceUntilPlayerInteraction,
  requiresPlayerInteraction,
  resumeAutomaticBeginningOfTurn,
} from '../rules/turn/autoAdvance'
import { cleanupDiscardDecision } from '../rules/turn/cleanup'
import { activePlayerIdOf, opponentPlayerIds } from '../rules/players/playerState'
import { planActivationManaPreparation } from '../rules/activation/activationPlanning'
import {
  createCombatDamageAssignmentDecision,
  planCombatDamage,
} from '../rules/combat/combatRules'
import { deckDefinitionForPlayer } from '../game/deckLookup'
import {
  resolveCommand,
  resolvePreparedCast,
  resolveFreeCastKnownCard,
  withNonManaCastCosts,
} from '../commands/resolver/resolveCommand'
import type { ParsedCommand } from '../commands/types/commandTypes'
import { resolveCardQuery } from '../commands/resolver/cardResolver'
import {
  shouldResolveTopBeforeCommand,
  requiresAttentionAfterImplicitResolution,
  type TabletopExecutionResult,
} from '../rules/implicitResolution/implicitResolution'

type GameStore = GameState & {
  undoStack: GameState[]
  dispatch: (action: GameAction) => void
  dispatchMany: (actions: GameAction[]) => void
  executeTabletopCommand: (command: ParsedCommand) => TabletopExecutionResult
  declareExternalSpell: (card: CardDefinition, manaSpent: number) => void
  setStackResolutionMode: (mode: StackResolutionMode) => void
  undoLastAction: () => void
  resolvePendingAbility: (pendingId: string) => void
  resolvePendingAbilityPayment: (
    pendingId: string,
    selection: 'PAID' | 'NOT_PAID',
  ) => void
  ignorePendingAbility: (pendingId: string) => void
  resolvePendingDecision: (
    decisionId: string,
    selection: 'YES' | 'NO' | string,
  ) => void
  resolvePendingDecisionWithExternalCard: (
    decisionId: string,
    card: CardDefinition,
  ) => void
  getCurrentGameState: () => GameState
  replaceGame: (game: GameState) => void
}

let actionSequence = 0
const createActionMetadata = (): ActionMetadata => ({
  actionId:
    globalThis.crypto?.randomUUID?.() ??
    `action-${Date.now()}-${++actionSequence}`,
  timestamp: Date.now(),
})

const cardMatchesCastCostColors = (
  card: GameState['cards'][number]['card'],
  colors: readonly ManaColor[] | undefined,
): boolean =>
  !colors?.length || colors.some((color) => card.colors.includes(color))

const deckEntryForCardName = (
  state: GameState,
  name: string,
  playerId = state.localPlayerId ?? 'player-1',
) => {
  const deck = deckDefinitionForPlayer(state, playerId)
  return (
    deck &&
    [deck.commander, ...deck.mainboard].find((entry) => entry.name === name)
  )
}

const activationVariableName = (
  ability: import('../abilities/types/abilityTypes').ActivatedAbilityDefinition,
): string | undefined => {
  for (const cost of ability.costs) {
    if (cost.type === 'WATERBEND' && cost.amount.type === 'VARIABLE')
      return cost.amount.name
    if (cost.type !== 'MANA_COST') continue
    const match = /\{([A-Z])\}/.exec(cost.cost)
    if (match?.[1] === 'X') return 'X'
  }
  return undefined
}

const legalActivationVariableValues = (
  state: GameState,
  sourceInstanceId: string,
  ability: import('../abilities/types/abilityTypes').ActivatedAbilityDefinition,
  variableName: string,
): number[] => {
  const manaUpperBound = Object.values(state.manaPool).reduce(
    (total, amount) => total + amount,
    0,
  )
  const waterbendCandidates = activationWaterbendCostCandidates(
    state,
    sourceInstanceId,
  )
  const upperBound = manaUpperBound + waterbendCandidates.length
  const sacrificeCandidate = activationPermanentCostCandidates(
    state,
    sourceInstanceId,
    ability,
  )[0]
  return Array.from({ length: upperBound + 1 }, (_, value) => value).filter(
    (value) => {
      const waterbend = ability.costs.find((cost) => cost.type === 'WATERBEND')
      if (waterbend) {
        const counts = Array.from(
          { length: Math.min(value, waterbendCandidates.length) + 1 },
          (_, count) => count,
        )
        return counts.some(
          (count) =>
            resolveActivatedAbility(
              state,
              sourceInstanceId,
              ability,
              { [variableName]: value },
              waterbendCandidates
                .slice(0, count)
                .map((card) => card.instanceId),
            ).ok,
        )
      }
      return resolveActivatedAbility(
        state,
        sourceInstanceId,
        ability,
        { [variableName]: value },
        sacrificeCandidate ? [sacrificeCandidate.instanceId] : [],
      ).ok
    },
  )
}

const activationCostDecision = (
  state: GameState,
  source: GameState['cards'][number],
  ability: import('../abilities/types/abilityTypes').ActivatedAbilityDefinition,
  variables: Record<string, string | number | boolean> = {},
  declaredTargets: import('../abilities/types/abilityTypes').DeclaredTarget[] = [],
): import('../abilities/types/abilityTypes').PendingDecision | undefined => {
  const waterbend = ability.costs.find((item) => item.type === 'WATERBEND')
  if (waterbend && waterbend.type === 'WATERBEND') {
    const requiredAmount =
      waterbend.amount.type === 'LITERAL'
        ? waterbend.amount.value
        : waterbend.amount.type === 'VARIABLE' &&
            typeof variables[waterbend.amount.name] === 'number'
          ? Number(variables[waterbend.amount.name])
          : 0
    const candidates = activationWaterbendCostCandidates(
      state,
      source.instanceId,
    )
    const legalCounts = Array.from(
      { length: Math.min(requiredAmount, candidates.length) + 1 },
      (_, count) => count,
    ).filter(
      (count) =>
        resolveActivatedAbility(
          state,
          source.instanceId,
          ability,
          variables,
          candidates.slice(0, count).map((card) => card.instanceId),
          additionalDeclaredActivationTargetCost(
            state,
            source,
            declaredTargets,
          ),
        ).ok,
    )
    if (!legalCounts.length) return undefined
    return {
      id: `decision-activation-waterbend-count-${source.instanceId}-${ability.id}`,
      sourceAbilityId: ability.id,
      sourceInstanceId: source.instanceId,
      decisionPlayerId: source.controllerId ?? state.localPlayerId,
      type: 'ACTIVATION_WATERBEND_COUNT',
      prompt: `Waterbend ${requiredAmount}: ¿cuántos artefactos o criaturas quieres girar?`,
      options: legalCounts.map((count) => ({
        instanceId: String(count),
        label: String(count),
      })),
      continuation: {
        effectsToExecute: [],
        resumeEffectIndex: 0,
        activationWaterbend: {
          sourceInstanceId: source.instanceId,
          abilityId: ability.id,
          variables,
          declaredTargets: [...declaredTargets],
          requiredAmount,
          selectedIds: [],
        },
      },
    }
  }
  const cost = ability.costs.find((item) => item.type === 'SACRIFICE_PERMANENT')
  if (!cost || cost.type !== 'SACRIFICE_PERMANENT') return undefined
  const candidates = activationPermanentCostCandidates(
    state,
    source.instanceId,
    ability,
  )
  if (!candidates.length) return undefined
  return {
    id: `decision-activation-cost-${source.instanceId}-${ability.id}`,
    sourceAbilityId: ability.id,
    sourceInstanceId: source.instanceId,
    decisionPlayerId: source.controllerId ?? state.localPlayerId,
    type: 'ACTIVATION_COST_PERMANENT_SELECTION',
    prompt: cost.prompt,
    options: candidates.map((card) => ({
      instanceId: card.instanceId,
      label: card.card.name,
    })),
    constraints: cost.constraints,
    continuation: {
      effectsToExecute: [],
      resumeEffectIndex: 0,
      activationCostSelection: {
        sourceInstanceId: source.instanceId,
        abilityId: ability.id,
        constraints: cost.constraints,
        variables,
        declaredTargets: [...declaredTargets],
      },
    },
  }
}

const declaredCastCostCard = (
  state: GameState,
  decision: NonNullable<GameState['pendingDecisions'][number]>,
  selection: string,
):
  | { instanceId: string; scryfallId: string; materialize: boolean }
  | undefined => {
  const cost = decision.continuation.castCardCost
  if (!cost) return undefined
  const selectedIds = new Set(cost.selected.map((item) => item.instanceId))
  const known = state.cards.find(
    (card) =>
      card.instanceId === selection &&
      card.zone === 'hand' &&
      !selectedIds.has(card.instanceId),
  )
  if (known) {
    if (
      known.instanceId === cost.excludeSourceInstanceId ||
      !cardMatchesCastCostColors(known.card, cost.colors)
    )
      return undefined
    return {
      instanceId: known.instanceId,
      scryfallId: known.card.scryfallId,
      materialize: false,
    }
  }
  const playerId =
    decision.decisionPlayerId ?? state.localPlayerId ?? 'player-1'
  const deck = deckDefinitionForPlayer(state, playerId)
  if (!deck) return undefined
  const match = resolveCardQuery(deck, selection)
  if (match.status !== 'resolved') return undefined
  const entry = deckEntryForCardName(state, match.name, playerId)
  if (!entry || !cardMatchesCastCostColors(entry.card, cost.colors))
    return undefined
  const knownHand = state.cards.find(
    (card) =>
      card.zone === 'hand' &&
      card.card.scryfallId === entry.card.scryfallId &&
      card.instanceId !== cost.excludeSourceInstanceId &&
      !selectedIds.has(card.instanceId),
  )
  if (knownHand)
    return {
      instanceId: knownHand.instanceId,
      scryfallId: knownHand.card.scryfallId,
      materialize: false,
    }

  const inventory = [deck.commander, ...deck.mainboard].find(
    (candidate) => candidate.card.scryfallId === entry.card.scryfallId,
  )
  if (!inventory) return undefined
  const knownCount = state.cards.filter(
    (card) =>
      card.card.scryfallId === entry.card.scryfallId &&
      (card.ownerId ?? state.localPlayerId) === playerId,
  ).length
  const reservedHidden = cost.selected.filter(
    (item) => item.materialize && item.scryfallId === entry.card.scryfallId,
  ).length
  const sourceReserved =
    entry.card.scryfallId === cost.sourceScryfallId &&
    !state.cards.some((card) => card.instanceId === decision.sourceInstanceId)
      ? 1
      : 0
  if (knownCount + reservedHidden + sourceReserved >= inventory.quantity)
    return undefined
  const instanceId = `known-${entry.card.scryfallId}-${knownCount + reservedHidden + sourceReserved + 1}`
  return { instanceId, scryfallId: entry.card.scryfallId, materialize: true }
}

const knownCastCostOptions = (
  state: GameState,
  decision: GameState['pendingDecisions'][number],
) => {
  const cost = decision.continuation.castCardCost
  if (!cost) return []
  const selectedIds = new Set(cost.selected.map((item) => item.instanceId))
  return state.cards
    .filter(
      (card) =>
        card.zone === 'hand' &&
        card.instanceId !== cost.excludeSourceInstanceId &&
        !selectedIds.has(card.instanceId) &&
        cardMatchesCastCostColors(card.card, cost.colors),
    )
    .map((card) => ({ instanceId: card.instanceId, label: card.card.name }))
}

const cardMatchesSearchConstraints = (
  card: GameState['cards'][number]['card'],
  constraints: import('../abilities/types/abilityTypes').SelectionConstraints,
): boolean => {
  const typeLine = card.typeLine.toLocaleLowerCase()
  if (
    constraints.cardTypes?.some(
      (type) => !typeLine.includes(type.toLocaleLowerCase()),
    )
  )
    return false
  if (
    constraints.cardTypesAnyOf?.length &&
    !constraints.cardTypesAnyOf.some((type) =>
      typeLine.includes(type.toLocaleLowerCase()),
    )
  )
    return false
  if (
    constraints.excludeCardTypes?.some((type) =>
      typeLine.includes(type.toLocaleLowerCase()),
    )
  )
    return false
  if (
    constraints.subtypes?.some(
      (subtype) => !typeLine.includes(subtype.toLocaleLowerCase()),
    )
  )
    return false
  if (
    constraints.subtypesAnyOf?.length &&
    !constraints.subtypesAnyOf.some((subtype) =>
      typeLine.includes(subtype.toLocaleLowerCase()),
    )
  )
    return false
  if (constraints.historic !== undefined) {
    const historic = /\bartifact\b|\blegendary\b|\bsaga\b/i.test(typeLine)
    if (historic !== constraints.historic) return false
  }
  if (
    constraints.colors?.some((color) => !card.colors.includes(color)) ||
    constraints.excludeColors?.some((color) => card.colors.includes(color))
  )
    return false
  return true
}

const declaredLibrarySearchCard = (
  state: GameState,
  decision: GameState['pendingDecisions'][number],
  selection: string,
):
  | {
      instanceId: string
      card: GameState['cards'][number]['card']
      materialize: boolean
    }
  | undefined => {
  const search = decision.continuation.librarySearch
  if (!search) return undefined
  const searchedPlayerId =
    search.playerId ??
    decision.decisionPlayerId ??
    state.localPlayerId ??
    'player-1'
  const known = state.cards.find(
    (card) =>
      card.instanceId === selection &&
      card.zone === 'library' &&
      (card.ownerId ?? state.localPlayerId) === searchedPlayerId,
  )
  if (known && cardMatchesSearchConstraints(known.card, search.constraints))
    return {
      instanceId: known.instanceId,
      card: known.card,
      materialize: false,
    }
  const deck = deckDefinitionForPlayer(state, searchedPlayerId)
  if (!deck) return undefined
  const match = resolveCardQuery(deck, selection)
  if (match.status !== 'resolved') return undefined
  const entry = deckEntryForCardName(state, match.name, searchedPlayerId)
  if (!entry || !cardMatchesSearchConstraints(entry.card, search.constraints))
    return undefined
  const knownLibrary = state.cards.find(
    (card) =>
      card.zone === 'library' &&
      card.card.scryfallId === entry.card.scryfallId &&
      (card.ownerId ?? state.localPlayerId) === searchedPlayerId,
  )
  if (knownLibrary)
    return {
      instanceId: knownLibrary.instanceId,
      card: knownLibrary.card,
      materialize: false,
    }
  const knownCount = state.cards.filter(
    (card) =>
      card.card.scryfallId === entry.card.scryfallId &&
      (card.ownerId ?? state.localPlayerId) === searchedPlayerId,
  ).length
  if (knownCount >= entry.quantity) return undefined
  return {
    instanceId: `known-search-${entry.card.scryfallId}-${knownCount + 1}`,
    card: entry.card,
    materialize: true,
  }
}

const declaredHiddenZoneCard = (
  state: GameState,
  decision: GameState['pendingDecisions'][number],
  selection: string,
):
  | {
      instanceId: string
      scryfallId: string
      card: GameState['cards'][number]['card']
      materialize: boolean
    }
  | undefined => {
  const hidden = decision.continuation.hiddenZoneSelection
  if (!hidden || hidden.player !== 'SOURCE_CONTROLLER') return undefined
  const selectedIds = new Set(hidden.selected.map((item) => item.instanceId))
  const playerId =
    decision.decisionPlayerId ?? state.localPlayerId ?? 'player-1'
  const known = state.cards.find(
    (card) =>
      card.instanceId === selection &&
      card.zone === hidden.zone &&
      (card.ownerId ?? state.localPlayerId) === playerId &&
      !selectedIds.has(card.instanceId),
  )
  if (known && cardMatchesSearchConstraints(known.card, hidden.constraints))
    return {
      instanceId: known.instanceId,
      scryfallId: known.card.scryfallId,
      card: known.card,
      materialize: false,
    }
  const deck = deckDefinitionForPlayer(state, playerId)
  if (!deck) return undefined
  const match = resolveCardQuery(deck, selection)
  if (match.status !== 'resolved') return undefined
  const entry = deckEntryForCardName(state, match.name, playerId)
  if (!entry || !cardMatchesSearchConstraints(entry.card, hidden.constraints))
    return undefined
  const knownZone = state.cards.find(
    (card) =>
      card.zone === hidden.zone &&
      card.card.scryfallId === entry.card.scryfallId &&
      (card.ownerId ?? state.localPlayerId) === playerId &&
      !selectedIds.has(card.instanceId),
  )
  if (knownZone)
    return {
      instanceId: knownZone.instanceId,
      scryfallId: knownZone.card.scryfallId,
      card: knownZone.card,
      materialize: false,
    }
  const knownCount = state.cards.filter(
    (card) =>
      card.card.scryfallId === entry.card.scryfallId &&
      (card.ownerId ?? state.localPlayerId) === playerId,
  ).length
  const reserved = hidden.selected.filter(
    (item) => item.materialize && item.scryfallId === entry.card.scryfallId,
  ).length
  if (knownCount + reserved >= entry.quantity) return undefined
  return {
    instanceId: `known-hidden-${hidden.zone}-${entry.card.scryfallId}-${knownCount + reserved + 1}`,
    scryfallId: entry.card.scryfallId,
    card: entry.card,
    materialize: true,
  }
}

const knownHiddenZoneOptions = (
  state: GameState,
  decision: GameState['pendingDecisions'][number],
) => {
  const hidden = decision.continuation.hiddenZoneSelection
  if (!hidden) return []
  const selectedIds = new Set(hidden.selected.map((item) => item.instanceId))
  const playerId =
    decision.decisionPlayerId ?? state.localPlayerId ?? 'player-1'
  return state.cards
    .filter(
      (card) =>
        card.zone === hidden.zone &&
        (card.ownerId ?? state.localPlayerId) === playerId &&
        !selectedIds.has(card.instanceId) &&
        cardMatchesSearchConstraints(card.card, hidden.constraints),
    )
    .map((card) => ({ instanceId: card.instanceId, label: card.card.name }))
}

const toGameState = (state: GameStore): GameState => ({
  localPlayerId: state.localPlayerId,
  playerState: state.playerState,
  players: state.players,
  activePlayerId: state.activePlayerId,
  turnOrder: state.turnOrder,
  life: state.life,
  turn: state.turn,
  activePlayer: state.activePlayer,
  turnState: state.turnState,
  autoAdvanceBeginningOfTurnPaused:
    state.autoAdvanceBeginningOfTurnPaused ?? false,
  gameStatus: state.gameStatus,
  gameLossReason: state.gameLossReason,
  manaPool: state.manaPool,
  autoManaMode: state.autoManaMode,
  stackResolutionMode: state.stackResolutionMode,
  hiddenZoneTracking: state.hiddenZoneTracking,
  libraryCount: state.libraryCount,
  handCount: state.handCount,
  knownLibraryTopInstanceId: state.knownLibraryTopInstanceId,
  maxHandSizeOverride: state.maxHandSizeOverride,
  landPlaysUsedThisTurn: state.landPlaysUsedThisTurn,
  landPlayLimit: state.landPlayLimit,
  failedDrawFromEmptyLibrary: state.failedDrawFromEmptyLibrary,
  commanderCastsFromCommandZone: state.commanderCastsFromCommandZone,
  commanderDamageReceivedBySource: state.commanderDamageReceivedBySource,
  commanderDamageByPlayer: state.commanderDamageByPlayer,
  opponentLife: state.opponentLife,
  combatState: state.combatState,
  damageRecords: state.damageRecords,
  commanderZoneChoiceAcknowledged: state.commanderZoneChoiceAcknowledged,
  commanderReplacementChoiceAcknowledged:
    state.commanderReplacementChoiceAcknowledged,
  cards: state.cards,
  stack: state.stack,
  deckDefinition: state.deckDefinition,
  deckDefinitionsByPlayer: state.deckDefinitionsByPlayer,
  commanderIds: state.commanderIds,
  commanderId: state.commanderId,
  commanderIdsByPlayer: state.commanderIdsByPlayer,
  pendingAbilities: state.pendingAbilities,
  pendingResolutions: state.pendingResolutions,
  pendingDecisions: state.pendingDecisions,
  delayedEffects: state.delayedEffects ?? [],
  linkedObjectGroups: state.linkedObjectGroups ?? [],
  temporaryContinuousEffects: state.temporaryContinuousEffects ?? [],
  temporaryCharacteristicEffects: state.temporaryCharacteristicEffects ?? [],
  temporaryProtectionEffects: state.temporaryProtectionEffects ?? [],
  untapRestrictions: state.untapRestrictions ?? [],
  typeContinuousEffects: state.typeContinuousEffects ?? [],
  playerControlEffects: state.playerControlEffects ?? [],
  copyContinuousEffects: state.copyContinuousEffects ?? [],
  perTurnEventMarkers: state.perTurnEventMarkers ?? {},
  extraTurnsQueued: state.extraTurnsQueued ?? 0,
  extraTurnQueue: state.extraTurnQueue ?? [],
  pendingCombatPhaseSkipsByPlayer: state.pendingCombatPhaseSkipsByPlayer ?? {},
  skipCombatPhasesThisTurnForPlayerId:
    state.skipCombatPhasesThisTurnForPlayerId,
  spellsCastThisTurn: state.spellsCastThisTurn ?? 0,
  spellsCastThisTurnByPlayer: state.spellsCastThisTurnByPlayer ?? {},
  spellCastHistoryThisTurn: state.spellCastHistoryThisTurn ?? [],
  cardsDrawnThisTurnByPlayer: state.cardsDrawnThisTurnByPlayer ?? {},
  permanentsEnteredThisTurn: state.permanentsEnteredThisTurn ?? [],
  creaturesAttackedThisTurnByPlayer:
    state.creaturesAttackedThisTurnByPlayer ?? {},
  triggeredAbilityTurnMarkers: state.triggeredAbilityTurnMarkers ?? {},
  temporaryBlockingRestrictions: state.temporaryBlockingRestrictions ?? [],
  attackRequirements: state.attackRequirements ?? [],
  blockRequirements: state.blockRequirements ?? [],
  history: state.history,
})

const genericManaFromCost = (cost: string): number | undefined => {
  const symbols = [...cost.matchAll(/\{([^}]+)\}/g)].map((match) => match[1])
  let total = 0
  for (const symbol of symbols) {
    if (!/^\d+$/.test(symbol)) return undefined
    total += Number(symbol)
  }
  return total
}

const targetingPaymentEffects = (
  state: GameState,
  resolution: GameState['pendingResolutions'][number],
  selectedInstanceId: string,
  effects: import('../abilities/types/abilityTypes').ResolvedEffect[],
): import('../abilities/types/abilityTypes').ResolvedEffect[] => {
  const target = state.cards.find(
    (card) =>
      card.instanceId === selectedInstanceId && card.zone === 'battlefield',
  )
  if (!target) return effects
  const source = state.cards.find(
    (card) => card.instanceId === resolution.context.sourceInstanceId,
  )
  const sourceControllerId =
    source?.controllerId ?? state.localPlayerId ?? 'player-1'
  const stackObject = state.stack.find(
    (object) => object.sourceInstanceId === resolution.context.sourceInstanceId,
  )
  const kind = stackObject?.kind ?? ('SPELL' as const)
  const costs = targetingCosts(state, target, {
    sourceInstanceId: resolution.context.sourceInstanceId,
    controllerId: sourceControllerId,
    kind,
  })
  const ward = costs.wardCosts
    .map(genericManaFromCost)
    .filter((amount): amount is number => amount !== undefined)
    .reduce((sum, amount) => sum + amount, 0)

  // Kopala-style taxes and ward are deliberately separate choices.  The
  // current declarative runtime still declares some targets while resolving,
  // so the exact cast/activation timing of the additional cost remains
  // assisted, but the amount and the consequence are no longer conflated.
  let branch = effects
  if (ward > 0)
    branch = [
      {
        type: 'PAYMENT_BRANCH',
        payer: 'SOURCE_CONTROLLER',
        cost: { type: 'FIXED_MANA', cost: `{${ward}}` },
        ifPaid: branch,
        ifNotPaid: [{ type: 'COUNTER_SOURCE_STACK_OBJECT' }],
        prompt: `Ward {${ward}}: paga el coste o el hechizo/habilidad no afectará a este objetivo.`,
      },
    ]
  if (costs.additionalGeneric > 0)
    branch = [
      {
        type: 'PAYMENT_BRANCH',
        payer: 'SOURCE_CONTROLLER',
        cost: {
          type: 'FIXED_MANA',
          cost: `{${costs.additionalGeneric}}`,
        },
        ifPaid: branch,
        ifNotPaid: [{ type: 'COUNTER_SOURCE_STACK_OBJECT' }],
        prompt: `Paga {${costs.additionalGeneric}} de coste adicional por hacer objetivo.`,
      },
    ]
  return branch
}

const wardPendingAbilitiesForStackObject = (
  state: GameState,
  stackObject: GameState['stack'][number],
): import('../abilities/types/abilityTypes').PendingAbility[] => {
  if (
    stackObject.kind !== 'SPELL' &&
    stackObject.kind !== 'ACTIVATED_ABILITY' &&
    stackObject.kind !== 'TRIGGERED_ABILITY'
  )
    return []
  const controllerId =
    stackObject.controllerId ??
    (stackObject.controller === 'YOU'
      ? (state.localPlayerId ?? 'player-1')
      : (state.turnOrder.find((id) => id !== state.localPlayerId) ??
        'player-2'))
  return (stackObject.declaredTargets ?? []).flatMap(
    (declared, targetIndex) => {
      const target = declaredTargetCard(state, declared)
      if (!target || target.zone !== 'battlefield') return []
      const wardControllerId =
        target.controllerId ??
        (target.controller === 'OPPONENT'
          ? (state.turnOrder.find((id) => id !== state.localPlayerId) ??
            'player-2')
          : (state.localPlayerId ?? 'player-1'))
      return targetingCosts(state, target, {
        sourceInstanceId: stackObject.sourceInstanceId,
        controllerId,
        kind: stackObject.kind,
      }).wardCosts.flatMap((cost, wardIndex) => {
        const amount = genericManaFromCost(cost)
        if (amount === undefined) return []
        return [
          {
            id: `ward-${stackObject.stackObjectId}-${targetIndex}-${wardIndex}`,
            abilityId: `ward-${target.instanceId}-${wardIndex}`,
            sourceInstanceId: stackObject.sourceInstanceId,
            sourceCardName: `${target.card.name} — Ward`,
            controllerId: wardControllerId,
            createdFromEvent: { type: 'ABILITY_ACTIVATED' as const },
            resolvedEffects: [
              {
                type: 'PAYMENT_BRANCH' as const,
                payer: 'SOURCE_CONTROLLER' as const,
                cost: { type: 'FIXED_MANA' as const, cost },
                prompt: `Ward ${cost}: paga el coste o el hechizo/habilidad será contrarrestado.`,
                ifPaid: [],
                ifNotPaid: [
                  {
                    type: 'COUNTER_STACK_OBJECT' as const,
                    stackObjectId: stackObject.stackObjectId,
                  },
                ],
              },
            ],
            automation: 'ASSISTED' as const,
          },
        ]
      })
    },
  )
}

const applyActivatedAbilityExecution = (
  state: GameState,
  source: GameState['cards'][number],
  ability: import('../abilities/types/abilityTypes').ActivatedAbilityDefinition,
  activation: Extract<ReturnType<typeof resolveActivatedAbility>, { ok: true }>,
  variables: Record<string, string | number | boolean> = {},
  prefixActions: GameAction[] = [],
  declaredTargets: import('../abilities/types/abilityTypes').DeclaredTarget[] = [],
): GameState => {
  const controllerId = source.controllerId ?? state.localPlayerId ?? 'player-1'
  const controller =
    controllerId === state.localPlayerId
      ? ('YOU' as const)
      : ('OPPONENT' as const)
  const activationAction: GameAction = {
    type: 'ACTIVATE_ABILITY',
    instanceId: source.instanceId,
    abilityId: ability.id,
    actorPlayerId: controllerId,
  }
  const next = applyActionsWithEvents(state, [
    ...prefixActions,
    activationAction,
    ...activation.costActions,
  ])
  const pending = createActivatedPendingAbility(
    source,
    ability,
    variables,
    declaredTargets,
  )
  if (!ability.isManaAbility)
    return applyActionsWithEvents(next, [
      { type: 'ADD_PENDING_ABILITIES', pending: [pending] },
      {
        type: 'ADD_STACK_OBJECT',
        stackObject: {
          stackObjectId: `activated-stack-${pending.id}`,
          kind: 'ACTIVATED_ABILITY',
          controller,
          controllerId,
          sourceInstanceId: source.instanceId,
          pendingAbilityId: pending.id,
          targets: declaredTargets.map((target) => target.targetId),
          ...(declaredTargets.length
            ? {
                declaredTargets: declaredTargets.map((target) => ({
                  ...target,
                })),
              }
            : {}),
          order: next.stack.length + 1,
        },
      },
    ])

  const resolution = createPendingResolution(pending)
  const step = advancePendingResolution(next, resolution)
  if (step.type === 'ACTIONS')
    return applyActionsWithEvents(next, [
      ...step.actions,
      ...(step.resolution.completionActions ?? []),
    ])
  if (step.type === 'COMPLETE')
    return applyActionsWithEvents(next, step.resolution.completionActions ?? [])
  if (step.type === 'DECISION')
    return applyActionsWithEvents(next, [
      ...step.actions,
      { type: 'ADD_PENDING_RESOLUTION', resolution: step.resolution },
      { type: 'ADD_PENDING_DECISION', decision: step.decision },
    ])
  return next
}

const additionalDeclaredActivationTargetCost = (
  state: GameState,
  source: GameState['cards'][number],
  declaredTargets: readonly import('../abilities/types/abilityTypes').DeclaredTarget[],
): number => {
  const controllerId = source.controllerId ?? state.localPlayerId ?? 'player-1'
  return declaredTargets.reduce((sum, declared) => {
    const target = declaredTargetCard(state, declared)
    if (!target) return sum
    return (
      sum +
      targetingCosts(state, target, {
        sourceInstanceId: source.instanceId,
        controllerId,
        kind: 'ACTIVATED_ABILITY',
      }).additionalGeneric
    )
  }, 0)
}

const activationModeDecision = (
  state: GameState,
  source: GameState['cards'][number],
  ability: import('../abilities/types/abilityTypes').ActivatedAbilityDefinition,
  variables: Record<string, string | number | boolean> = {},
  declaredTargets: import('../abilities/types/abilityTypes').DeclaredTarget[] = [],
): import('../abilities/types/abilityTypes').PendingDecision | undefined => {
  const requirement = declarationModeRequirement(ability)
  if (!requirement) return undefined
  const key = declaredModeVariableKey(ability.id)
  if (typeof variables[key] === 'string') return undefined
  const controllerId = source.controllerId ?? state.localPlayerId ?? 'player-1'
  return {
    id: `decision-activation-mode-${source.instanceId}-${ability.id}`,
    sourceAbilityId: ability.id,
    sourceInstanceId: source.instanceId,
    decisionPlayerId: controllerId,
    type: 'ACTIVATION_MODE_SELECTION',
    prompt: requirement.prompt,
    options: requirement.modes.map((mode) => ({
      instanceId: mode.id,
      label: mode.label,
    })),
    continuation: {
      effectsToExecute: [],
      resumeEffectIndex: 0,
      activationModeDeclaration: {
        sourceInstanceId: source.instanceId,
        abilityId: ability.id,
        variables,
        modes: requirement.modes,
        declaredTargets: [...declaredTargets],
      },
    },
  }
}

const activationTargetDecision = (
  state: GameState,
  source: GameState['cards'][number],
  ability: import('../abilities/types/abilityTypes').ActivatedAbilityDefinition,
  variables: Record<string, string | number | boolean> = {},
  selectedTargets: import('../abilities/types/abilityTypes').DeclaredTarget[] = [],
): import('../abilities/types/abilityTypes').PendingDecision | undefined => {
  const requirement = declarationTargetRequirement(ability, variables)
  if (!requirement || requirement.requiredCount === 0) return undefined
  if (selectedTargets.length >= requirement.requiredCount) return undefined
  const controllerId = source.controllerId ?? state.localPlayerId ?? 'player-1'
  const options = legalDeclarationTargetOptions(
    state,
    {
      sourceInstanceId: source.instanceId,
      sourceCard: source.card,
      controllerId,
      kind: 'ACTIVATED_ABILITY',
    },
    requirement.constraints,
  ).filter((option) => {
    if (selectedTargets.some((target) => target.targetId === option.instanceId))
      return false
    if (
      requirement.constraints.sharesCreatureSubtypeWithFirstTarget &&
      selectedTargets.length > 0
    ) {
      const first = state.cards.find(
        (card) => card.instanceId === selectedTargets[0].targetId,
      )
      const candidate = state.cards.find(
        (card) => card.instanceId === option.instanceId,
      )
      if (!first || !candidate) return false
      const firstSubtypes = new Set(effectiveCreatureSubtypes(state, first))
      if (
        !effectiveCreatureSubtypes(state, candidate).some((subtype) =>
          firstSubtypes.has(subtype),
        )
      )
        return false
    }
    return true
  })
  const missing = requirement.requiredCount - selectedTargets.length
  if (options.length < missing) return undefined
  return {
    id: `decision-activation-target-${source.instanceId}-${ability.id}-${selectedTargets.length + 1}`,
    sourceAbilityId: ability.id,
    sourceInstanceId: source.instanceId,
    decisionPlayerId: controllerId,
    type: 'ACTIVATION_TARGET_SELECTION',
    prompt: requirement.prompt,
    options,
    constraints: requirement.constraints,
    continuation: {
      effectsToExecute: [],
      resumeEffectIndex: 0,
      activationTargetDeclaration: {
        sourceInstanceId: source.instanceId,
        abilityId: ability.id,
        variables,
        prompt: requirement.prompt,
        constraints: requirement.constraints,
        requiredCount: requirement.requiredCount,
        selectedTargets: [...selectedTargets],
      },
    },
  }
}

const executeActivatedAbilityWithSmartMana = (
  state: GameState,
  source: GameState['cards'][number],
  ability: import('../abilities/types/abilityTypes').ActivatedAbilityDefinition,
  variables: Record<string, string | number | boolean> = {},
  selectedCostInstanceIds: string[] = [],
  prefixActions: GameAction[] = [],
  declaredTargets: import('../abilities/types/abilityTypes').DeclaredTarget[] = [],
): GameState => {
  const additionalGenericCost = additionalDeclaredActivationTargetCost(
    state,
    source,
    declaredTargets,
  )
  let activation = resolveActivatedAbility(
    state,
    source.instanceId,
    ability,
    variables,
    selectedCostInstanceIds,
    additionalGenericCost,
  )
  if (activation.ok)
    return applyActivatedAbilityExecution(
      state,
      source,
      ability,
      activation,
      variables,
      prefixActions,
      declaredTargets,
    )
  if (activation.code !== 'NOT_ENOUGH_MANA') return state

  const mana = planActivationManaPreparation({
    state,
    source,
    ability,
    variables,
    additionalGenericCost,
  })
  if (mana.kind !== 'AUTO_PLAN') return state

  const prepared = applyActionsWithEvents(state, mana.actions)
  const preparedSource = prepared.cards.find(
    (card) => card.instanceId === source.instanceId,
  )
  if (!preparedSource) return state
  activation = resolveActivatedAbility(
    prepared,
    preparedSource.instanceId,
    ability,
    variables,
    selectedCostInstanceIds,
    additionalDeclaredActivationTargetCost(
      prepared,
      preparedSource,
      declaredTargets,
    ),
  )
  if (!activation.ok) return state

  return applyActivatedAbilityExecution(
    state,
    source,
    ability,
    activation,
    variables,
    [...prefixActions, ...mana.actions],
    declaredTargets,
  )
}

const beginActivatedAbilityDeclaration = (
  state: GameState,
  source: GameState['cards'][number],
  ability: import('../abilities/types/abilityTypes').ActivatedAbilityDefinition,
  variables: Record<string, string | number | boolean> = {},
  prefixActions: GameAction[] = [],
  declaredTargets: import('../abilities/types/abilityTypes').DeclaredTarget[] = [],
): GameState => {
  const modeDecision = activationModeDecision(
    state,
    source,
    ability,
    variables,
    declaredTargets,
  )
  if (modeDecision)
    return applyActionsWithEvents(state, [
      ...prefixActions,
      { type: 'ADD_PENDING_DECISION', decision: modeDecision },
    ])
  const targetRequirement = declarationTargetRequirement(ability, variables)
  if (
    targetRequirement &&
    declaredTargets.length < targetRequirement.requiredCount
  ) {
    const targetDecision = activationTargetDecision(
      state,
      source,
      ability,
      variables,
      declaredTargets,
    )
    if (!targetDecision) return state
    return applyActionsWithEvents(state, [
      ...prefixActions,
      { type: 'ADD_PENDING_DECISION', decision: targetDecision },
    ])
  }
  const costDecision = activationCostDecision(
    state,
    source,
    ability,
    variables,
    declaredTargets,
  )
  if (costDecision)
    return applyActionsWithEvents(state, [
      ...prefixActions,
      { type: 'ADD_PENDING_DECISION', decision: costDecision },
    ])
  return executeActivatedAbilityWithSmartMana(
    state,
    source,
    ability,
    variables,
    [],
    prefixActions,
    declaredTargets,
  )
}

const resumePausedBeginningOfTurn = (
  state: GameStore,
): GameStore | Partial<GameStore> => {
  const previous = toGameState(state)
  const next = resumeAutomaticBeginningOfTurn({
    state: previous,
    applyAction: (current, action) => applyActionsWithEvents(current, [action]),
  }).state
  return next === previous ? state : { ...next, undoStack: state.undoStack }
}

const resolvePendingAbilityCore = (
  previous: GameState,
  pendingId: string,
): GameState | undefined => {
  const pending = previous.pendingAbilities.find(
    (ability) => ability.id === pendingId,
  )
  if (!pending) return undefined
  const stackObject = previous.stack.find(
    (object) => object.pendingAbilityId === pendingId,
  )
  if (
    stackObject &&
    previous.stack.at(-1)?.stackObjectId !== stackObject.stackObjectId
  )
    return undefined

  const resolution = {
    ...createPendingResolution(pending),
    ...(stackObject
      ? {
          completionActions: [
            {
              type: 'REMOVE_STACK_OBJECT' as const,
              stackObjectId: stackObject.stackObjectId,
            },
          ],
        }
      : {}),
  }
  let next = applyActionsWithEvents(previous, [
    { type: 'REMOVE_PENDING_ABILITY', pendingId },
  ])
  let step = advancePendingResolution(next, resolution)

  // A payment can depend on deterministic effects immediately before it.
  // Cumulative upkeep is the canonical example: add the age counter, then
  // calculate the amount to pay from the new counter total. Re-evaluate the
  // payment after those prefix actions have actually changed state.
  if (
    step.type === 'DECISION' &&
    step.decision.type === 'PAYMENT_CHOICE' &&
    step.actions.length > 0
  ) {
    next = applyActionsWithEvents(next, step.actions)
    const paymentEffectIndex = step.decision.continuation.resumeEffectIndex - 1
    const reevaluated = advancePendingResolution(next, {
      ...step.resolution,
      currentEffectIndex: Math.max(0, paymentEffectIndex),
    })
    if (reevaluated.type === 'DECISION') step = reevaluated
    else if (reevaluated.type === 'ACTIONS')
      return applyActionsWithEvents(next, [
        ...reevaluated.actions,
        ...(reevaluated.resolution.completionActions ?? []),
      ])
    else if (reevaluated.type === 'COMPLETE')
      return applyActionsWithEvents(
        next,
        reevaluated.resolution.completionActions ?? [],
      )
    else return next
  }

  if (step.type === 'ACTIONS')
    return applyActionsWithEvents(next, [
      ...step.actions,
      ...(step.resolution.completionActions ?? []),
    ])
  if (step.type === 'DECISION')
    return applyActionsWithEvents(next, [
      ...step.actions,
      { type: 'ADD_PENDING_RESOLUTION', resolution: step.resolution },
      { type: 'ADD_PENDING_DECISION', decision: step.decision },
    ])
  if (step.type === 'COMPLETE')
    return applyActionsWithEvents(next, step.resolution.completionActions ?? [])
  if (step.type === 'ERROR' && stackObject)
    return applyActionsWithEvents(next, [
      { type: 'REMOVE_STACK_OBJECT', stackObjectId: stackObject.stackObjectId },
    ])
  return next
}

const combatProgressCommand = (command: ParsedCommand): boolean =>
  command.type === 'DECLARE_ATTACKERS' ||
  command.type === 'DECLARE_BLOCKERS' ||
  command.type === 'RESOLVE_COMBAT_DAMAGE'

const commandImpliesPostcombatMain = (command: ParsedCommand): boolean =>
  command.type === 'PLAY_CARD' ||
  command.type === 'DECLARE_CARD' ||
  (command.type === 'CAST_SPELL' && command.inResponse !== true) ||
  (command.type === 'ACTIVATE_ABILITY' && command.abilityHint === 'EQUIP') ||
  command.type === 'NEXT_TURN'

const combatProgressLabel = (step: GameState['turnState']['step']): string => {
  if (step === 'BEGIN_COMBAT') return 'inicio de combate'
  if (step === 'DECLARE_ATTACKERS') return 'declarar atacantes'
  if (step === 'DECLARE_BLOCKERS') return 'declarar bloqueadores'
  if (step === 'COMBAT_DAMAGE') return 'paso de daño de combate'
  if (step === 'END_COMBAT') return 'fin de combate'
  if (step === 'MAIN_2') return 'segunda principal'
  return step
}

type ImplicitStackResolution = {
  state: GameState
  stackObjectId: string
  label: string
}

const resolveTopStackObjectImplicitly = (
  previous: GameState,
): ImplicitStackResolution | undefined => {
  const top = previous.stack.at(-1)
  if (!top) return undefined

  if (top.kind === 'SPELL' && top.spellInstanceId) {
    const spell = previous.cards.find(
      (card) =>
        card.instanceId === top.spellInstanceId && card.zone === 'stack',
    )
    if (!spell) return undefined
    return {
      state: resolveSpellWithEffects(previous, {
        type: 'RESOLVE_SPELL',
        instanceId: spell.instanceId,
      }),
      stackObjectId: top.stackObjectId,
      label: spell.card.name,
    }
  }

  if (
    (top.kind === 'TRIGGERED_ABILITY' || top.kind === 'ACTIVATED_ABILITY') &&
    top.pendingAbilityId
  ) {
    const pending = previous.pendingAbilities.find(
      (ability) => ability.id === top.pendingAbilityId,
    )
    if (!pending) return undefined
    const next = resolvePendingAbilityCore(previous, pending.id)
    if (!next) return undefined
    return {
      state: next,
      stackObjectId: top.stackObjectId,
      label:
        top.kind === 'TRIGGERED_ABILITY'
          ? `${pending.sourceCardName} trigger`
          : `${pending.sourceCardName} ability`,
    }
  }

  return undefined
}

const resolvePaymentDecisionCore = (
  previous: GameState,
  decisionId: string,
  selection: string,
): GameState | undefined => {
  const decision = previous.pendingDecisions.find(
    (candidate) => candidate.id === decisionId,
  )
  if (decision?.type !== 'PAYMENT_CHOICE') return undefined
  if (selection !== 'NOT_PAID' && !selection.startsWith('PAID'))
    return undefined
  const resolution = previous.pendingResolutions.find(
    (candidate) => candidate.id === decision.continuation.resolutionId,
  )
  const payment = decision.continuation.payment
  if (!resolution || !payment) return undefined
  const paidOption = selection.startsWith('PAID')
    ? payment.options?.find((option) => option.id === selection)
    : undefined
  if (selection.startsWith('PAID') && !paidOption) return undefined

  const resumed = {
    ...resolution,
    effects: [
      ...(selection.startsWith('PAID') ? payment.ifPaid : payment.ifNotPaid),
      ...resolution.effects.slice(decision.continuation.resumeEffectIndex),
    ],
    currentEffectIndex: 0,
  }
  let next = applyActionsWithEvents(previous, [
    { type: 'REMOVE_PENDING_DECISION', decisionId },
    ...(paidOption?.actions ?? []),
    { type: 'UPDATE_PENDING_RESOLUTION', resolution: resumed },
  ])
  const step = advancePendingResolution(next, resumed)
  if (step.type === 'ACTIONS')
    next = applyActionsWithEvents(next, [
      ...step.actions,
      { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
      ...(step.resolution.completionActions ?? []),
    ])
  else if (step.type === 'COMPLETE' || step.type === 'ERROR')
    next = applyActionsWithEvents(next, [
      { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
      ...(step.type === 'COMPLETE'
        ? (step.resolution.completionActions ?? [])
        : []),
    ])
  else
    next = applyActionsWithEvents(next, [
      ...step.actions,
      { type: 'UPDATE_PENDING_RESOLUTION', resolution: step.resolution },
      { type: 'ADD_PENDING_DECISION', decision: step.decision },
    ])
  return next
}

type TriggerDeclarationRequirement = {
  prompt: string
  constraints: import('../abilities/types/abilityTypes').SelectionConstraints
  requiredCount: number
  optional: boolean
}

const triggerDeclarationRequirement = (
  pending: import('../abilities/types/abilityTypes').PendingAbility,
): TriggerDeclarationRequirement | undefined => {
  const first = pending.resolvedEffects[0]
  if (!first) return undefined
  if (first.type === 'TARGET_SELECTION')
    return {
      prompt: first.prompt,
      constraints: first.constraints,
      requiredCount: Math.max(0, first.count ?? 1),
      optional: false,
    }
  if (first.type !== 'OPTIONAL_EFFECT') return undefined
  const nested = first.effects[0]
  if (!nested || nested.type !== 'TARGET_SELECTION') return undefined
  return {
    prompt: nested.prompt,
    constraints: nested.constraints,
    requiredCount: Math.max(0, nested.count ?? 1),
    optional: true,
  }
}

const pendingAbilityController = (
  state: GameState,
  pending: import('../abilities/types/abilityTypes').PendingAbility,
) => {
  const source = state.cards.find(
    (card) => card.instanceId === pending.sourceInstanceId,
  )
  const controllerId =
    pending.controllerId ??
    source?.controllerId ??
    state.localPlayerId ??
    'player-1'
  return {
    controllerId,
    controller:
      controllerId === state.localPlayerId
        ? ('YOU' as const)
        : ('OPPONENT' as const),
    source,
  }
}

const triggerStackObject = (
  state: GameState,
  pending: import('../abilities/types/abilityTypes').PendingAbility,
  declaredTargets: import('../abilities/types/abilityTypes').DeclaredTarget[] = [],
  orderOffset = 0,
): Extract<GameAction, { type: 'ADD_STACK_OBJECT' }> => {
  const controller = pendingAbilityController(state, pending)
  return {
    type: 'ADD_STACK_OBJECT',
    stackObject: {
      stackObjectId: `trigger-${pending.id}`,
      kind: 'TRIGGERED_ABILITY',
      controller: controller.controller,
      controllerId: controller.controllerId,
      sourceInstanceId: pending.sourceInstanceId,
      pendingAbilityId: pending.id,
      targets: declaredTargets.map((target) => target.targetId),
      ...(declaredTargets.length
        ? { declaredTargets: declaredTargets.map((target) => ({ ...target })) }
        : {}),
      order: state.stack.length + orderOffset + 1,
    },
  }
}

/**
 * Builds stack-placement actions for already ordered triggers. Targeted triggered
 * abilities stop here to declare targets before their stack object exists.
 */
const triggerPlacementActions = (
  state: GameState,
  orderedPendingAbilityIds: string[],
): GameAction[] => {
  const actions: GameAction[] = []
  let stackOffset = 0
  for (let index = 0; index < orderedPendingAbilityIds.length; index += 1) {
    const pendingId = orderedPendingAbilityIds[index]
    const pending = state.pendingAbilities.find((item) => item.id === pendingId)
    if (!pending) continue
    const requirement = triggerDeclarationRequirement(pending)
    if (!requirement || requirement.requiredCount === 0) {
      actions.push(triggerStackObject(state, pending, [], stackOffset++))
      continue
    }
    const controller = pendingAbilityController(state, pending)
    const options = legalDeclarationTargetOptions(
      state,
      {
        sourceInstanceId: pending.sourceInstanceId,
        sourceCard: controller.source?.card,
        controllerId: controller.controllerId,
        kind: 'TRIGGERED_ABILITY',
      },
      requirement.constraints,
    )
    if (!options.length && !requirement.optional) {
      // A targeted triggered ability with no legal target is removed rather than
      // being put on the stack without a target.
      actions.push({ type: 'REMOVE_PENDING_ABILITY', pendingId: pending.id })
      continue
    }
    if (!options.length && requirement.optional) {
      const first = pending.resolvedEffects[0]
      const updated = {
        ...pending,
        resolvedEffects:
          first?.type === 'OPTIONAL_EFFECT'
            ? pending.resolvedEffects.slice(1)
            : pending.resolvedEffects,
      }
      actions.push({ type: 'UPDATE_PENDING_ABILITY', pending: updated })
      actions.push(triggerStackObject(state, updated, [], stackOffset++))
      continue
    }
    actions.push({
      type: 'ADD_PENDING_DECISION',
      decision: {
        id: `trigger-target-${pending.id}-1`,
        sourceAbilityId: pending.abilityId,
        sourceInstanceId: pending.sourceInstanceId,
        decisionPlayerId: controller.controllerId,
        type: 'TRIGGER_TARGET_SELECTION',
        prompt: requirement.prompt,
        options: [
          ...(requirement.optional
            ? [{ instanceId: 'NO_TARGET', label: 'No target' }]
            : []),
          ...options,
        ],
        constraints: requirement.constraints,
        continuation: {
          effectsToExecute: [],
          resumeEffectIndex: 0,
          triggerTargetDeclaration: {
            pendingAbilityId: pending.id,
            prompt: requirement.prompt,
            constraints: requirement.constraints,
            requiredCount: requirement.requiredCount,
            selectedTargets: [],
            optional: requirement.optional,
            remainingPendingAbilityIds: orderedPendingAbilityIds.slice(
              index + 1,
            ),
          },
        },
      },
    })
    break
  }
  return actions
}

const stackCopyRetargetDecision = (
  state: GameState,
  stackObjectId: string,
  targetIndex = 0,
  declaredTargets?: import('../abilities/types/abilityTypes').DeclaredTarget[],
): import('../abilities/types/abilityTypes').PendingDecision | undefined => {
  const stackObject = state.stack.find(
    (object) => object.stackObjectId === stackObjectId,
  )
  const targets = declaredTargets ?? stackObject?.declaredTargets
  if (!stackObject || !targets?.length || targetIndex >= targets.length)
    return undefined
  const current = targets[targetIndex]
  const source = stackObject.spellInstanceId
    ? state.cards.find(
        (card) => card.instanceId === stackObject.spellInstanceId,
      )
    : undefined
  const controllerId =
    stackObject.controllerId ??
    source?.controllerId ??
    state.localPlayerId ??
    'player-1'
  const legalOptions = legalDeclarationTargetOptions(
    state,
    {
      sourceInstanceId: source?.instanceId ?? stackObject.sourceInstanceId,
      sourceCard: source?.card,
      controllerId,
      kind: 'SPELL',
    },
    current.constraints,
  )
  return {
    id: `copy-retarget-${stackObjectId}-${targetIndex + 1}`,
    sourceAbilityId: 'copy-spell-retarget',
    sourceInstanceId: source?.instanceId ?? stackObject.sourceInstanceId,
    decisionPlayerId: controllerId,
    type: 'STACK_COPY_RETARGET_SELECTION',
    prompt: `Keep target ${targetIndex + 1}, or choose a new legal target for the spell copy?`,
    options: [
      { instanceId: '__KEEP_TARGET__', label: 'Keep current target' },
      ...legalOptions.filter(
        (option) => option.instanceId !== current.targetId,
      ),
    ],
    constraints: current.constraints,
    continuation: {
      effectsToExecute: [],
      resumeEffectIndex: 0,
      stackCopyRetarget: {
        stackObjectId,
        targetIndex,
        declaredTargets: targets.map((target) => ({
          ...target,
          constraints: { ...target.constraints },
        })),
      },
    },
  }
}

const externalSpellTargetDecision = (
  state: GameState,
  castAction: Extract<GameAction, { type: 'CAST_SPELL' }>,
  selectedTargets: import('../abilities/types/abilityTypes').DeclaredTarget[] = [],
): import('../abilities/types/abilityTypes').PendingDecision | undefined => {
  const ability = getAbilitiesForCard(castAction.card).find(
    (
      candidate,
    ): candidate is import('../abilities/types/abilityTypes').SpellEffectDefinition =>
      candidate.kind === 'SPELL_EFFECT',
  )
  if (!ability) return undefined
  const requirement = declarationTargetRequirement(
    ability,
    castAction.variables ?? {},
  )
  if (!requirement || selectedTargets.length >= requirement.requiredCount)
    return undefined
  const controllerId = castAction.actorPlayerId ?? 'player-2'
  const options = legalDeclarationTargetOptions(
    state,
    {
      sourceInstanceId: castAction.instanceId,
      sourceCard: castAction.card,
      controllerId,
      kind: 'SPELL',
    },
    requirement.constraints,
  ).filter(
    (option) =>
      !selectedTargets.some((target) => target.targetId === option.instanceId),
  )
  if (!options.length && requirement.requiredCount > selectedTargets.length)
    return undefined
  return {
    id: `external-spell-target-${castAction.instanceId}-${selectedTargets.length + 1}`,
    sourceAbilityId: ability.id,
    sourceInstanceId: castAction.instanceId,
    type: 'EXTERNAL_SPELL_TARGET_SELECTION',
    prompt: `${requirement.prompt} (${selectedTargets.length + 1}/${requirement.requiredCount})`,
    options,
    constraints: requirement.constraints,
    continuation: {
      effectsToExecute: [],
      resumeEffectIndex: 0,
      externalSpellDeclaration: {
        castAction,
        prompt: requirement.prompt,
        constraints: requirement.constraints,
        requiredCount: requirement.requiredCount,
        selectedTargets,
      },
    },
  }
}

const controlledStackRetargetDecision = (
  state: GameState,
  resolution: GameState['pendingResolutions'][number],
  stackObjectId: string,
  targetIndex: number,
  declaredTargets: import('../abilities/types/abilityTypes').DeclaredTarget[],
  resumeEffectIndex: number,
): import('../abilities/types/abilityTypes').PendingDecision | undefined => {
  const stackObject = state.stack.find(
    (object) => object.stackObjectId === stackObjectId,
  )
  if (!stackObject || targetIndex >= declaredTargets.length) return undefined
  const current = declaredTargets[targetIndex]
  const source = stackObject.spellInstanceId
    ? state.cards.find(
        (card) => card.instanceId === stackObject.spellInstanceId,
      )
    : undefined
  const controllerId =
    stackObject.controllerId ??
    source?.controllerId ??
    state.localPlayerId ??
    'player-1'
  const legalOptions = legalDeclarationTargetOptions(
    state,
    {
      sourceInstanceId: source?.instanceId ?? stackObject.sourceInstanceId,
      sourceCard: source?.card,
      controllerId,
      kind: 'SPELL',
    },
    current.constraints,
  )
  return {
    id: `controlled-retarget-${stackObjectId}-${targetIndex + 1}`,
    sourceAbilityId: resolution.sourceAbilityId,
    sourceInstanceId: resolution.sourceInstanceId,
    decisionPlayerId: controllerId,
    type: 'STACK_RETARGET_SELECTION',
    prompt: `Keep target ${targetIndex + 1}, or choose a new legal target?`,
    options: [
      { instanceId: '__KEEP_TARGET__', label: 'Keep current target' },
      ...legalOptions.filter(
        (option) => option.instanceId !== current.targetId,
      ),
    ],
    constraints: current.constraints,
    continuation: {
      resolutionId: resolution.id,
      effectsToExecute: [],
      resumeEffectIndex,
      stackRetarget: {
        stackObjectId,
        targetIndex,
        declaredTargets: declaredTargets.map((target) => ({
          ...target,
          constraints: { ...target.constraints },
        })),
        resumeEffectIndex,
      },
    },
  }
}

const activatedAbilitiesAvailableFromZone = (
  state: GameState,
  source: GameState['cards'][number],
): import('../abilities/types/abilityTypes').ActivatedAbilityDefinition[] =>
  effectiveAbilitiesForCard(state, source).filter(
    (
      candidate,
    ): candidate is import('../abilities/types/abilityTypes').ActivatedAbilityDefinition =>
      candidate.kind === 'ACTIVATED' &&
      (candidate.activeZones?.length
        ? candidate.activeZones.includes(source.zone)
        : source.zone === 'battlefield'),
  )

const activatedAbilityLabel = (
  ability: import('../abilities/types/abilityTypes').ActivatedAbilityDefinition,
): string => {
  const manaCost = ability.costs.find((cost) => cost.type === 'MANA_COST')
  const withCost = (label: string): string =>
    manaCost?.type === 'MANA_COST' ? `${label} ${manaCost.cost}` : label

  if (ability.isManaAbility) return 'Mana'
  if (ability.costs.some((cost) => cost.type === 'WATERBEND'))
    return withCost('Waterbend')
  if (
    ability.activeZones?.includes('hand') &&
    ability.costs.some((cost) => cost.type === 'DISCARD_SOURCE')
  )
    return withCost('Channel')
  if (ability.effects.some((effect) => effect.type === 'ATTACH')) {
    if (/commander/i.test(ability.id)) return withCost('Equip commander')
    if (/legendary/i.test(ability.id)) return withCost('Equip legendary')
    return withCost('Equip')
  }
  return ability.id
}

const applyActivateAbilityAction = (
  previous: GameState,
  action: Extract<GameAction, { type: 'ACTIVATE_ABILITY' }>,
): GameState => {
  if (previous.turnState.priority !== 'WINDOW_OPEN') return previous
  const source = previous.cards.find(
    (card) => card.instanceId === action.instanceId,
  )
  const abilities = source
    ? activatedAbilitiesAvailableFromZone(previous, source)
    : []
  if (!source || !abilities.length) return previous
  if (!action.abilityId && abilities.length > 1)
    return applyActionsWithEvents(previous, [
      {
        type: 'ADD_PENDING_DECISION',
        decision: {
          id: `decision-activate-${source.instanceId}`,
          sourceAbilityId: 'ability-selection',
          sourceInstanceId: source.instanceId,
          type: 'ABILITY_SELECTION',
          prompt: `Elige la habilidad activada de ${source.card.name}.`,
          options: abilities.map((ability) => ({
            instanceId: ability.id,
            label: activatedAbilityLabel(ability),
          })),
          continuation: {
            effectsToExecute: [],
            resumeEffectIndex: 0,
            activationSourceInstanceId: source.instanceId,
          },
        },
      },
    ])

  const ability =
    abilities.find((candidate) => candidate.id === action.abilityId) ??
    (abilities.length === 1 ? abilities[0] : undefined)
  if (!ability) return previous
  const activationVariable = activationVariableName(ability)
  if (activationVariable) {
    const options = legalActivationVariableValues(
      previous,
      source.instanceId,
      ability,
      activationVariable,
    )
    if (!options.length) return previous
    return applyActionsWithEvents(previous, [
      {
        type: 'ADD_PENDING_DECISION',
        decision: {
          id: `decision-activation-variable-${source.instanceId}-${ability.id}`,
          sourceAbilityId: ability.id,
          sourceInstanceId: source.instanceId,
          type: 'ACTIVATION_VARIABLE_SELECTION',
          prompt: `Elige el valor de ${activationVariable} para ${source.card.name}.`,
          options: options.map((value) => ({
            instanceId: String(value),
            label: `${activationVariable} = ${value}`,
          })),
          continuation: {
            effectsToExecute: [],
            resumeEffectIndex: 0,
            activationVariable: {
              sourceInstanceId: source.instanceId,
              abilityId: ability.id,
              variableName: activationVariable,
              options,
            },
          },
        },
      },
    ])
  }
  return beginActivatedAbilityDeclaration(previous, source, ability)
}

const initialState = createInitialGameState()

export const useGameStore = create<GameStore>((set, get) => ({
  ...initialState,
  undoStack: [],
  getCurrentGameState: () => toGameState(get()),
  dispatch: (action) =>
    set((state) => {
      const previous = toGameState(state)
      if (action.type === 'NEXT_TURN' || action.type === 'START_TURN') {
        const next = advanceUntilPlayerInteraction({
          state: previous,
          startAction: action,
          applyAction: (current, step) =>
            applyActionsWithEvents(current, [step]),
        }).state
        return next === previous
          ? state
          : { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (action.type === 'ACTIVATE_ABILITY') {
        const next = applyActivateAbilityAction(previous, action)
        return next === previous
          ? state
          : { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (action.type === 'RESOLVE_SPELL') {
        const next = resolveSpellWithEffects(previous, action)
        return next === previous
          ? state
          : { ...next, undoStack: [...state.undoStack, previous] }
      }
      const next = applyActionsWithEvents(previous, [action])
      return next === previous
        ? state
        : { ...next, undoStack: [...state.undoStack, previous] }
    }),
  dispatchMany: (actions) =>
    set((state) => {
      if (!actions.length) return state
      const previous = toGameState(state)
      const next = actions.reduce(
        (current, action) =>
          action.type === 'NEXT_TURN' || action.type === 'START_TURN'
            ? advanceUntilPlayerInteraction({
                state: current,
                startAction: action,
                applyAction: (turnState, step) =>
                  applyActionsWithEvents(turnState, [step]),
              }).state
            : applyActionsWithEvents(current, [action]),
        previous,
      )
      return next === previous
        ? state
        : { ...next, undoStack: [...state.undoStack, previous] }
    }),
  declareExternalSpell: (card, manaSpent) =>
    set((state) => {
      if (!Number.isSafeInteger(manaSpent) || manaSpent < 0)
        throw new Error(
          'Indica cuánto maná se gastó realmente para lanzar el hechizo.',
        )
      const previous = toGameState(state)
      const opponentId =
        opponentPlayerIds(previous, previous.localPlayerId ?? 'player-1')[0] ??
        'player-2'
      const castViolation = castRestrictionViolation(previous, card, opponentId)
      if (castViolation)
        throw new Error(
          `El rival no puede lanzar ${card.name}: ${castViolation}`,
        )
      const instanceId = `external-${card.scryfallId}-${globalThis.crypto?.randomUUID?.() ?? Date.now()}`
      const castAction: Extract<GameAction, { type: 'CAST_SPELL' }> = {
        type: 'CAST_SPELL',
        instanceId,
        card,
        fromZone: 'hand',
        actorPlayerId: opponentId,
        variables: { MANA_SPENT_TO_CAST: manaSpent },
      }
      const decision = externalSpellTargetDecision(previous, castAction)
      const next = decision
        ? applyActionsWithEvents(previous, [
            { type: 'ADD_PENDING_DECISION', decision },
          ])
        : applyActionsWithEvents(previous, [castAction])
      return { ...next, undoStack: [...state.undoStack, previous] }
    }),
  executeTabletopCommand: (command) => {
    let execution: TabletopExecutionResult = {
      status: 'error',
      error: { code: 'UNKNOWN_COMMAND', message: 'No se pudo ejecutar.' },
      implicitResolutions: [],
    }
    set((state) => {
      const previous = toGameState(state)
      let current = previous
      if (
        command.type !== 'UNDO' &&
        current.autoAdvanceBeginningOfTurnPaused &&
        !requiresPlayerInteraction(current)
      )
        current = resumeAutomaticBeginningOfTurn({
          state: current,
          applyAction: (turnState, step) =>
            applyActionsWithEvents(turnState, [step]),
        }).state
      const implicitResolutions: string[] = []
      const applyCommandActions = (actions: GameAction[]): GameState =>
        actions.reduce((next, action) => {
          if (action.type === 'ACTIVATE_ABILITY')
            return applyActivateAbilityAction(next, action)
          if (action.type === 'RESOLVE_SPELL')
            return resolveSpellWithEffects(next, action)
          if (action.type === 'NEXT_TURN' || action.type === 'START_TURN')
            return advanceUntilPlayerInteraction({
              state: next,
              startAction: action,
              applyAction: (turnState, step) =>
                applyActionsWithEvents(turnState, [step]),
            }).state
          return applyActionsWithEvents(next, [action])
        }, current)

      for (let attempts = 0; attempts < 48; attempts += 1) {
        const wantsCombatProgress =
          combatProgressCommand(command) || commandImpliesPostcombatMain(command)

        if (
          wantsCombatProgress &&
          current.stack.length > 0 &&
          current.pendingDecisions.length === 0 &&
          current.pendingResolutions.length === 0
        ) {
          const beforeResolution = current
          const implicit = resolveTopStackObjectImplicitly(current)
          if (implicit) {
            current = implicit.state
            implicitResolutions.push(implicit.label)
            if (
              requiresAttentionAfterImplicitResolution(
                beforeResolution,
                current,
                implicit.stackObjectId,
              )
            ) {
              execution = {
                status: 'paused',
                description: `${implicit.label} resolved until a player decision was required; the original declaration was not executed.`,
                implicitResolutions,
              }
              return { ...current, undoStack: [...state.undoStack, previous] }
            }
            continue
          }
        }

        if (
          wantsCombatProgress &&
          current.stack.length === 0 &&
          !requiresPlayerInteraction(current)
        ) {
          const step = current.turnState.step
          let combatAdvanced = false

          if (
            command.type === 'DECLARE_ATTACKERS' &&
            (step === 'MAIN_1' || step === 'BEGIN_COMBAT')
          ) {
            current = applyActionsWithEvents(current, [{ type: 'ADVANCE_STEP' }])
            implicitResolutions.push(combatProgressLabel(current.turnState.step))
            combatAdvanced = true
          } else if (
            command.type === 'DECLARE_BLOCKERS' &&
            step === 'DECLARE_ATTACKERS' &&
            current.combatState.attackersDeclared
          ) {
            current = applyActionsWithEvents(current, [{ type: 'ADVANCE_STEP' }])
            implicitResolutions.push(combatProgressLabel(current.turnState.step))
            combatAdvanced = true
          } else if (
            command.type === 'RESOLVE_COMBAT_DAMAGE' &&
            step === 'DECLARE_BLOCKERS' &&
            current.combatState.blockersDeclared
          ) {
            current = applyActionsWithEvents(current, [{ type: 'ADVANCE_STEP' }])
            implicitResolutions.push(combatProgressLabel(current.turnState.step))
            combatAdvanced = true
          } else if (
            command.type === 'RESOLVE_COMBAT_DAMAGE' &&
            step === 'COMBAT_DAMAGE'
          ) {
            if (current.combatState.damageStep === 'COMPLETE') {
              execution = {
                status: 'executed',
                description: 'Daño de combate resuelto',
                implicitResolutions,
              }
              return current === previous
                ? state
                : { ...current, undoStack: [...state.undoStack, previous] }
            }
            const plan = planCombatDamage(current)
            if (plan.type === 'DECISION') {
              current = applyActionsWithEvents(current, [
                { type: 'ADD_PENDING_DECISION', decision: plan.decision },
              ])
              execution = {
                status: 'paused',
                description: 'El combate necesita una asignación de daño.',
                implicitResolutions,
              }
              return { ...current, undoStack: [...state.undoStack, previous] }
            }
            if (plan.type === 'ACTIONS') {
              current = applyCommandActions(plan.actions)
              implicitResolutions.push('daño de combate')
              combatAdvanced = true
            }
          } else if (commandImpliesPostcombatMain(command)) {
            if (step === 'DECLARE_ATTACKERS' && current.combatState.attackersDeclared) {
              current = applyActionsWithEvents(current, [{ type: 'ADVANCE_STEP' }])
              implicitResolutions.push(combatProgressLabel(current.turnState.step))
              combatAdvanced = true
            } else if (step === 'DECLARE_BLOCKERS' && !current.combatState.blockersDeclared) {
              current = applyActionsWithEvents(current, [
                { type: 'DECLARE_BLOCKERS', blockers: [], actorPlayerId: opponentPlayerIds(current, activePlayerIdOf(current))[0] },
              ])
              implicitResolutions.push('sin bloqueos')
              combatAdvanced = true
            } else if (step === 'DECLARE_BLOCKERS' && current.combatState.blockersDeclared) {
              current = applyActionsWithEvents(current, [{ type: 'ADVANCE_STEP' }])
              implicitResolutions.push(combatProgressLabel(current.turnState.step))
              combatAdvanced = true
            } else if (step === 'COMBAT_DAMAGE' && current.combatState.damageStep !== 'COMPLETE') {
              const plan = planCombatDamage(current)
              if (plan.type === 'DECISION') {
                current = applyActionsWithEvents(current, [
                  { type: 'ADD_PENDING_DECISION', decision: plan.decision },
                ])
                execution = {
                  status: 'paused',
                  description: 'El combate necesita una asignación de daño antes de continuar.',
                  implicitResolutions,
                }
                return { ...current, undoStack: [...state.undoStack, previous] }
              }
              if (plan.type === 'ACTIONS') {
                current = applyCommandActions(plan.actions)
                implicitResolutions.push('daño de combate')
                combatAdvanced = true
              }
            } else if (
              step === 'COMBAT_DAMAGE' &&
              current.combatState.damageStep === 'COMPLETE'
            ) {
              current = applyActionsWithEvents(current, [{ type: 'ADVANCE_STEP' }])
              implicitResolutions.push(combatProgressLabel(current.turnState.step))
              combatAdvanced = true
            } else if (step === 'END_COMBAT') {
              current = applyActionsWithEvents(current, [{ type: 'ADVANCE_STEP' }])
              implicitResolutions.push(combatProgressLabel(current.turnState.step))
              combatAdvanced = true
            }
          }

          if (combatAdvanced) {
            if (
              current.pendingDecisions.length > 0 ||
              current.pendingResolutions.length > 0
            ) {
              execution = {
                status: 'paused',
                description: 'El combate avanzó hasta una decisión que necesita al jugador.',
                implicitResolutions,
              }
              return { ...current, undoStack: [...state.undoStack, previous] }
            }
            continue
          }
        }

        const resolved = resolveCommand(current, command)
        if (resolved.status === 'undo') {
          execution = { status: 'undo', description: resolved.description }
          return state
        }

        if (shouldResolveTopBeforeCommand(current, command, resolved)) {
          const beforeResolution = current
          const implicit = resolveTopStackObjectImplicitly(current)
          if (implicit) {
            current = implicit.state
            implicitResolutions.push(implicit.label)
            if (
              requiresAttentionAfterImplicitResolution(
                beforeResolution,
                current,
                implicit.stackObjectId,
              )
            ) {
              execution = {
                status: 'paused',
                description: `${implicit.label} resolved until a player decision was required; the original declaration was not executed.`,
                implicitResolutions,
              }
              return { ...current, undoStack: [...state.undoStack, previous] }
            }
            continue
          }
        }

        if (resolved.status === 'resolved') {
          const next = applyCommandActions(resolved.actions)
          execution = {
            status: 'executed',
            description:
              implicitResolutions.length > 0
                ? `${implicitResolutions.map((name) => `${name} resolved`).join(' · ')} · ${resolved.description}`
                : resolved.description,
            implicitResolutions,
          }
          return next === previous
            ? state
            : { ...next, undoStack: [...state.undoStack, previous] }
        }
        execution = {
          status: 'error',
          error: resolved.error,
          implicitResolutions,
        }
        return current === previous
          ? state
          : { ...current, undoStack: [...state.undoStack, previous] }
      }
      execution = {
        status: 'error',
        error: {
          code: 'STACK_NOT_EMPTY',
          message: 'La resolución implícita alcanzó el límite seguro.',
        },
        implicitResolutions,
      }
      return current === previous
        ? state
        : { ...current, undoStack: [...state.undoStack, previous] }
    })
    return execution
  },
  resolvePendingDecisionWithExternalCard: (decisionId, card) => {
    set((state) => {
      const previous = toGameState(state)
      const decision = previous.pendingDecisions.find(
        (candidate) => candidate.id === decisionId,
      )
      const resolution = previous.pendingResolutions.find(
        (candidate) => candidate.id === decision?.continuation.resolutionId,
      )
      if (!decision || !resolution) return state

      const continueResolution = (
        base: GameState,
        resumed: PendingResolution,
      ): GameState => {
        const step = advancePendingResolution(base, resumed)
        if (step.type === 'ACTIONS')
          return applyActionsWithEvents(base, [
            ...step.actions,
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.resolution.completionActions ?? []),
          ])
        if (step.type === 'COMPLETE' || step.type === 'ERROR')
          return applyActionsWithEvents(base, [
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.type === 'COMPLETE'
              ? (step.resolution.completionActions ?? [])
              : []),
          ])
        return applyActionsWithEvents(base, [
          ...step.actions,
          { type: 'UPDATE_PENDING_RESOLUTION', resolution: step.resolution },
          { type: 'ADD_PENDING_DECISION', decision: step.decision },
        ])
      }

      const publicSelection = decision.continuation.publicZoneSelection
      if (decision.type === 'PUBLIC_ZONE_CARD_SELECTION' && publicSelection) {
        if (!cardMatchesSearchConstraints(card, publicSelection.constraints))
          return state
        const known = previous.cards.find(
          (candidate) =>
            candidate.zone === publicSelection.zone &&
            candidate.card.scryfallId === card.scryfallId &&
            (candidate.ownerId ?? previous.localPlayerId) ===
              publicSelection.playerId,
        )
        const instanceId =
          known?.instanceId ??
          `external-${card.scryfallId}-${globalThis.crypto?.randomUUID?.() ?? Date.now()}`
        const resumed = {
          ...resolution,
          currentEffectIndex: decision.continuation.resumeEffectIndex,
        }
        let next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...(known
            ? []
            : [
                {
                  type: 'DECLARE_EXTERNAL_CARD' as const,
                  instanceId,
                  card,
                  zone: publicSelection.zone,
                  controllerId: publicSelection.playerId,
                  knownBecause: publicSelection.knownBecause,
                },
              ]),
          ...(publicSelection.linkKey
            ? ([
                {
                  type: 'LINK_CARD',
                  sourceInstanceId: decision.sourceInstanceId,
                  key: publicSelection.linkKey,
                  linkedInstanceId: instanceId,
                },
              ] as const)
            : []),
          { type: 'UPDATE_PENDING_RESOLUTION', resolution: resumed },
        ])
        next = continueResolution(next, resumed)
        return { ...next, undoStack: [...state.undoStack, previous] }
      }

      const search = decision.continuation.librarySearch
      if (
        decision.type !== 'HIDDEN_ZONE_CARD_SELECTION' ||
        !search?.playerId ||
        search.playerId === previous.localPlayerId ||
        !cardMatchesSearchConstraints(card, search.constraints)
      )
        return state

      const searchedPlayerId = search.playerId
      const known = previous.cards.find(
        (candidate) =>
          candidate.zone === 'library' &&
          candidate.card.scryfallId === card.scryfallId &&
          (candidate.ownerId ?? previous.localPlayerId) === searchedPlayerId,
      )
      const instanceId =
        known?.instanceId ??
        `external-search-${card.scryfallId}-${globalThis.crypto?.randomUUID?.() ?? Date.now()}`
      const destination =
        search.destination === 'TOP_OF_LIBRARY' ? 'library' : search.destination
      const destinationControllerId =
        destination === 'battlefield'
          ? search.controller === 'SOURCE_CONTROLLER'
            ? decision.decisionPlayerId
            : searchedPlayerId
          : undefined
      const trackedLibraryCount =
        previous.players.find((player) => player.id === searchedPlayerId)
          ?.libraryCount ?? 0
      const resumed = {
        ...resolution,
        context: {
          ...resolution.context,
          selectedCards: [...resolution.context.selectedCards, instanceId],
        },
        currentEffectIndex: decision.continuation.resumeEffectIndex,
      }
      const searchActions: GameAction[] = [
        { type: 'REMOVE_PENDING_DECISION', decisionId },
        ...(known
          ? []
          : [
              {
                type: 'DECLARE_EXTERNAL_CARD' as const,
                instanceId,
                card,
                zone: 'library' as const,
                controllerId: searchedPlayerId,
                knownBecause: 'SEARCHED' as const,
              },
            ]),
        ...(destination !== 'library'
          ? [
              {
                type: 'MOVE_CARD' as const,
                instanceId,
                toZone: destination,
                ...(destinationControllerId
                  ? { controllerId: destinationControllerId }
                  : {}),
              },
            ]
          : []),
        ...(trackedLibraryCount > 0 && destination !== 'library'
          ? [
              {
                type: 'SET_PLAYER_LIBRARY_COUNT' as const,
                playerId: searchedPlayerId,
                count: Math.max(0, trackedLibraryCount - 1),
              },
            ]
          : []),
        ...(search.shuffle
          ? [
              {
                type: 'DECLARE_PLAYER_SHUFFLED' as const,
                player: 'opponent' as const,
                playerId: searchedPlayerId,
              },
            ]
          : []),
        { type: 'UPDATE_PENDING_RESOLUTION', resolution: resumed },
      ]
      let next = applyActionsWithEvents(previous, searchActions)
      next = continueResolution(next, resumed)
      return { ...next, undoStack: [...state.undoStack, previous] }
    })
  },
  setStackResolutionMode: (mode) => set({ stackResolutionMode: mode }),
  undoLastAction: () =>
    set((state) => {
      const previous = state.undoStack.at(-1)
      return previous
        ? { ...previous, undoStack: state.undoStack.slice(0, -1) }
        : state
    }),
  resolvePendingAbility: (pendingId) => {
    set((state) => {
      const previous = toGameState(state)
      const next = resolvePendingAbilityCore(previous, pendingId)
      return !next || next === previous
        ? state
        : { ...next, undoStack: [...state.undoStack, previous] }
    })
    set(resumePausedBeginningOfTurn)
  },
  resolvePendingAbilityPayment: (pendingId, selection) => {
    set((state) => {
      const previous = toGameState(state)
      const staged = resolvePendingAbilityCore(previous, pendingId)
      if (!staged || staged === previous) return state
      const paymentDecision = staged.pendingDecisions.find(
        (decision) =>
          decision.type === 'PAYMENT_CHOICE' &&
          decision.continuation.resolutionId === `resolution-${pendingId}`,
      )
      if (!paymentDecision) return state

      if (selection === 'NOT_PAID') {
        const next = resolvePaymentDecisionCore(
          staged,
          paymentDecision.id,
          'NOT_PAID',
        )
        return next
          ? { ...next, undoStack: [...state.undoStack, previous] }
          : state
      }

      const paidOptions = paymentDecision.continuation.payment?.options ?? []
      if (paidOptions.length === 0) return state
      if (paidOptions.length === 1) {
        const next = resolvePaymentDecisionCore(
          staged,
          paymentDecision.id,
          paidOptions[0].id,
        )
        return next
          ? { ...next, undoStack: [...state.undoStack, previous] }
          : state
      }

      // Paying is a real choice, but choosing between several non-equivalent
      // mana plans is another real choice. Commit to paying without inventing
      // which sources the player wants to use.
      const committedDecision = {
        ...paymentDecision,
        prompt: `${paymentDecision.prompt} Elige cómo pagar.`,
        options: paymentDecision.options?.filter((option) =>
          option.instanceId.startsWith('PAID'),
        ),
      }
      const next = applyActionsWithEvents(staged, [
        { type: 'REMOVE_PENDING_DECISION', decisionId: paymentDecision.id },
        { type: 'ADD_PENDING_DECISION', decision: committedDecision },
      ])
      return { ...next, undoStack: [...state.undoStack, previous] }
    })
    set(resumePausedBeginningOfTurn)
  },
  ignorePendingAbility: (pendingId) => {
    set((state) => {
      const previous = toGameState(state)
      const stackObject = previous.stack.find(
        (object) => object.pendingAbilityId === pendingId,
      )
      const next = applyActionsWithEvents(previous, [
        { type: 'REMOVE_PENDING_ABILITY', pendingId },
        ...(stackObject
          ? [
              {
                type: 'REMOVE_STACK_OBJECT' as const,
                stackObjectId: stackObject.stackObjectId,
              },
            ]
          : []),
      ])
      return next === previous
        ? state
        : { ...next, undoStack: [...state.undoStack, previous] }
    })
    set(resumePausedBeginningOfTurn)
  },
  resolvePendingDecision: (decisionId, selection) => {
    set((state) => {
      const previous = toGameState(state)
      const decision = previous.pendingDecisions.find(
        (candidate) => candidate.id === decisionId,
      )
      if (
        decision?.type === 'MANA_PAYMENT_SELECTION' ||
        decision?.type === 'MANA_SOURCE_SELECTION'
      ) {
        const actionPayment = decision.continuation.actionPayment
        if (actionPayment) {
          const option = actionPayment.options.find(
            (candidate) => candidate.id === selection,
          )
          if (!option) return state
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            ...option.actions,
            ...actionPayment.completionActions,
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const payment =
          decision.type === 'MANA_SOURCE_SELECTION'
            ? decision.continuation.manaSourcePayment
            : decision.continuation.manaPayment
        const option = payment?.options.find(
          (candidate) => candidate.id === selection,
        )
        const castAction = payment?.castAction
        if (!option || !castAction) return state
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...option.actions,
          castAction,
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'LINKED_FREE_CAST_SELECTION') {
        const freeCast = decision.continuation.linkedFreeCast
        const resolution = previous.pendingResolutions.find(
          (candidate) => candidate.id === decision.continuation.resolutionId,
        )
        if (
          !freeCast ||
          !resolution ||
          (selection !== 'CAST' && selection !== 'DECLINE')
        )
          return state
        const finished = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resolution.id },
          ...(resolution.completionActions ?? []),
        ])
        if (selection === 'DECLINE')
          return { ...finished, undoStack: [...state.undoStack, previous] }
        const planned = resolveFreeCastKnownCard(
          finished,
          freeCast.cardInstanceId,
          {
            fromZone: freeCast.fromZone,
            actorPlayerId: freeCast.actorPlayerId,
            ...(freeCast.exileIfWouldEnterGraveyard
              ? { exileIfWouldEnterGraveyard: true }
              : {}),
          },
        )
        if (planned.status !== 'resolved') return state
        const next = applyActionsWithEvents(finished, planned.actions)
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'CLEANUP_DISCARD_SELECTION') {
        const cleanup = decision.continuation.cleanupDiscard
        if (!cleanup || previous.turnState.step !== 'CLEANUP') return state
        const playerId =
          decision.decisionPlayerId ?? previous.localPlayerId ?? 'player-1'
        const player = previous.players.find((entry) => entry.id === playerId)
        const handCount =
          player?.handCount ??
          (playerId === (previous.localPlayerId ?? 'player-1')
            ? previous.handCount
            : 0)
        const known = previous.cards.find(
          (card) =>
            card.zone === 'hand' &&
            card.instanceId === selection &&
            (card.ownerId ?? previous.localPlayerId ?? 'player-1') === playerId,
        )
        const knownHandCount = previous.cards.filter(
          (card) =>
            card.zone === 'hand' &&
            (card.ownerId ?? previous.localPlayerId ?? 'player-1') === playerId,
        ).length
        const unknownCount = Math.max(0, handCount - knownHandCount)
        if (!known && !(selection === 'UNKNOWN_CARD' && unknownCount > 0))
          return state
        let next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...(known
            ? [
                {
                  type: 'MOVE_CARD' as const,
                  instanceId: known.instanceId,
                  toZone: 'graveyard' as const,
                },
              ]
            : [
                {
                  type: 'SET_HAND_COUNT' as const,
                  count: Math.max(0, handCount - 1),
                  playerId,
                },
              ]),
        ])
        const followUp = cleanupDiscardDecision(next)
        if (followUp)
          next = applyActionsWithEvents(next, [
            { type: 'ADD_PENDING_DECISION', decision: followUp },
          ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'CAST_GIFT_SELECTION') {
        const declaration = decision.continuation.castGiftDeclaration
        if (!declaration) return state
        if (selection !== 'NO_GIFT' && selection !== 'PROMISE_GIFT')
          return state
        const castAction = {
          ...declaration.castAction,
          variables: {
            ...(declaration.castAction.variables ?? {}),
            [declaration.promisedVariableName]:
              selection === 'PROMISE_GIFT' ? 1 : 0,
          },
        }
        const planned = resolvePreparedCast(
          previous,
          declaration.cardName,
          declaration.displayedManaCost,
          castAction,
          declaration.cost,
        )
        if (planned.status !== 'resolved') return state
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...planned.actions,
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'CAST_GIFT_RECIPIENT_SELECTION') {
        const declaration = decision.continuation.castGiftDeclaration
        if (!declaration) return state
        if (
          !decision.options?.some((option) => option.instanceId === selection)
        )
          return state
        const castAction = {
          ...declaration.castAction,
          variables: {
            ...(declaration.castAction.variables ?? {}),
            [declaration.recipientVariableName]: selection,
          },
        }
        const planned = resolvePreparedCast(
          previous,
          declaration.cardName,
          declaration.displayedManaCost,
          castAction,
          declaration.cost,
        )
        if (planned.status !== 'resolved') return state
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...planned.actions,
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'CAST_MODE_SELECTION') {
        const declaration = decision.continuation.castModeDeclaration
        if (!declaration) return state
        if (!declaration.modes.some((mode) => mode.id === selection))
          return state
        const castAction = {
          ...declaration.castAction,
          variables: {
            ...(declaration.castAction.variables ?? {}),
            [declaredModeVariableKey(declaration.abilityId)]: selection,
          },
        }
        const planned = resolvePreparedCast(
          previous,
          declaration.cardName,
          declaration.displayedManaCost,
          castAction,
          declaration.cost,
        )
        if (planned.status !== 'resolved') return state
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...planned.actions,
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'ACTIVATION_MODE_SELECTION') {
        const declaration = decision.continuation.activationModeDeclaration
        if (!declaration) return state
        if (!declaration.modes.some((mode) => mode.id === selection))
          return state
        const source = previous.cards.find(
          (card) => card.instanceId === declaration.sourceInstanceId,
        )
        const ability = source
          ? effectiveAbilitiesForCard(previous, source).find(
              (
                candidate,
              ): candidate is import('../abilities/types/abilityTypes').ActivatedAbilityDefinition =>
                candidate.kind === 'ACTIVATED' &&
                candidate.id === declaration.abilityId,
            )
          : undefined
        if (!source || !ability) return state
        const next = beginActivatedAbilityDeclaration(
          previous,
          source,
          ability,
          {
            ...declaration.variables,
            [declaredModeVariableKey(declaration.abilityId)]: selection,
          },
          [{ type: 'REMOVE_PENDING_DECISION', decisionId }],
          declaration.declaredTargets,
        )
        return next === previous
          ? state
          : { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'EXTERNAL_SPELL_TARGET_SELECTION') {
        const declaration = decision.continuation.externalSpellDeclaration
        if (
          !declaration ||
          !decision.options?.some((option) => option.instanceId === selection)
        )
          return state
        const selectedTargets = [
          ...declaration.selectedTargets,
          {
            targetId: selection,
            constraints: declaration.constraints,
          },
        ]
        const nextDecision = externalSpellTargetDecision(
          previous,
          declaration.castAction,
          selectedTargets,
        )
        const actions: GameAction[] = [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...(nextDecision
            ? [
                {
                  type: 'ADD_PENDING_DECISION' as const,
                  decision: nextDecision,
                },
              ]
            : [
                {
                  ...declaration.castAction,
                  declaredTargets: selectedTargets,
                },
              ]),
        ]
        const next = applyActionsWithEvents(previous, actions)
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'CAST_TARGET_SELECTION') {
        const declaration = decision.continuation.castTargetDeclaration
        if (!declaration) return state
        const controllerId =
          declaration.castAction.actorPlayerId ??
          previous.localPlayerId ??
          'player-1'
        const legalOptions = legalDeclarationTargetOptions(
          previous,
          {
            sourceInstanceId: declaration.castAction.instanceId,
            sourceCard: declaration.castAction.card,
            controllerId,
            kind: 'SPELL',
          },
          declaration.constraints,
        ).filter(
          (option) =>
            !declaration.selectedTargets.some(
              (target) => target.targetId === option.instanceId,
            ),
        )
        if (selection === 'DONE') {
          if (
            !declaration.allowFewer ||
            declaration.selectedTargets.length < (declaration.minimumCount ?? 0)
          )
            return state
          const castAction = {
            ...declaration.castAction,
            declaredTargets: declaration.selectedTargets,
            variables: {
              ...(declaration.castAction.variables ?? {}),
              ...(declaration.abilityId
                ? {
                    [declaredTargetCountVariableKey(declaration.abilityId)]:
                      declaration.selectedTargets.length,
                  }
                : {}),
            },
          }
          const contribution = decision.continuation.castContribution
          if (contribution) {
            const countOptions = contribution.countOptions ?? []
            const next = applyActionsWithEvents(previous, [
              { type: 'REMOVE_PENDING_DECISION', decisionId },
              {
                type: 'ADD_PENDING_DECISION',
                decision: {
                  id: `cast-contribution-${castAction.instanceId}-declared`,
                  sourceAbilityId: 'cast-generic-contribution',
                  sourceInstanceId: castAction.instanceId,
                  type: 'CAST_GENERIC_CONTRIBUTION_COUNT',
                  prompt:
                    contribution.contributionType === 'TAP_PERMANENTS'
                      ? `Elige cuántos permanentes quieres girar para pagar ${contribution.displayedManaCost ?? 'el coste adicional'}.`
                      : contribution.contributionType ===
                          'EXILE_DECLARED_CARDS_FROM_HAND'
                        ? `Elige cuántas cartas de tu mano quieres declarar y exiliar para reducir ${contribution.displayedManaCost ?? 'el coste'}.`
                        : `Elige cuántas cartas quieres exiliar del cementerio para pagar ${contribution.displayedManaCost ?? 'el coste adicional'}.`,
                  options: countOptions.map((count) => ({
                    instanceId: String(count),
                    label: `${count}`,
                  })),
                  continuation: {
                    effectsToExecute: [],
                    resumeEffectIndex: 0,
                    castContribution: { ...contribution, castAction },
                  },
                },
              },
            ])
            return { ...next, undoStack: [...state.undoStack, previous] }
          }
          const planned = resolvePreparedCast(
            previous,
            declaration.cardName,
            declaration.displayedManaCost,
            castAction,
            declaration.cost,
          )
          if (planned.status !== 'resolved') return state
          const plannedActions = declaration.nonManaCosts?.length
            ? withNonManaCastCosts(
                previous,
                castAction,
                planned.actions,
                declaration.nonManaCosts,
              )
            : planned.actions
          if (!plannedActions) return state
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            ...plannedActions,
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        if (!legalOptions.some((option) => option.instanceId === selection))
          return state
        const selectedTargets = [
          ...declaration.selectedTargets,
          { targetId: selection, constraints: declaration.constraints },
        ]
        if (selectedTargets.length < declaration.requiredCount) {
          const remainingOptions = legalOptions.filter(
            (option) => option.instanceId !== selection,
          )
          if (
            !declaration.allowFewer &&
            remainingOptions.length <
              declaration.requiredCount - selectedTargets.length
          )
            return state
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            {
              type: 'ADD_PENDING_DECISION',
              decision: {
                ...decision,
                id: `cast-target-${declaration.castAction.instanceId}-${selectedTargets.length + 1}`,
                options: declaration.allowFewer
                  ? [
                      ...remainingOptions,
                      { instanceId: 'DONE', label: 'Hecho' },
                    ]
                  : remainingOptions,
                continuation: {
                  ...decision.continuation,
                  castTargetDeclaration: {
                    ...declaration,
                    selectedTargets,
                  },
                },
              },
            },
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const castAction = {
          ...declaration.castAction,
          declaredTargets: selectedTargets,
          variables: {
            ...(declaration.castAction.variables ?? {}),
            ...(declaration.allowFewer && declaration.abilityId
              ? {
                  [declaredTargetCountVariableKey(declaration.abilityId)]:
                    selectedTargets.length,
                }
              : {}),
          },
        }
        const contribution = decision.continuation.castContribution
        if (contribution) {
          const countOptions = contribution.countOptions ?? []
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            {
              type: 'ADD_PENDING_DECISION',
              decision: {
                id: `cast-contribution-${castAction.instanceId}-declared`,
                sourceAbilityId: 'cast-generic-contribution',
                sourceInstanceId: castAction.instanceId,
                type: 'CAST_GENERIC_CONTRIBUTION_COUNT',
                prompt:
                  contribution.contributionType === 'TAP_PERMANENTS'
                    ? `Elige cuántos permanentes quieres girar para pagar ${contribution.displayedManaCost ?? 'el coste adicional'}.`
                    : `Elige cuántas cartas quieres exiliar del cementerio para pagar ${contribution.displayedManaCost ?? 'el coste adicional'}.`,
                options: countOptions.map((count) => ({
                  instanceId: String(count),
                  label: `${count}`,
                })),
                continuation: {
                  effectsToExecute: [],
                  resumeEffectIndex: 0,
                  castContribution: { ...contribution, castAction },
                },
              },
            },
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const planned = resolvePreparedCast(
          previous,
          declaration.cardName,
          declaration.displayedManaCost,
          castAction,
          declaration.cost,
        )
        if (planned.status !== 'resolved') return state
        const plannedActions = declaration.nonManaCosts?.length
          ? withNonManaCastCosts(
              previous,
              castAction,
              planned.actions,
              declaration.nonManaCosts,
            )
          : planned.actions
        if (!plannedActions) return state
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...plannedActions,
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'ABILITY_SELECTION') {
        const sourceInstanceId =
          decision.continuation.activationSourceInstanceId
        const source = sourceInstanceId
          ? previous.cards.find((card) => card.instanceId === sourceInstanceId)
          : undefined
        const ability = source
          ? effectiveAbilitiesForCard(previous, source).find(
              (
                candidate,
              ): candidate is import('../abilities/types/abilityTypes').ActivatedAbilityDefinition =>
                candidate.kind === 'ACTIVATED' && candidate.id === selection,
            )
          : undefined
        if (!source || !ability) return state
        const activationVariable = activationVariableName(ability)
        if (activationVariable) {
          const options = legalActivationVariableValues(
            previous,
            source.instanceId,
            ability,
            activationVariable,
          )
          if (!options.length) return state
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            {
              type: 'ADD_PENDING_DECISION',
              decision: {
                id: `decision-activation-variable-${source.instanceId}-${ability.id}`,
                sourceAbilityId: ability.id,
                sourceInstanceId: source.instanceId,
                type: 'ACTIVATION_VARIABLE_SELECTION',
                prompt: `Elige el valor de ${activationVariable} para ${source.card.name}.`,
                options: options.map((value) => ({
                  instanceId: String(value),
                  label: `${activationVariable} = ${value}`,
                })),
                continuation: {
                  effectsToExecute: [],
                  resumeEffectIndex: 0,
                  activationVariable: {
                    sourceInstanceId: source.instanceId,
                    abilityId: ability.id,
                    variableName: activationVariable,
                    options,
                  },
                },
              },
            },
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const next = beginActivatedAbilityDeclaration(
          previous,
          source,
          ability,
          {},
          [{ type: 'REMOVE_PENDING_DECISION', decisionId }],
        )
        return next === previous
          ? state
          : { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'ACTIVATION_TARGET_SELECTION') {
        const declaration = decision.continuation.activationTargetDeclaration
        if (!declaration) return state
        const source = previous.cards.find(
          (card) => card.instanceId === declaration.sourceInstanceId,
        )
        const ability = source
          ? effectiveAbilitiesForCard(previous, source).find(
              (
                candidate,
              ): candidate is import('../abilities/types/abilityTypes').ActivatedAbilityDefinition =>
                candidate.kind === 'ACTIVATED' &&
                candidate.id === declaration.abilityId,
            )
          : undefined
        if (!source || !ability) return state
        const controllerId =
          source.controllerId ?? previous.localPlayerId ?? 'player-1'
        const legalOptions = legalDeclarationTargetOptions(
          previous,
          {
            sourceInstanceId: source.instanceId,
            sourceCard: source.card,
            controllerId,
            kind: 'ACTIVATED_ABILITY',
          },
          declaration.constraints,
        ).filter(
          (option) =>
            !declaration.selectedTargets.some(
              (target) => target.targetId === option.instanceId,
            ),
        )
        if (!legalOptions.some((option) => option.instanceId === selection))
          return state
        const selectedTargets = [
          ...declaration.selectedTargets,
          { targetId: selection, constraints: declaration.constraints },
        ]
        const next = beginActivatedAbilityDeclaration(
          previous,
          source,
          ability,
          declaration.variables,
          [{ type: 'REMOVE_PENDING_DECISION', decisionId }],
          selectedTargets,
        )
        return next === previous
          ? state
          : { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'ACTIVATION_WATERBEND_COUNT') {
        const continuation = decision.continuation.activationWaterbend
        if (!continuation) return state
        const count = Number(selection)
        if (!Number.isSafeInteger(count) || count < 0) return state
        const source = previous.cards.find(
          (card) => card.instanceId === continuation.sourceInstanceId,
        )
        const ability = source
          ? effectiveAbilitiesForCard(previous, source).find(
              (
                candidate,
              ): candidate is import('../abilities/types/abilityTypes').ActivatedAbilityDefinition =>
                candidate.kind === 'ACTIVATED' &&
                candidate.id === continuation.abilityId,
            )
          : undefined
        if (!source || !ability) return state
        const candidates = activationWaterbendCostCandidates(
          previous,
          source.instanceId,
        )
        if (count > candidates.length || count > continuation.requiredAmount)
          return state
        if (count === 0) {
          const activation = resolveActivatedAbility(
            previous,
            source.instanceId,
            ability,
            continuation.variables,
            [],
            additionalDeclaredActivationTargetCost(
              previous,
              source,
              continuation.declaredTargets,
            ),
          )
          if (!activation.ok) return state
          const next = applyActivatedAbilityExecution(
            previous,
            source,
            ability,
            activation,
            continuation.variables,
            [{ type: 'REMOVE_PENDING_DECISION', decisionId }],
            continuation.declaredTargets,
          )
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const nextDecision: import('../abilities/types/abilityTypes').PendingDecision =
          {
            id: `decision-activation-waterbend-selection-${source.instanceId}-${ability.id}`,
            sourceAbilityId: ability.id,
            sourceInstanceId: source.instanceId,
            decisionPlayerId: source.controllerId ?? previous.localPlayerId,
            type: 'ACTIVATION_WATERBEND_SELECTION',
            prompt: `Elige ${count} permanente${count === 1 ? '' : 's'} para Waterbend.`,
            options: candidates.map((card) => ({
              instanceId: card.instanceId,
              label: card.card.name,
            })),
            continuation: {
              effectsToExecute: [],
              resumeEffectIndex: 0,
              activationWaterbend: {
                ...continuation,
                selectedIds: [],
                requiredCount: count,
              },
            },
          }
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          { type: 'ADD_PENDING_DECISION', decision: nextDecision },
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'ACTIVATION_WATERBEND_SELECTION') {
        const continuation = decision.continuation.activationWaterbend
        if (!continuation?.requiredCount) return state
        const source = previous.cards.find(
          (card) => card.instanceId === continuation.sourceInstanceId,
        )
        const ability = source
          ? effectiveAbilitiesForCard(previous, source).find(
              (
                candidate,
              ): candidate is import('../abilities/types/abilityTypes').ActivatedAbilityDefinition =>
                candidate.kind === 'ACTIVATED' &&
                candidate.id === continuation.abilityId,
            )
          : undefined
        if (!source || !ability) return state
        const candidates = activationWaterbendCostCandidates(
          previous,
          source.instanceId,
        )
        if (
          !candidates.some((card) => card.instanceId === selection) ||
          continuation.selectedIds.includes(selection)
        )
          return state
        const selectedIds = [...continuation.selectedIds, selection]
        if (selectedIds.length < continuation.requiredCount) {
          const nextDecision: import('../abilities/types/abilityTypes').PendingDecision =
            {
              ...decision,
              id: `${decision.id}-${selectedIds.length}`,
              options: candidates
                .filter((card) => !selectedIds.includes(card.instanceId))
                .map((card) => ({
                  instanceId: card.instanceId,
                  label: card.card.name,
                })),
              continuation: {
                ...decision.continuation,
                activationWaterbend: { ...continuation, selectedIds },
              },
            }
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            { type: 'ADD_PENDING_DECISION', decision: nextDecision },
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const activation = resolveActivatedAbility(
          previous,
          source.instanceId,
          ability,
          continuation.variables,
          selectedIds,
          additionalDeclaredActivationTargetCost(
            previous,
            source,
            continuation.declaredTargets,
          ),
        )
        if (!activation.ok) return state
        const next = applyActivatedAbilityExecution(
          previous,
          source,
          ability,
          activation,
          continuation.variables,
          [{ type: 'REMOVE_PENDING_DECISION', decisionId }],
          continuation.declaredTargets,
        )
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'ACTIVATION_COST_PERMANENT_SELECTION') {
        const cost = decision.continuation.activationCostSelection
        if (!cost) return state
        const source = previous.cards.find(
          (card) => card.instanceId === cost.sourceInstanceId,
        )
        const ability = source
          ? effectiveAbilitiesForCard(previous, source).find(
              (
                candidate,
              ): candidate is import('../abilities/types/abilityTypes').ActivatedAbilityDefinition =>
                candidate.kind === 'ACTIVATED' &&
                candidate.id === cost.abilityId,
            )
          : undefined
        if (!source || !ability) return state
        if (
          !activationPermanentCostCandidates(
            previous,
            source.instanceId,
            ability,
          ).some((card) => card.instanceId === selection)
        )
          return state
        const declaredTargets = cost.declaredTargets ?? []
        const next = executeActivatedAbilityWithSmartMana(
          previous,
          source,
          ability,
          cost.variables,
          [selection],
          [{ type: 'REMOVE_PENDING_DECISION', decisionId }],
          declaredTargets,
        )
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'CAST_OPTION_SELECTION') {
        const option = decision.continuation.castOptions?.find(
          (candidate) => candidate.id === selection,
        )
        if (!option) return state
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...option.actions,
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'CAST_GENERIC_CONTRIBUTION_COUNT') {
        const contribution = decision.continuation.castContribution
        const count = Number(selection)
        if (
          !contribution ||
          !Number.isSafeInteger(count) ||
          !contribution.countOptions?.includes(count)
        )
          return state
        if (count === 0) {
          const planned = resolvePreparedCast(
            previous,
            contribution.cardName,
            contribution.displayedManaCost,
            contribution.castAction,
            contribution.cost,
          )
          if (planned.status !== 'resolved') return state
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            ...planned.actions,
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        if (
          contribution.contributionType === 'EXILE_DECLARED_CARDS_FROM_HAND'
        ) {
          const reduction = contribution.genericReductionPerCard ?? 0
          if (reduction <= 0) return state
          const nextDecision: import('../abilities/types/abilityTypes').PendingDecision =
            {
              id: `cast-card-contribution-${contribution.castAction.instanceId}-1`,
              sourceAbilityId: 'cast-generic-contribution',
              sourceInstanceId: contribution.castAction.instanceId,
              decisionPlayerId:
                contribution.castAction.actorPlayerId ??
                previous.localPlayerId ??
                'player-1',
              type: 'CAST_COST_CARD_SELECTION',
              prompt: `Declara una carta de tu mano para exiliar y reducir el coste (1/${count}).`,
              options: [],
              acceptsTextValue: true,
              textValueLabel: 'Nombre de la carta declarada',
              continuation: {
                effectsToExecute: [],
                resumeEffectIndex: 0,
                castCardCost: {
                  pendingActions: [],
                  costActions: [],
                  requiredCount: count,
                  selected: [],
                  ...(contribution.colors?.length
                    ? { colors: contribution.colors }
                    : {}),
                  ...(contribution.excludeSource
                    ? {
                        excludeSourceInstanceId:
                          contribution.castAction.instanceId,
                      }
                    : {}),
                  sourceScryfallId: contribution.castAction.card.scryfallId,
                  genericReductionContribution: {
                    cardName: contribution.cardName,
                    ...(contribution.displayedManaCost
                      ? { displayedManaCost: contribution.displayedManaCost }
                      : {}),
                    castAction: contribution.castAction,
                    cost: contribution.cost,
                    genericReductionPerCard: reduction,
                  },
                },
              },
            }
          nextDecision.options = knownCastCostOptions(previous, nextDecision)
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            { type: 'ADD_PENDING_DECISION', decision: nextDecision },
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const candidateSet = new Set(contribution.candidateIds)
        const options = previous.cards
          .filter((card) => candidateSet.has(card.instanceId))
          .filter((card) =>
            contribution.contributionType === 'TAP_PERMANENTS'
              ? card.zone === 'battlefield' && !card.tapped
              : card.zone === 'graveyard',
          )
          .map((card) => ({
            instanceId: card.instanceId,
            label: card.card.name,
          }))
        if (options.length < count) return state
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          {
            type: 'ADD_PENDING_DECISION',
            decision: {
              ...decision,
              id: `${decision.id}-select-1`,
              type: 'CAST_GENERIC_CONTRIBUTION_SELECTION',
              prompt:
                contribution.contributionType === 'TAP_PERMANENTS'
                  ? `Elige el primer permanente que giras para pagar (${1}/${count}).`
                  : `Elige la primera carta que exilias del cementerio (${1}/${count}).`,
              options,
              continuation: {
                ...decision.continuation,
                castContribution: {
                  ...contribution,
                  requiredCount: count,
                  selectedIds: [],
                },
              },
            },
          },
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'CAST_GENERIC_CONTRIBUTION_SELECTION') {
        const contribution = decision.continuation.castContribution
        const requiredCount = contribution?.requiredCount ?? 0
        const selectedIds = contribution?.selectedIds ?? []
        if (
          !contribution ||
          requiredCount <= 0 ||
          selectedIds.includes(selection) ||
          !decision.options?.some((option) => option.instanceId === selection)
        )
          return state
        const selected = [...selectedIds, selection]
        if (selected.length < requiredCount) {
          const remaining = (decision.options ?? []).filter(
            (option) => !selected.includes(option.instanceId),
          )
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            {
              type: 'ADD_PENDING_DECISION',
              decision: {
                ...decision,
                id: `${decision.id}-${selected.length + 1}`,
                prompt:
                  contribution.contributionType === 'TAP_PERMANENTS'
                    ? `Elige otro permanente que giras para pagar (${selected.length + 1}/${requiredCount}).`
                    : `Elige otra carta que exilias del cementerio (${selected.length + 1}/${requiredCount}).`,
                options: remaining,
                continuation: {
                  ...decision.continuation,
                  castContribution: { ...contribution, selectedIds: selected },
                },
              },
            },
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const contributionActions: GameAction[] = selected.map((instanceId) =>
          contribution.contributionType === 'TAP_PERMANENTS'
            ? ({ type: 'TAP_CARD', instanceId } as const)
            : ({ type: 'MOVE_CARD', instanceId, toZone: 'exile' } as const),
        )
        const provisional = applyActionsWithEvents(
          previous,
          contributionActions,
        )
        const reducedCost = {
          ...contribution.cost,
          generic: Math.max(0, contribution.cost.generic - requiredCount),
        }
        const planned = resolvePreparedCast(
          provisional,
          contribution.cardName,
          contribution.displayedManaCost,
          contribution.castAction,
          reducedCost,
        )
        if (planned.status !== 'resolved') return state
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...contributionActions,
          ...planned.actions,
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'CAST_COST_CARD_SELECTION') {
        const cost = decision.continuation.castCardCost
        const declared = declaredCastCostCard(previous, decision, selection)
        if (!cost || !declared) return state
        const selected = [...cost.selected, declared]
        if (selected.length < cost.requiredCount) {
          const nextDecision = {
            ...decision,
            id: `${decision.id}-${selected.length + 1}`,
            prompt: `Declara otra carta de tu mano para exiliar como coste (${selected.length + 1}/${cost.requiredCount}).`,
            continuation: {
              ...decision.continuation,
              castCardCost: { ...cost, selected },
            },
          }
          nextDecision.options = knownCastCostOptions(previous, nextDecision)
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            { type: 'ADD_PENDING_DECISION', decision: nextDecision },
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const declaredActions: GameAction[] = []
        for (const item of selected) {
          const known = previous.cards.find(
            (card) => card.instanceId === item.instanceId,
          )
          if (known) {
            declaredActions.push({
              type: 'MOVE_CARD',
              instanceId: item.instanceId,
              toZone: 'exile',
            })
            continue
          }
          const decisionPlayerId =
            decision.decisionPlayerId ?? previous.localPlayerId ?? 'player-1'
          const decisionDeck = deckDefinitionForPlayer(
            previous,
            decisionPlayerId,
          )
          const entry =
            decisionDeck &&
            [decisionDeck.commander, ...decisionDeck.mainboard].find(
              (candidate) => candidate.card.scryfallId === item.scryfallId,
            )
          if (entry)
            declaredActions.push({
              type: 'MATERIALIZE_CARD',
              instanceId: item.instanceId,
              card: entry.card,
              fromZone: 'hand',
              toZone: 'exile',
              actorPlayerId: decisionPlayerId,
            })
        }
        if (declaredActions.length !== selected.length) return state
        const reductionContribution = cost.genericReductionContribution
        if (reductionContribution) {
          const provisional = applyActionsWithEvents(previous, declaredActions)
          const reducedCost = {
            ...reductionContribution.cost,
            generic: Math.max(
              0,
              reductionContribution.cost.generic -
                selected.length * reductionContribution.genericReductionPerCard,
            ),
          }
          const planned = resolvePreparedCast(
            provisional,
            reductionContribution.cardName,
            reductionContribution.displayedManaCost,
            reductionContribution.castAction,
            reducedCost,
          )
          if (planned.status !== 'resolved') return state
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            ...declaredActions,
            ...planned.actions,
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...cost.costActions,
          ...declaredActions,
          ...cost.pendingActions,
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'ACTIVATION_VARIABLE_SELECTION') {
        const variable = decision.continuation.activationVariable
        const value = Number(selection)
        if (
          !variable ||
          !Number.isSafeInteger(value) ||
          !variable.options.includes(value)
        )
          return state
        const source = previous.cards.find(
          (card) => card.instanceId === variable.sourceInstanceId,
        )
        const ability = source
          ? effectiveAbilitiesForCard(previous, source).find(
              (
                candidate,
              ): candidate is import('../abilities/types/abilityTypes').ActivatedAbilityDefinition =>
                candidate.kind === 'ACTIVATED' &&
                candidate.id === variable.abilityId,
            )
          : undefined
        if (!source || !ability) return state
        const variables = { [variable.variableName]: value }
        const next = beginActivatedAbilityDeclaration(
          previous,
          source,
          ability,
          variables,
          [{ type: 'REMOVE_PENDING_DECISION', decisionId }],
        )
        return next === previous
          ? state
          : { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'NUMBER_SELECTION') {
        const variable = decision.continuation.castVariable
        const option = variable?.options.find(
          (candidate) => candidate.id === selection,
        )
        if (!variable || !option) return state
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...option.actions,
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'REPLACEMENT_EFFECT') {
        const replacement = decision.continuation.replacement
        if (!replacement || (selection !== 'YES' && selection !== 'NO'))
          return state
        const selectedActions =
          selection === 'YES'
            ? replacement.replacementActions
            : [replacement.originalAction]
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...selectedActions,
          ...replacement.deferredActions,
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'STACK_RETARGET_SELECTION') {
        const retarget = decision.continuation.stackRetarget
        const resolution = previous.pendingResolutions.find(
          (candidate) => candidate.id === decision.continuation.resolutionId,
        )
        if (!retarget || !resolution) return state
        if (
          selection !== '__KEEP_TARGET__' &&
          !decision.options?.some((option) => option.instanceId === selection)
        )
          return state
        const declaredTargets = retarget.declaredTargets.map((target, index) =>
          index === retarget.targetIndex && selection !== '__KEEP_TARGET__'
            ? { ...target, targetId: selection }
            : target,
        )
        const nextIndex = retarget.targetIndex + 1
        const nextDecision = controlledStackRetargetDecision(
          previous,
          resolution,
          retarget.stackObjectId,
          nextIndex,
          declaredTargets,
          retarget.resumeEffectIndex,
        )
        if (nextDecision) {
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            { type: 'ADD_PENDING_DECISION', decision: nextDecision },
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const resumed = {
          ...resolution,
          currentEffectIndex: retarget.resumeEffectIndex,
          completionActions: [
            ...(resolution.completionActions ?? []),
            {
              type: 'SET_STACK_TARGETS' as const,
              stackObjectId: retarget.stackObjectId,
              declaredTargets,
            },
          ],
        }
        let next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          { type: 'UPDATE_PENDING_RESOLUTION', resolution: resumed },
        ])
        const step = advancePendingResolution(next, resumed)
        if (step.type === 'ACTIONS')
          next = applyActionsWithEvents(next, [
            ...step.actions,
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.resolution.completionActions ?? []),
          ])
        else if (step.type === 'COMPLETE' || step.type === 'ERROR')
          next = applyActionsWithEvents(next, [
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.type === 'COMPLETE'
              ? (step.resolution.completionActions ?? [])
              : []),
          ])
        else
          next = applyActionsWithEvents(next, [
            ...step.actions,
            { type: 'UPDATE_PENDING_RESOLUTION', resolution: step.resolution },
            { type: 'ADD_PENDING_DECISION', decision: step.decision },
          ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'STACK_COPY_RETARGET_SELECTION') {
        const retarget = decision.continuation.stackCopyRetarget
        if (!retarget) return state
        if (
          selection !== '__KEEP_TARGET__' &&
          !decision.options?.some((option) => option.instanceId === selection)
        )
          return state
        const declaredTargets = retarget.declaredTargets.map((target, index) =>
          index === retarget.targetIndex && selection !== '__KEEP_TARGET__'
            ? { ...target, targetId: selection }
            : target,
        )
        const nextIndex = retarget.targetIndex + 1
        const nextDecision = stackCopyRetargetDecision(
          previous,
          retarget.stackObjectId,
          nextIndex,
          declaredTargets,
        )
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...(nextDecision
            ? [
                {
                  type: 'ADD_PENDING_DECISION' as const,
                  decision: nextDecision,
                },
              ]
            : [
                {
                  type: 'SET_STACK_TARGETS' as const,
                  stackObjectId: retarget.stackObjectId,
                  declaredTargets,
                },
              ]),
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'TRIGGER_TARGET_SELECTION') {
        const declaration = decision.continuation.triggerTargetDeclaration
        if (!declaration) return state
        const pending = previous.pendingAbilities.find(
          (item) => item.id === declaration.pendingAbilityId,
        )
        if (!pending) return state
        const chooseNoTarget = selection === 'NO_TARGET'
        if (
          chooseNoTarget &&
          (!declaration.optional || declaration.selectedTargets.length)
        )
          return state
        if (
          !chooseNoTarget &&
          !decision.options?.some((option) => option.instanceId === selection)
        )
          return state
        if (chooseNoTarget) {
          const first = pending.resolvedEffects[0]
          const updated = {
            ...pending,
            resolvedEffects:
              first?.type === 'OPTIONAL_EFFECT'
                ? pending.resolvedEffects.slice(1)
                : pending.resolvedEffects,
          }
          let next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            { type: 'UPDATE_PENDING_ABILITY', pending: updated },
            triggerStackObject(previous, updated),
          ])
          if (declaration.remainingPendingAbilityIds.length)
            next = applyActionsWithEvents(
              next,
              triggerPlacementActions(
                next,
                declaration.remainingPendingAbilityIds,
              ),
            )
          return { ...next, undoStack: [...state.undoStack, previous] }
        }

        const selectedTargets = [
          ...declaration.selectedTargets,
          { targetId: selection, constraints: declaration.constraints },
        ]
        if (selectedTargets.length < declaration.requiredCount) {
          const remainingOptions = (decision.options ?? []).filter(
            (option) =>
              option.instanceId !== 'NO_TARGET' &&
              !selectedTargets.some(
                (target) => target.targetId === option.instanceId,
              ),
          )
          if (
            remainingOptions.length <
            declaration.requiredCount - selectedTargets.length
          )
            return state
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            {
              type: 'ADD_PENDING_DECISION',
              decision: {
                ...decision,
                id: `trigger-target-${pending.id}-${selectedTargets.length + 1}`,
                options: remainingOptions,
                continuation: {
                  ...decision.continuation,
                  triggerTargetDeclaration: {
                    ...declaration,
                    selectedTargets,
                  },
                },
              },
            },
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }

        const first = pending.resolvedEffects[0]
        const declaredEffects =
          declaration.optional && first?.type === 'OPTIONAL_EFFECT'
            ? [...first.effects, ...pending.resolvedEffects.slice(1)]
            : pending.resolvedEffects
        const captured = pending.capturedContext
        const updated = {
          ...pending,
          resolvedEffects: declaredEffects,
          capturedContext: {
            selectedTargets: captured?.selectedTargets ?? [],
            selectedCards: captured?.selectedCards ?? [],
            selectedStackObjects: captured?.selectedStackObjects ?? [],
            selectedPlayers: captured?.selectedPlayers ?? [],
            variables: captured?.variables ?? {},
            declaredTargets: selectedTargets,
          },
        }
        let next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          { type: 'UPDATE_PENDING_ABILITY', pending: updated },
          triggerStackObject(previous, updated, selectedTargets),
        ])
        if (declaration.remainingPendingAbilityIds.length)
          next = applyActionsWithEvents(
            next,
            triggerPlacementActions(
              next,
              declaration.remainingPendingAbilityIds,
            ),
          )
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'TRIGGER_ORDER_SELECTION') {
        const remaining =
          decision.continuation.triggerOrder?.pendingAbilityIds ?? []
        if (!remaining.includes(selection)) return state
        const chosen = [
          ...(decision.continuation.triggerOrder?.orderedPendingAbilityIds ??
            []),
          selection,
        ]
        const stillUnordered = remaining.filter((id) => id !== selection)
        if (stillUnordered.length > 1) {
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            {
              type: 'ADD_PENDING_DECISION',
              decision: {
                ...decision,
                prompt:
                  'Choose the next trigger to put on the stack (earlier choices resolve later).',
                options: (decision.options ?? []).filter((option) =>
                  stillUnordered.includes(option.instanceId),
                ),
                continuation: {
                  ...decision.continuation,
                  triggerOrder: {
                    pendingAbilityIds: stillUnordered,
                    orderedPendingAbilityIds: chosen,
                  },
                },
              },
            },
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const ordered = [...chosen, ...stillUnordered]
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...triggerPlacementActions(previous, ordered),
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'LEGEND_RULE_SELECTION') {
        const options = decision.continuation.legendRule?.keepOptions ?? []
        if (!options.includes(selection)) return state
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...(decision.continuation.legendRule?.moveToGraveyard ?? [])
            .filter((instanceId) => instanceId !== selection)
            .map((instanceId) => ({
              type: 'MOVE_CARD' as const,
              instanceId,
              toZone: 'graveyard' as const,
            })),
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'COMMANDER_ZONE_CHOICE') {
        if (
          selection !== 'KEEP_IN_CURRENT_ZONE' &&
          selection !== 'MOVE_TO_COMMAND_ZONE'
        )
          return state
        const commander = decision.continuation.commanderZone
        if (!commander) return state
        const armed =
          selection === 'KEEP_IN_CURRENT_ZONE'
            ? {
                ...previous,
                commanderZoneChoiceAcknowledged: [
                  ...previous.commanderZoneChoiceAcknowledged,
                  {
                    instanceId: commander.instanceId,
                    zone: commander.currentZone,
                  },
                ],
              }
            : previous
        const next = applyActionsWithEvents(armed, [
          ...(selection === 'MOVE_TO_COMMAND_ZONE'
            ? [
                {
                  type: 'MOVE_CARD' as const,
                  instanceId: commander.instanceId,
                  toZone: 'command' as const,
                },
              ]
            : []),
          { type: 'REMOVE_PENDING_DECISION', decisionId },
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'COMMANDER_REPLACEMENT_CHOICE') {
        if (
          selection !== 'ORIGINAL_DESTINATION' &&
          selection !== 'COMMAND_ZONE'
        )
          return state
        const commander = decision.continuation.commanderZone
        if (!commander?.moveAction) return state
        const armed =
          selection === 'ORIGINAL_DESTINATION'
            ? {
                ...previous,
                commanderReplacementChoiceAcknowledged: [
                  ...previous.commanderReplacementChoiceAcknowledged,
                  {
                    instanceId: commander.instanceId,
                    destination: commander.currentZone,
                  },
                ],
              }
            : previous
        const next = applyActionsWithEvents(armed, [
          selection === 'COMMAND_ZONE'
            ? {
                type: 'MOVE_CARD',
                instanceId: commander.instanceId,
                toZone: 'command',
              }
            : commander.moveAction,
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...(commander.deferredActions ?? []),
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'COMBAT_DAMAGE_ASSIGNMENT') {
        const combatDamage = decision.continuation.combatDamage
        const option = combatDamage?.options.find(
          (candidate) => candidate.id === selection,
        )
        if (!combatDamage || !option) return state
        const accumulatedDamages = [
          ...combatDamage.accumulatedDamages,
          ...option.damages,
        ]
        const [nextAssignment, ...remainingAssignments] =
          combatDamage.remainingAssignments
        const actions: GameAction[] = [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
        ]
        if (nextAssignment)
          actions.push({
            type: 'ADD_PENDING_DECISION',
            decision: createCombatDamageAssignmentDecision(
              nextAssignment,
              accumulatedDamages,
              remainingAssignments,
              combatDamage.completionActions,
            ),
          })
        else
          actions.push(
            { type: 'DEAL_DAMAGE_BATCH', damages: accumulatedDamages },
            ...combatDamage.completionActions,
          )
        const next = applyActionsWithEvents(previous, actions)
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'PUBLIC_ZONE_CARD_SELECTION') {
        const publicSelection = decision.continuation.publicZoneSelection
        const resolution = previous.pendingResolutions.find(
          (candidate) => candidate.id === decision.continuation.resolutionId,
        )
        if (!publicSelection || !resolution) return state
        if (selection === 'FAIL_TO_FIND') {
          if (!publicSelection.allowFail) return state
          const resumed = {
            ...resolution,
            currentEffectIndex: decision.continuation.resumeEffectIndex,
          }
          let next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            { type: 'UPDATE_PENDING_RESOLUTION', resolution: resumed },
          ])
          const step = advancePendingResolution(next, resumed)
          if (step.type === 'ACTIONS')
            next = applyActionsWithEvents(next, [
              ...step.actions,
              { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
              ...(step.resolution.completionActions ?? []),
            ])
          else if (step.type === 'COMPLETE' || step.type === 'ERROR')
            next = applyActionsWithEvents(next, [
              { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
              ...(step.type === 'COMPLETE'
                ? (step.resolution.completionActions ?? [])
                : []),
            ])
          else
            next = applyActionsWithEvents(next, [
              ...step.actions,
              {
                type: 'UPDATE_PENDING_RESOLUTION',
                resolution: step.resolution,
              },
              { type: 'ADD_PENDING_DECISION', decision: step.decision },
            ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const known = previous.cards.find(
          (card) =>
            card.instanceId === selection &&
            card.zone === publicSelection.zone &&
            (card.ownerId ?? previous.localPlayerId) ===
              publicSelection.playerId &&
            cardMatchesSearchConstraints(
              card.card,
              publicSelection.constraints,
            ),
        )
        if (!known) return state
        const resumed = {
          ...resolution,
          currentEffectIndex: decision.continuation.resumeEffectIndex,
        }
        let next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...(publicSelection.linkKey
            ? ([
                {
                  type: 'LINK_CARD',
                  sourceInstanceId: decision.sourceInstanceId,
                  key: publicSelection.linkKey,
                  linkedInstanceId: known.instanceId,
                },
              ] as const)
            : []),
          { type: 'UPDATE_PENDING_RESOLUTION', resolution: resumed },
        ])
        const step = advancePendingResolution(next, resumed)
        if (step.type === 'ACTIONS')
          next = applyActionsWithEvents(next, [
            ...step.actions,
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.resolution.completionActions ?? []),
          ])
        else if (step.type === 'COMPLETE' || step.type === 'ERROR')
          next = applyActionsWithEvents(next, [
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.type === 'COMPLETE'
              ? (step.resolution.completionActions ?? [])
              : []),
          ])
        else
          next = applyActionsWithEvents(next, [
            ...step.actions,
            { type: 'UPDATE_PENDING_RESOLUTION', resolution: step.resolution },
            { type: 'ADD_PENDING_DECISION', decision: step.decision },
          ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'HIDDEN_ZONE_CARD_SELECTION') {
        const resolution = previous.pendingResolutions.find(
          (candidate) => candidate.id === decision.continuation.resolutionId,
        )
        if (!resolution) return state
        const hidden = decision.continuation.hiddenZoneSelection
        if (hidden) {
          if (selection === 'FAIL_TO_FIND') {
            if (!hidden.allowFail || hidden.selected.length > 0) return state
            const resumed = {
              ...resolution,
              currentEffectIndex: decision.continuation.resumeEffectIndex,
            }
            let next = applyActionsWithEvents(previous, [
              { type: 'REMOVE_PENDING_DECISION', decisionId },
              { type: 'UPDATE_PENDING_RESOLUTION', resolution: resumed },
            ])
            const step = advancePendingResolution(next, resumed)
            if (step.type === 'ACTIONS')
              next = applyActionsWithEvents(next, [
                ...step.actions,
                { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
                ...(step.resolution.completionActions ?? []),
              ])
            else if (step.type === 'COMPLETE' || step.type === 'ERROR')
              next = applyActionsWithEvents(next, [
                { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
                ...(step.type === 'COMPLETE'
                  ? (step.resolution.completionActions ?? [])
                  : []),
              ])
            else
              next = applyActionsWithEvents(next, [
                ...step.actions,
                {
                  type: 'UPDATE_PENDING_RESOLUTION',
                  resolution: step.resolution,
                },
                { type: 'ADD_PENDING_DECISION', decision: step.decision },
              ])
            return { ...next, undoStack: [...state.undoStack, previous] }
          }
          const declared = declaredHiddenZoneCard(previous, decision, selection)
          if (!declared) return state
          const selected = [
            ...hidden.selected,
            {
              instanceId: declared.instanceId,
              scryfallId: declared.scryfallId,
              materialize: declared.materialize,
            },
          ]
          if (selected.length < hidden.requiredCount) {
            const updatedDecision = {
              ...decision,
              id: `${decision.id}-${selected.length + 1}`,
              prompt: `${decision.prompt.replace(/\s*\(\d+\/\d+\)$/, '')} (${selected.length + 1}/${hidden.requiredCount})`,
              continuation: {
                ...decision.continuation,
                hiddenZoneSelection: { ...hidden, selected },
              },
            }
            const nextDecision = {
              ...updatedDecision,
              options: [
                ...knownHiddenZoneOptions(previous, updatedDecision),
                ...(hidden.allowFail && selected.length === 0
                  ? [
                      {
                        instanceId: 'FAIL_TO_FIND',
                        label: 'No elegir ninguna carta',
                      },
                    ]
                  : []),
              ],
            }
            const next = applyActionsWithEvents(previous, [
              { type: 'REMOVE_PENDING_DECISION', decisionId },
              { type: 'ADD_PENDING_DECISION', decision: nextDecision },
            ])
            return { ...next, undoStack: [...state.undoStack, previous] }
          }
          const searchedPlayerId =
            decision.decisionPlayerId ?? previous.localPlayerId ?? 'player-1'
          const searchedDeck = deckDefinitionForPlayer(
            previous,
            searchedPlayerId,
          )
          const cardDefinitionFor = (scryfallId: string) =>
            previous.cards.find((card) => card.card.scryfallId === scryfallId)
              ?.card ??
            (searchedDeck
              ? [searchedDeck.commander, ...searchedDeck.mainboard].find(
                  (entry) => entry.card.scryfallId === scryfallId,
                )?.card
              : undefined)
          const moveActions: GameAction[] = []
          for (const item of selected) {
            if (item.materialize) {
              const card = cardDefinitionFor(item.scryfallId)
              if (!card) return state
              moveActions.push({
                type: 'MATERIALIZE_CARD',
                instanceId: item.instanceId,
                card,
                fromZone: hidden.zone,
                toZone: hidden.destination,
                actorPlayerId: searchedPlayerId,
              })
            } else if (hidden.destination !== hidden.zone) {
              moveActions.push({
                type: 'MOVE_CARD',
                instanceId: item.instanceId,
                toZone: hidden.destination,
              })
            }
            if (hidden.linkKey)
              moveActions.push({
                type: 'LINK_CARD',
                sourceInstanceId: decision.sourceInstanceId,
                key: hidden.linkKey,
                linkedInstanceId: item.instanceId,
              })
          }
          const resumed = {
            ...resolution,
            currentEffectIndex: decision.continuation.resumeEffectIndex,
          }
          let next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            ...moveActions,
            { type: 'UPDATE_PENDING_RESOLUTION', resolution: resumed },
          ])
          const step = advancePendingResolution(next, resumed)
          if (step.type === 'ACTIONS')
            next = applyActionsWithEvents(next, [
              ...step.actions,
              { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
              ...(step.resolution.completionActions ?? []),
            ])
          else if (step.type === 'COMPLETE' || step.type === 'ERROR')
            next = applyActionsWithEvents(next, [
              { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
              ...(step.type === 'COMPLETE'
                ? (step.resolution.completionActions ?? [])
                : []),
            ])
          else
            next = applyActionsWithEvents(next, [
              ...step.actions,
              {
                type: 'UPDATE_PENDING_RESOLUTION',
                resolution: step.resolution,
              },
              { type: 'ADD_PENDING_DECISION', decision: step.decision },
            ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const search = decision.continuation.librarySearch
        if (!search) return state
        const searchedPlayerId =
          search.playerId ?? previous.localPlayerId ?? 'player-1'
        const searchedPlayerIsLocal =
          searchedPlayerId === previous.localPlayerId
        const shuffleAction = {
          type: 'DECLARE_PLAYER_SHUFFLED' as const,
          player: searchedPlayerIsLocal
            ? ('local' as const)
            : ('opponent' as const),
          playerId: searchedPlayerId,
        }
        if (selection === 'FAIL_TO_FIND') {
          if (!search.allowFail) return state
          const resumed = {
            ...resolution,
            currentEffectIndex: decision.continuation.resumeEffectIndex,
          }
          let next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            ...(search.shuffle ? [shuffleAction] : []),
            { type: 'UPDATE_PENDING_RESOLUTION', resolution: resumed },
          ])
          const step = advancePendingResolution(next, resumed)
          if (step.type === 'ACTIONS')
            next = applyActionsWithEvents(next, [
              ...step.actions,
              { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
              ...(step.resolution.completionActions ?? []),
            ])
          else if (step.type === 'COMPLETE' || step.type === 'ERROR')
            next = applyActionsWithEvents(next, [
              { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
              ...(step.type === 'COMPLETE'
                ? (step.resolution.completionActions ?? [])
                : []),
            ])
          else
            next = applyActionsWithEvents(next, [
              ...step.actions,
              {
                type: 'UPDATE_PENDING_RESOLUTION',
                resolution: step.resolution,
              },
              { type: 'ADD_PENDING_DECISION', decision: step.decision },
            ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const declared = declaredLibrarySearchCard(
          previous,
          decision,
          selection,
        )
        if (!declared) return state
        const destination =
          search.destination === 'TOP_OF_LIBRARY'
            ? ('library' as const)
            : search.destination
        const trackedLibraryCount =
          previous.players.find((player) => player.id === searchedPlayerId)
            ?.libraryCount ?? 0
        const searchActions: GameAction[] = [
          ...(declared.materialize
            ? [
                {
                  type: 'MATERIALIZE_CARD' as const,
                  instanceId: declared.instanceId,
                  card: declared.card,
                  fromZone: 'library' as const,
                  toZone: destination,
                },
              ]
            : destination !== 'library'
              ? [
                  {
                    type: 'MOVE_CARD' as const,
                    instanceId: declared.instanceId,
                    toZone: destination,
                    ...(destination === 'battlefield' &&
                    search.controller === 'SOURCE_CONTROLLER'
                      ? { controllerId: decision.decisionPlayerId }
                      : {}),
                  },
                ]
              : []),
          ...(!searchedPlayerIsLocal &&
          trackedLibraryCount > 0 &&
          destination !== 'library'
            ? [
                {
                  type: 'SET_PLAYER_LIBRARY_COUNT' as const,
                  playerId: searchedPlayerId,
                  count: Math.max(0, trackedLibraryCount - 1),
                },
              ]
            : []),
          ...(search.destination === 'TOP_OF_LIBRARY' && searchedPlayerIsLocal
            ? [
                {
                  type: 'SET_KNOWN_LIBRARY_TOP' as const,
                  instanceId: declared.instanceId,
                },
              ]
            : []),
          ...(search.shuffle ? [shuffleAction] : []),
        ]
        const resumed = {
          ...resolution,
          context: {
            ...resolution.context,
            selectedCards: [
              ...resolution.context.selectedCards,
              declared.instanceId,
            ],
          },
          currentEffectIndex: decision.continuation.resumeEffectIndex,
        }
        let next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          ...searchActions,
          { type: 'UPDATE_PENDING_RESOLUTION', resolution: resumed },
        ])
        const step = advancePendingResolution(next, resumed)
        if (step.type === 'ACTIONS')
          next = applyActionsWithEvents(next, [
            ...step.actions,
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.resolution.completionActions ?? []),
          ])
        else if (step.type === 'COMPLETE' || step.type === 'ERROR')
          next = applyActionsWithEvents(next, [
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.type === 'COMPLETE'
              ? (step.resolution.completionActions ?? [])
              : []),
          ])
        else
          next = applyActionsWithEvents(next, [
            ...step.actions,
            { type: 'UPDATE_PENDING_RESOLUTION', resolution: step.resolution },
            { type: 'ADD_PENDING_DECISION', decision: step.decision },
          ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'CHOOSE_MODE') {
        const resolution = previous.pendingResolutions.find(
          (candidate) => candidate.id === decision.continuation.resolutionId,
        )
        const mode = decision.continuation.modes?.find(
          (candidate) => candidate.id === selection,
        )
        if (!resolution || !mode) return state
        const resumed = {
          ...resolution,
          effects: [
            ...mode.effects,
            ...resolution.effects.slice(
              decision.continuation.resumeEffectIndex,
            ),
          ],
          currentEffectIndex: 0,
        }
        let next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          { type: 'UPDATE_PENDING_RESOLUTION', resolution: resumed },
        ])
        const step = advancePendingResolution(next, resumed)
        if (step.type === 'ACTIONS')
          next = applyActionsWithEvents(next, [
            ...step.actions,
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.resolution.completionActions ?? []),
          ])
        else if (step.type === 'COMPLETE' || step.type === 'ERROR')
          next = applyActionsWithEvents(next, [
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.type === 'COMPLETE'
              ? (step.resolution.completionActions ?? [])
              : []),
          ])
        else
          next = applyActionsWithEvents(next, [
            ...step.actions,
            { type: 'UPDATE_PENDING_RESOLUTION', resolution: step.resolution },
            { type: 'ADD_PENDING_DECISION', decision: step.decision },
          ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'CHOOSE_VALUE') {
        const resolution = previous.pendingResolutions.find(
          (candidate) => candidate.id === decision.continuation.resolutionId,
        )
        const choice = decision.continuation.chooseValue
        const option = choice?.options.find(
          (candidate) => candidate.id === selection,
        )
        const customValue =
          choice?.allowCustomValue === true && selection.trim().length > 0
            ? selection.trim()
            : undefined
        if (!resolution || !choice || (!option && customValue === undefined))
          return state
        const resumed = {
          ...resolution,
          currentEffectIndex: decision.continuation.resumeEffectIndex,
          context: {
            ...resolution.context,
            variables: {
              ...resolution.context.variables,
              [choice.variableName]: option?.value ?? customValue!,
            },
          },
        }
        let next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          { type: 'UPDATE_PENDING_RESOLUTION', resolution: resumed },
        ])
        const step = advancePendingResolution(next, resumed)
        if (step.type === 'ACTIONS')
          next = applyActionsWithEvents(next, [
            ...step.actions,
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.resolution.completionActions ?? []),
          ])
        else if (step.type === 'COMPLETE' || step.type === 'ERROR')
          next = applyActionsWithEvents(next, [
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.type === 'COMPLETE'
              ? (step.resolution.completionActions ?? [])
              : []),
          ])
        else
          next = applyActionsWithEvents(next, [
            ...step.actions,
            { type: 'UPDATE_PENDING_RESOLUTION', resolution: step.resolution },
            { type: 'ADD_PENDING_DECISION', decision: step.decision },
          ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'COUNTER_MOVE_TYPE_SELECTION') {
        const move = decision.continuation.counterMove
        const resolution = previous.pendingResolutions.find(
          (candidate) => candidate.id === decision.continuation.resolutionId,
        )
        if (!move || !resolution) return state
        if (selection === 'DONE') {
          const moves = Object.entries(move.moved)
            .filter(([, amount]) => amount > 0)
            .map(([counter, amount]) => ({ counter, amount }))
          const moveActions: GameAction[] = moves.length
            ? [
                {
                  type: 'MOVE_COUNTERS',
                  fromInstanceId: move.sourceInstanceId,
                  toInstanceId: move.targetInstanceId,
                  moves,
                },
              ]
            : []
          let next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            ...moveActions,
          ])
          const resumed = {
            ...resolution,
            currentEffectIndex: decision.continuation.resumeEffectIndex,
          }
          const step = advancePendingResolution(next, resumed)
          if (step.type === 'ACTIONS')
            next = applyActionsWithEvents(next, [
              ...step.actions,
              { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
              ...(step.resolution.completionActions ?? []),
            ])
          else if (step.type === 'COMPLETE' || step.type === 'ERROR')
            next = applyActionsWithEvents(next, [
              { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
              ...(step.type === 'COMPLETE'
                ? (step.resolution.completionActions ?? [])
                : []),
            ])
          else
            next = applyActionsWithEvents(next, [
              ...step.actions,
              {
                type: 'UPDATE_PENDING_RESOLUTION',
                resolution: step.resolution,
              },
              { type: 'ADD_PENDING_DECISION', decision: step.decision },
            ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const amount = move.available[selection]
        if (!Number.isSafeInteger(amount) || amount <= 0) return state
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          {
            type: 'ADD_PENDING_DECISION',
            decision: {
              ...decision,
              id: `${decision.id}-${selection}`,
              type: 'COUNTER_MOVE_AMOUNT_SELECTION',
              prompt: `¿Cuántos contadores ${selection} quieres mover?`,
              options: Array.from({ length: amount }, (_, index) => ({
                instanceId: String(index + 1),
                label: String(index + 1),
              })),
              continuation: {
                ...decision.continuation,
                counterMove: { ...move, selectedCounterType: selection },
              },
            },
          },
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'COUNTER_MOVE_AMOUNT_SELECTION') {
        const move = decision.continuation.counterMove
        const counter = move?.selectedCounterType
        const amount = Number(selection)
        if (
          !move ||
          !counter ||
          !Number.isSafeInteger(amount) ||
          amount <= 0 ||
          amount > (move.available[counter] ?? 0)
        )
          return state
        const available = { ...move.available }
        delete available[counter]
        const moved = {
          ...move.moved,
          [counter]: (move.moved[counter] ?? 0) + amount,
        }
        const next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          {
            type: 'ADD_PENDING_DECISION',
            decision: {
              ...decision,
              id: `${decision.id}-next`,
              type: 'COUNTER_MOVE_TYPE_SELECTION',
              prompt: 'Elige otro tipo de contador o termina.',
              options: [
                ...Object.keys(available).map((candidate) => ({
                  instanceId: candidate,
                  label: `${candidate} (${available[candidate]})`,
                })),
                { instanceId: 'DONE', label: 'Hecho' },
              ],
              continuation: {
                ...decision.continuation,
                counterMove: {
                  ...move,
                  available,
                  moved,
                  selectedCounterType: undefined,
                },
              },
            },
          },
        ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'COUNTER_DISTRIBUTION_SELECTION') {
        const distribution = decision.continuation.counterDistribution
        const resolution = previous.pendingResolutions.find(
          (candidate) => candidate.id === decision.continuation.resolutionId,
        )
        if (
          !distribution ||
          !resolution ||
          distribution.remaining <= 0 ||
          !distribution.candidateIds.includes(selection) ||
          !previous.cards.some(
            (card) =>
              card.instanceId === selection && card.zone === 'battlefield',
          )
        )
          return state
        const allocations = {
          ...distribution.allocations,
          [selection]: (distribution.allocations[selection] ?? 0) + 1,
        }
        const remaining = distribution.remaining - 1
        if (remaining > 0) {
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            {
              type: 'ADD_PENDING_DECISION',
              decision: {
                ...decision,
                id: `${decision.id}-${remaining}`,
                prompt:
                  distribution.prompt ??
                  `Distribuye ${remaining} contador${remaining === 1 ? '' : 'es'} ${distribution.counterType} restante${remaining === 1 ? '' : 's'}.`,
                continuation: {
                  ...decision.continuation,
                  counterDistribution: {
                    ...distribution,
                    remaining,
                    allocations,
                  },
                },
              },
            },
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        let next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          {
            type: 'DISTRIBUTE_COUNTERS',
            counter: distribution.counterType,
            allocations: Object.entries(allocations).map(
              ([instanceId, amount]) => ({ instanceId, amount }),
            ),
          },
        ])
        const resumed = {
          ...resolution,
          currentEffectIndex: decision.continuation.resumeEffectIndex,
        }
        const step = advancePendingResolution(next, resumed)
        if (step.type === 'ACTIONS')
          next = applyActionsWithEvents(next, [
            ...step.actions,
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.resolution.completionActions ?? []),
          ])
        else if (step.type === 'COMPLETE' || step.type === 'ERROR')
          next = applyActionsWithEvents(next, [
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.type === 'COMPLETE'
              ? (step.resolution.completionActions ?? [])
              : []),
          ])
        else
          next = applyActionsWithEvents(next, [
            ...step.actions,
            { type: 'UPDATE_PENDING_RESOLUTION', resolution: step.resolution },
            { type: 'ADD_PENDING_DECISION', decision: step.decision },
          ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      if (decision?.type === 'PAYMENT_CHOICE') {
        const next = resolvePaymentDecisionCore(previous, decisionId, selection)
        return next
          ? { ...next, undoStack: [...state.undoStack, previous] }
          : state
      }
      if (
        (decision?.type === 'TARGET_SELECTION' ||
          decision?.type === 'CARD_SELECTION') &&
        decision.continuation.selectionBatch
      ) {
        const resolution = previous.pendingResolutions.find(
          (candidate) => candidate.id === decision.continuation.resolutionId,
        )
        const batch = decision.continuation.selectionBatch
        if (
          !resolution ||
          !decision.options?.some(
            (option) => option.instanceId === selection,
          ) ||
          batch.selectedIds.includes(selection)
        )
          return state
        const selectedIds = [...batch.selectedIds, selection]
        const isStackTarget =
          decision.type === 'TARGET_SELECTION' &&
          (decision.constraints?.zones?.includes('stack') ||
            decision.constraints?.stackKind === 'SPELL')
        const isPlayerTarget =
          decision.type === 'TARGET_SELECTION' &&
          decision.constraints?.playerRelation !== undefined
        const context = {
          ...resolution.context,
          ...(decision.type === 'CARD_SELECTION'
            ? {
                selectedCards: [...resolution.context.selectedCards, selection],
              }
            : isPlayerTarget
              ? {
                  selectedPlayers: [
                    ...(resolution.context.selectedPlayers ?? []),
                    selection,
                  ],
                }
              : isStackTarget
                ? {
                    selectedStackObjects: [
                      ...resolution.context.selectedStackObjects,
                      selection,
                    ],
                  }
                : {
                    selectedTargets: [
                      ...resolution.context.selectedTargets,
                      selection,
                    ],
                    selectedTargetConstraints: [
                      ...(resolution.context.selectedTargetConstraints ?? []),
                      decision.constraints ?? {},
                    ],
                  }),
        }
        if (selectedIds.length < batch.requiredCount) {
          const continuedResolution = { ...resolution, context }
          const remainingOptions = (decision.options ?? []).filter(
            (option) => !selectedIds.includes(option.instanceId),
          )
          const nextDecision = {
            ...decision,
            id: `${decision.id}-${selectedIds.length + 1}`,
            prompt: `${batch.prompt} (${selectedIds.length + 1}/${batch.requiredCount})`,
            options: remainingOptions,
            continuation: {
              ...decision.continuation,
              selectionBatch: { ...batch, selectedIds },
            },
          }
          const next = applyActionsWithEvents(previous, [
            { type: 'REMOVE_PENDING_DECISION', decisionId },
            {
              type: 'UPDATE_PENDING_RESOLUTION',
              resolution: continuedResolution,
            },
            { type: 'ADD_PENDING_DECISION', decision: nextDecision },
          ])
          return { ...next, undoStack: [...state.undoStack, previous] }
        }
        const resumed = {
          ...resolution,
          effects: [
            ...batch.effects,
            ...resolution.effects.slice(
              decision.continuation.resumeEffectIndex,
            ),
          ],
          currentEffectIndex: 0,
          context,
        }
        let next = applyActionsWithEvents(previous, [
          { type: 'REMOVE_PENDING_DECISION', decisionId },
          { type: 'UPDATE_PENDING_RESOLUTION', resolution: resumed },
        ])
        const step = advancePendingResolution(next, resumed)
        if (step.type === 'ACTIONS')
          next = applyActionsWithEvents(next, [
            ...step.actions,
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.resolution.completionActions ?? []),
          ])
        else if (step.type === 'COMPLETE' || step.type === 'ERROR')
          next = applyActionsWithEvents(next, [
            { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
            ...(step.type === 'COMPLETE'
              ? (step.resolution.completionActions ?? [])
              : []),
          ])
        else
          next = applyActionsWithEvents(next, [
            ...step.actions,
            { type: 'UPDATE_PENDING_RESOLUTION', resolution: step.resolution },
            { type: 'ADD_PENDING_DECISION', decision: step.decision },
          ])
        return { ...next, undoStack: [...state.undoStack, previous] }
      }
      const resolution = decision
        ? previous.pendingResolutions.find(
            (candidate) => candidate.id === decision.continuation.resolutionId,
          )
        : undefined
      if (!decision || !resolution) return state
      const isOptional = decision.type === 'OPTIONAL_EFFECT'
      if (isOptional && selection !== 'YES' && selection !== 'NO') return state
      if (
        !isOptional &&
        !decision.options?.some((option) => option.instanceId === selection)
      )
        return state
      const selectedContext = {
        ...resolution.context,
        ...(decision.type === 'TARGET_SELECTION'
          ? decision.constraints?.playerRelation
            ? {
                selectedPlayers: [
                  ...(resolution.context.selectedPlayers ?? []),
                  selection,
                ],
              }
            : decision.constraints?.zones?.includes('stack')
              ? {
                  selectedStackObjects: [
                    ...resolution.context.selectedStackObjects,
                    selection,
                  ],
                }
              : {
                  selectedTargets: [
                    ...resolution.context.selectedTargets,
                    selection,
                  ],
                  selectedTargetConstraints: [
                    ...(resolution.context.selectedTargetConstraints ?? []),
                    decision.constraints ?? {},
                  ],
                }
          : {}),
        ...(decision.type === 'CARD_SELECTION'
          ? { selectedCards: [...resolution.context.selectedCards, selection] }
          : {}),
        ...(decision.type === 'PLAYER_SELECTION'
          ? {
              selectedPlayers: [
                ...(resolution.context.selectedPlayers ?? []),
                selection,
              ],
            }
          : {}),
      }
      let branchEffects =
        isOptional && selection === 'NO'
          ? []
          : decision.continuation.effectsToExecute
      if (
        decision.type === 'TARGET_SELECTION' &&
        !decision.constraints?.zones?.includes('stack') &&
        !decision.constraints?.playerRelation
      )
        branchEffects = targetingPaymentEffects(
          previous,
          resolution,
          selection,
          branchEffects,
        )
      const resumed = {
        ...resolution,
        effects: [
          ...branchEffects,
          ...resolution.effects.slice(decision.continuation.resumeEffectIndex),
        ],
        currentEffectIndex: 0,
        context: selectedContext,
      }
      let next = applyActionsWithEvents(previous, [
        { type: 'REMOVE_PENDING_DECISION', decisionId },
        { type: 'UPDATE_PENDING_RESOLUTION', resolution: resumed },
      ])
      const step = advancePendingResolution(next, resumed)
      if (step.type === 'ACTIONS') {
        next = applyActionsWithEvents(next, [
          ...step.actions,
          { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
          ...(step.resolution.completionActions ?? []),
        ])
      } else if (step.type === 'COMPLETE' || step.type === 'ERROR') {
        next = applyActionsWithEvents(next, [
          { type: 'REMOVE_PENDING_RESOLUTION', resolutionId: resumed.id },
          ...(step.type === 'COMPLETE'
            ? (step.resolution.completionActions ?? [])
            : []),
        ])
      } else {
        next = applyActionsWithEvents(next, [
          ...step.actions,
          { type: 'UPDATE_PENDING_RESOLUTION', resolution: step.resolution },
          { type: 'ADD_PENDING_DECISION', decision: step.decision },
        ])
      }
      return { ...next, undoStack: [...state.undoStack, previous] }
    })
    set(resumePausedBeginningOfTurn)
  },
  replaceGame: (game) => set({ ...game, undoStack: [] }),
}))

/** Applies an action group once, deriving events exclusively from domain state transitions. */
const applyActionsWithEvents = (
  initial: GameState,
  actions: GameAction[],
): GameState => {
  const addPendingToStack = (
    state: GameState,
    pending: import('../abilities/types/abilityTypes').PendingAbility[],
  ): GameState => {
    let next = applyGameAction(
      state,
      { type: 'ADD_PENDING_ABILITIES', pending },
      createActionMetadata(),
    )
    if (pending.length === 1) {
      for (const placementAction of triggerPlacementActions(next, [
        pending[0].id,
      ])) {
        next = applyGameAction(next, placementAction, createActionMetadata())
        if (
          placementAction.type === 'ADD_STACK_OBJECT' &&
          placementAction.stackObject.kind === 'TRIGGERED_ABILITY' &&
          placementAction.stackObject.declaredTargets?.length
        ) {
          const stackObject = next.stack.find(
            (object) =>
              object.stackObjectId ===
              placementAction.stackObject.stackObjectId,
          )
          if (stackObject) {
            const ward = wardPendingAbilitiesForStackObject(next, stackObject)
            if (ward.length) next = addPendingToStack(next, ward)
          }
        }
      }
      return next
    }
    if (pending.length > 1)
      next = applyGameAction(
        next,
        {
          type: 'ADD_PENDING_DECISION',
          decision: {
            id: `trigger-order-${pending.map((item) => item.id).join('-')}`,
            sourceAbilityId: 'trigger-order',
            sourceInstanceId: pending[0].sourceInstanceId,
            type: 'TRIGGER_ORDER_SELECTION',
            prompt: 'Choose trigger order (first listed resolves last).',
            options: pending.map((item) => ({
              instanceId: item.id,
              label: item.sourceCardName,
            })),
            continuation: {
              effectsToExecute: [],
              resumeEffectIndex: 0,
              triggerOrder: {
                pendingAbilityIds: pending.map((item) => item.id),
              },
            },
          },
        },
        createActionMetadata(),
      )
    return next
  }
  const processDerivedEvents = (
    before: GameState,
    action: GameAction,
    after: GameState,
  ): GameState => {
    let next = after
    const pending: import('../abilities/types/abilityTypes').PendingAbility[] =
      []
    const consumedDelayed = new Set<string>()
    for (const event of deriveGameEvents(before, action, after)) {
      if (event.type === 'CARD_ENTERED_BATTLEFIELD' && event.playerId)
        next = applyGameAction(
          next,
          {
            type: 'RECORD_PERMANENT_ENTERED_THIS_TURN',
            instanceId: event.cardInstanceId,
            playerId: event.playerId,
            cardTypes: event.cardTypes,
            subtypes: event.subtypes,
          },
          createActionMetadata(),
        )
      if (event.type === 'CREATURE_ATTACKED' && event.playerId)
        next = applyGameAction(
          next,
          {
            type: 'RECORD_CREATURE_ATTACKED_THIS_TURN',
            instanceId: event.cardInstanceId,
            playerId: event.playerId,
          },
          createActionMetadata(),
        )
      const eventPending = evaluateAbilities(next, event, before)
      pending.push(...eventPending)
      for (const item of eventPending) {
        if (item.triggerLimit !== 'ONCE_EACH_TURN') continue
        next = applyGameAction(
          next,
          {
            type: 'SET_TRIGGERED_ABILITY_TURN_MARKER',
            key: `${item.sourceInstanceId}:${item.abilityId}`,
            turn: next.turn,
          },
          createActionMetadata(),
        )
      }
      const delayed = evaluateDelayedEffects(next, event)
      pending.push(...delayed.pending)
      delayed.consumedIds.forEach((id) => consumedDelayed.add(id))
    }
    for (const delayedEffectId of consumedDelayed)
      next = applyGameAction(
        next,
        { type: 'REMOVE_DELAYED_EFFECT', delayedEffectId },
        createActionMetadata(),
      )
    return pending.length ? addPendingToStack(next, pending) : next
  }
  const addWardTriggersForDeclaration = (
    before: GameState,
    action: GameAction,
    after: GameState,
  ): GameState => {
    let stackObject: GameState['stack'][number] | undefined
    if (action.type === 'CAST_SPELL')
      stackObject = after.stack.find(
        (object) =>
          object.kind === 'SPELL' &&
          object.spellInstanceId === action.instanceId &&
          !before.stack.some(
            (previousObject) =>
              previousObject.stackObjectId === object.stackObjectId,
          ),
      )
    else if (
      action.type === 'ADD_STACK_OBJECT' &&
      (action.stackObject.kind === 'ACTIVATED_ABILITY' ||
        action.stackObject.kind === 'TRIGGERED_ABILITY')
    )
      stackObject = after.stack.find(
        (object) => object.stackObjectId === action.stackObject.stackObjectId,
      )
    else if (action.type === 'SET_STACK_TARGETS')
      stackObject = after.stack.find(
        (object) => object.stackObjectId === action.stackObjectId,
      )
    else if (action.type === 'COPY_STACK_SPELL' && !action.chooseNewTargets)
      stackObject = after.stack.find(
        (object) =>
          object.kind === 'SPELL' &&
          object.copiedFromStackObjectId === action.sourceStackObjectId &&
          !before.stack.some(
            (previousObject) =>
              previousObject.stackObjectId === object.stackObjectId,
          ),
      )
    if (!stackObject?.declaredTargets?.length) return after
    const ward = wardPendingAbilitiesForStackObject(after, stackObject)
    return ward.length ? addPendingToStack(after, ward) : after
  }
  const applySbas = (state: GameState): GameState => {
    let next = state
    for (let iteration = 0; iteration < 20; iteration += 1) {
      const result = checkStateBasedActions(next)
      if (result.decision)
        return applyGameAction(
          next,
          { type: 'ADD_PENDING_DECISION', decision: result.decision },
          createActionMetadata(),
        )
      if (!result.actions.length) return next
      for (const action of result.actions) {
        const after = applyGameAction(next, action, createActionMetadata())
        if (after === next) continue
        next = processDerivedEvents(next, action, after)
      }
    }
    return next
  }
  let state = initial
  for (let actionIndex = 0; actionIndex < actions.length; actionIndex += 1) {
    const action = actions[actionIndex]
    const replacement = planReplacement(state, action)
    if (replacement) {
      for (const markerAction of replacement.markerActions)
        state = applyGameAction(state, markerAction, createActionMetadata())
      if (replacement.effect.optional) {
        state = applyGameAction(
          state,
          {
            type: 'ADD_PENDING_DECISION',
            decision: {
              id: `replacement-${replacement.effect.id}-${state.turn}-${actionIndex}`,
              sourceAbilityId: replacement.effect.id,
              sourceInstanceId: replacement.effect.sourceInstanceId,
              type: 'REPLACEMENT_EFFECT',
              prompt: 'Apply the replacement effect instead?',
              options: [
                { instanceId: 'YES', label: 'Yes' },
                { instanceId: 'NO', label: 'No' },
              ],
              continuation: {
                effectsToExecute: [],
                resumeEffectIndex: 0,
                replacement: {
                  effectId: replacement.effect.id,
                  originalAction: replacement.originalAction,
                  replacementActions: replacement.replacementActions,
                  deferredActions: actions.slice(actionIndex + 1),
                },
              },
            },
          },
          createActionMetadata(),
        )
        return state
      }
      state = applyActionsWithEvents(state, replacement.replacementActions)
      continue
    }
    if (action.type === 'MOVE_CARD') {
      const commander = state.cards.find(
        (card) => card.instanceId === action.instanceId,
      )
      if (
        commander &&
        isCommanderInstance(state, commander.instanceId) &&
        (action.toZone === 'hand' || action.toZone === 'library') &&
        !state.commanderReplacementChoiceAcknowledged.some(
          (entry) =>
            entry.instanceId === commander.instanceId &&
            entry.destination === action.toZone,
        )
      ) {
        state = applyGameAction(
          state,
          {
            type: 'ADD_PENDING_DECISION',
            decision: {
              id: `commander-replacement-${commander.instanceId}-${action.toZone}`,
              sourceAbilityId: 'commander-replacement',
              sourceInstanceId: commander.instanceId,
              type: 'COMMANDER_REPLACEMENT_CHOICE',
              prompt: `Put commander into command zone instead of ${action.toZone}?`,
              options: [
                {
                  instanceId: 'ORIGINAL_DESTINATION',
                  label: 'Original destination',
                },
                { instanceId: 'COMMAND_ZONE', label: 'Command zone' },
              ],
              continuation: {
                effectsToExecute: [],
                resumeEffectIndex: 0,
                commanderZone: {
                  instanceId: commander.instanceId,
                  currentZone: action.toZone,
                  moveAction: action,
                  deferredActions: actions.slice(actionIndex + 1),
                },
              },
            },
          },
          createActionMetadata(),
        )
        return state
      }
    }
    const beforeAction = state
    const next = applyGameAction(state, action, createActionMetadata())
    if (next === state) continue
    const enteringTappedIds = new Set(
      next.cards
        .filter((card) => {
          if (card.zone !== 'battlefield' || card.tapped) return false
          const previousCard = beforeAction.cards.find(
            (candidate) => candidate.instanceId === card.instanceId,
          )
          if (previousCard?.zone === 'battlefield') return false
          return entersBattlefieldTappedByStaticEffects(beforeAction, card)
        })
        .map((card) => card.instanceId),
    )
    const enteredState = enteringTappedIds.size
      ? {
          ...next,
          cards: next.cards.map((card) =>
            enteringTappedIds.has(card.instanceId)
              ? { ...card, tapped: true }
              : card,
          ),
        }
      : next
    state = processDerivedEvents(state, action, enteredState)
    if (action.type === 'COPY_STACK_SPELL' && action.chooseNewTargets) {
      const copiedStackObject = state.stack.find(
        (object) =>
          object.kind === 'SPELL' &&
          object.copiedFromStackObjectId === action.sourceStackObjectId &&
          !beforeAction.stack.some(
            (previousObject) =>
              previousObject.stackObjectId === object.stackObjectId,
          ),
      )
      const retargetDecision = copiedStackObject
        ? stackCopyRetargetDecision(state, copiedStackObject.stackObjectId)
        : undefined
      if (retargetDecision)
        state = applyGameAction(
          state,
          { type: 'ADD_PENDING_DECISION', decision: retargetDecision },
          createActionMetadata(),
        )
      else state = addWardTriggersForDeclaration(beforeAction, action, state)
    } else state = addWardTriggersForDeclaration(beforeAction, action, state)
    state = applySbas(state)
    if (
      (action.type === 'ADVANCE_STEP' || action.type === 'END_TURN') &&
      state.turnState.step === 'CLEANUP' &&
      !state.pendingDecisions.some(
        (decision) => decision.type === 'CLEANUP_DISCARD_SELECTION',
      )
    ) {
      const cleanupDecision = cleanupDiscardDecision(state)
      if (cleanupDecision)
        state = applyGameAction(
          state,
          { type: 'ADD_PENDING_DECISION', decision: cleanupDecision },
          createActionMetadata(),
        )
    }
  }
  return state
}

/**
 * Resolves a spell through the normal domain pipeline.  Some spells already
 * have declarative runtime effects; those must finish (or pause for a choice)
 * before their stack object leaves the stack.  All other spells use the normal
 * RESOLVE_SPELL transition directly.
 */
const resolveSpellWithEffects = (
  state: GameState,
  action: Extract<GameAction, { type: 'RESOLVE_SPELL' }>,
): GameState => {
  const source = state.cards.find(
    (card) => card.instanceId === action.instanceId && card.zone === 'stack',
  )
  const abilities = source ? effectiveAbilitiesForCard(state, source) : []
  const spellEffect = abilities.find(
    (
      ability,
    ): ability is import('../abilities/types/abilityTypes').SpellEffectDefinition =>
      ability.kind === 'SPELL_EFFECT',
  )
  const asEnters = abilities.find(
    (
      ability,
    ): ability is import('../abilities/types/abilityTypes').AsEntersAbilityDefinition =>
      ability.kind === 'AS_ENTERS',
  )

  if (!source) return applyActionsWithEvents(state, [action])

  if (asEnters && !action.asEntersHandled) {
    const resolution = createAsEntersResolution(source, asEnters)
    const step = advancePendingResolution(state, resolution)
    if (step.type === 'ACTIONS')
      return applyActionsWithEvents(state, [
        ...step.actions,
        ...(step.resolution.completionActions ?? []),
      ])
    if (step.type === 'DECISION')
      return applyActionsWithEvents(state, [
        ...step.actions,
        { type: 'ADD_PENDING_RESOLUTION', resolution: step.resolution },
        { type: 'ADD_PENDING_DECISION', decision: step.decision },
      ])
    if (step.type === 'ERROR') return state
    return applyActionsWithEvents(
      state,
      step.resolution.completionActions ?? [action],
    )
  }

  if (!spellEffect) return applyActionsWithEvents(state, [action])

  const stackObject = state.stack.find(
    (candidate) => candidate.spellInstanceId === source.instanceId,
  )
  const resolution = createSpellEffectResolution(
    source,
    spellEffect,
    stackObject?.variables ?? {},
    stackObject?.declaredTargets ?? [],
  )
  const step = advancePendingResolution(state, resolution)
  if (step.type === 'ACTIONS')
    return applyActionsWithEvents(state, [
      ...step.actions,
      ...(step.resolution.completionActions ?? [action]),
    ])
  if (step.type === 'DECISION')
    return applyActionsWithEvents(state, [
      ...step.actions,
      { type: 'ADD_PENDING_RESOLUTION', resolution: step.resolution },
      { type: 'ADD_PENDING_DECISION', decision: step.decision },
    ])
  if (step.type === 'ERROR') return state
  return applyActionsWithEvents(
    state,
    step.resolution.completionActions ?? [action],
  )
}
