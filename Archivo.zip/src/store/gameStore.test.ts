import { beforeEach, describe, expect, it } from 'vitest'
import { createInitialGameState } from '../engine/gameEngine'
import type { CardInstance } from '../types/card'
import { useGameStore } from './gameStore'

const ring: CardInstance = {
  instanceId: 'ring',
  card: {
    scryfallId: 'ring',
    name: 'Sol Ring',
    cmc: 1,
    typeLine: 'Artifact',
    colors: [],
    colorIdentity: [],
  },
  zone: 'battlefield',
  tapped: false,
  counters: {},
}

beforeEach(() =>
  useGameStore.getState().replaceGame(createInitialGameState([ring])),
)

describe('game store undo', () => {
  it('undoes a loss of life', () => {
    useGameStore.getState().dispatch({ type: 'LOSE_LIFE', amount: 3 })
    expect(useGameStore.getState().life).toBe(37)
    useGameStore.getState().undoLastAction()
    expect(useGameStore.getState().life).toBe(40)
  })

  it('undoes a tap', () => {
    useGameStore.getState().dispatch({ type: 'TAP_CARD', instanceId: 'ring' })
    useGameStore.getState().undoLastAction()
    expect(useGameStore.getState().cards[0].tapped).toBe(false)
  })

  it('undoes several successful actions one at a time', () => {
    useGameStore.getState().dispatch({ type: 'LOSE_LIFE', amount: 2 })
    useGameStore
      .getState()
      .dispatch({ type: 'ADD_MANA', color: 'C', amount: 1 })
    useGameStore.getState().undoLastAction()
    expect(useGameStore.getState().manaPool.C).toBe(0)
    expect(useGameStore.getState().life).toBe(38)
    useGameStore.getState().undoLastAction()
    expect(useGameStore.getState().life).toBe(40)
  })

  it('does not add an undo snapshot for a failed action', () => {
    useGameStore
      .getState()
      .dispatch({ type: 'TAP_CARD', instanceId: 'missing' })
    expect(useGameStore.getState().undoStack).toHaveLength(0)
  })

  it('clears undo history when a new game replaces the current one', () => {
    useGameStore.getState().dispatch({ type: 'LOSE_LIFE', amount: 1 })
    useGameStore.getState().replaceGame(createInitialGameState())
    expect(useGameStore.getState().undoStack).toHaveLength(0)
  })
})

describe('declaration-time ward', () => {
  it('puts Ward above a declared opposing spell and counters that spell when unpaid', () => {
    const svyelun: CardInstance = {
      instanceId: 'svyelun',
      card: {
        scryfallId: 'svyelun',
        name: 'Svyelun of Sea and Sky',
        cmc: 3,
        typeLine: 'Legendary Creature — Merfolk God',
        oracleText:
          'Svyelun has indestructible as long as you control at least two other Merfolk.\nWhenever Svyelun attacks, draw a card.\nOther Merfolk you control have ward {1}.',
        colors: ['U'],
        colorIdentity: ['U'],
        power: '3',
        toughness: '4',
      },
      zone: 'battlefield',
      tapped: false,
      counters: {},
      controller: 'YOU',
      controllerId: 'player-1',
      ownerId: 'player-1',
    }
    const target: CardInstance = {
      instanceId: 'warded-merfolk',
      card: {
        scryfallId: 'warded-merfolk',
        name: 'Warded Merfolk',
        cmc: 2,
        typeLine: 'Creature — Merfolk',
        colors: ['U'],
        colorIdentity: ['U'],
        power: '2',
        toughness: '2',
      },
      zone: 'battlefield',
      tapped: false,
      counters: {},
      controller: 'YOU',
      controllerId: 'player-1',
      ownerId: 'player-1',
    }
    const hostileSpell: CardInstance = {
      instanceId: 'hostile-spell',
      card: {
        scryfallId: 'hostile-spell',
        name: 'Hostile Spell',
        cmc: 1,
        typeLine: 'Instant',
        colors: ['R'],
        colorIdentity: ['R'],
      },
      zone: 'hand',
      tapped: false,
      counters: {},
      controller: 'OPPONENT',
      controllerId: 'player-2',
      ownerId: 'player-2',
    }
    useGameStore
      .getState()
      .replaceGame(createInitialGameState([svyelun, target, hostileSpell]))

    useGameStore.getState().dispatch({
      type: 'CAST_SPELL',
      instanceId: hostileSpell.instanceId,
      card: hostileSpell.card,
      fromZone: 'hand',
      actorPlayerId: 'player-2',
      declaredTargets: [
        {
          targetId: target.instanceId,
          constraints: { zones: ['battlefield'], cardTypes: ['Creature'] },
        },
      ],
    })

    const afterCast = useGameStore.getState()
    const ward = afterCast.pendingAbilities.find((ability) =>
      ability.id.startsWith('ward-'),
    )
    expect(ward).toBeDefined()
    expect(afterCast.stack.map((object) => object.kind)).toEqual([
      'SPELL',
      'TRIGGERED_ABILITY',
    ])
    expect(afterCast.stack.at(-1)).toMatchObject({
      controller: 'YOU',
      pendingAbilityId: ward!.id,
    })

    useGameStore.getState().resolvePendingAbility(ward!.id)
    const payment = useGameStore
      .getState()
      .pendingDecisions.find((decision) => decision.type === 'PAYMENT_CHOICE')
    expect(payment?.options).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ instanceId: 'PAID' }),
        expect.objectContaining({ instanceId: 'NOT_PAID' }),
      ]),
    )
    useGameStore.getState().resolvePendingDecision(payment!.id, 'NOT_PAID')

    expect(
      useGameStore
        .getState()
        .cards.find((card) => card.instanceId === hostileSpell.instanceId)
        ?.zone,
    ).toBe('graveyard')
    expect(
      useGameStore.getState().stack.some((object) => object.kind === 'SPELL'),
    ).toBe(false)
  })
})
